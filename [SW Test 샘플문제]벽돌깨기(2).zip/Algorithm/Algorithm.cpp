#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>

void drop();
void print_f();
void destroy(std::pair<int, int> start_p);
void DFS(int total_shoot);
void copy_matrix();
int find_start_p(int row_num);
int range_chk(std::pair<int, int> cur_p);

int N, W, H = 0;
int map[16][13];
int map_copied[16][13];
int map_visit[16][13];
int row_visit[13];

int min_block_cnt = 1e9;
int shoot_cnt = 0;
int total_block_cnt = 0;

int main() {
	int test_case = 0;

	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		memset(map, 0, sizeof(map));
		memset(map_copied, 0, sizeof(map_copied));
		memset(row_visit, 0, sizeof(row_visit));
		memset(map_visit, 0, sizeof(map_visit));
		shoot_cnt = 0;
		min_block_cnt = 1e9;
		total_block_cnt = 0;

		scanf("%d %d %d", &N, &W, &H);
		
		for (int j = 0; j < H; j++) {
			for (int k = 0; k < W; k++) {
				scanf("%d", &map[j][k]);
				if (map[j][k] >= 1)
					total_block_cnt++;
			}
		}

		DFS(N);

		if (min_block_cnt == 1e9)
			min_block_cnt = 0;
		printf("#%d %d\n", i, min_block_cnt);
	}
	return 0;
}

// ��ȹ�� �ٲ㼭 W�� ������ N���� ���� �̴� ���
std::vector<int> row_v;
int line_num = 0;
int cur_block_cnt = 0;
// �� ��ȣ �� N���� �����ϴ� ���
// ���� �� ������ ���� ū ���ڸ� ������
void DFS(int total_shoot) {
	if (shoot_cnt == total_shoot) {

		/*printf("���� ��\n");
		for (int i = 0; i < row_v.size(); i++) {
			printf("%d ", row_v[i]);
		}
		printf("\n");*/
		
		copy_matrix();
		
		for (int i = 0; i < row_v.size(); i++) {
			line_num = find_start_p(row_v[i]);
			if (line_num == -1)
				return;
			else {
				destroy({ line_num, row_v[i] });
			}
		}

		//printf("�̹� ���� �� %d\n",cur_block_cnt);
		if (min_block_cnt > cur_block_cnt)
			min_block_cnt = cur_block_cnt;

		return;
	}
	
	for (int i = 0; i < W; i++) {
		if (row_visit[i] == 0) {
			//row_visit[i] = 1;
			row_v.push_back(i);
			shoot_cnt++;

			DFS(total_shoot);

			//row_visit[i] = 0;
			row_v.pop_back();
			shoot_cnt--;
		}
	}
	return;
}

int block_cnt() {
	int cnt = 0;
	for (int i = 0; i < H; i++) {
		for (int j = 0; j < W; j++) {
			if (map_copied[i][j] != 0)
				cnt++;
		}
	}
	return cnt;
}

void copy_matrix() {
	for (int i = 0; i < H; i++) {
		for (int j = 0; j < W; j++) {
			map_copied[i][j] = map[i][j];
		}
	}
	return;
}

int find_start_p(int row_num) {
	for (int i = 0; i < H; i++) {
		if (map_copied[i][row_num] == 0)
			continue;
		else
			return i;
	}
	return -1;
}

void destroy(std::pair<int, int> start_p) {
	std::queue<std::pair<std::pair<int, int>,int>> bfs_q;
	std::pair<int, int> cur_p;
	int cur_v = 0;
	std::pair<int, int> next_p;
	int next_v = 0;
	int destroy_block_cnt = 0;
	memset(map_visit, 0, sizeof(map_visit));

	bfs_q.push({ start_p,map_copied[start_p.first][start_p.second] });
	while (bfs_q.empty() == 0 && destroy_block_cnt < total_block_cnt) {
		cur_p = bfs_q.front().first;
		cur_v = bfs_q.front().second;
		bfs_q.pop();

		// ������
		//printf("���� %d %d\n", cur_p.first, cur_p.second);
		for (int i = cur_p.first - cur_v + 1; i < cur_p.first + cur_v; i++) {
			next_p = { i,cur_p.second };
			if (map_copied[next_p.first][next_p.second] >= 1 && range_chk(next_p) && map_visit[next_p.first][next_p.second] == 0) {
				map_visit[next_p.first][next_p.second] = 1;
				next_v = map_copied[next_p.first][next_p.second];
				if (next_v > 1) {
					//printf("%d %d\n", next_p.first, next_p.second);
					bfs_q.push({ next_p,next_v });
				}
				map_copied[next_p.first][next_p.second] = 0;
				destroy_block_cnt++;
			}
		}

		// ������
		for (int i = cur_p.second - cur_v + 1; i < cur_p.second + cur_v; i++) {
			next_p = { cur_p.first,i };
			if (map_copied[next_p.first][next_p.second] >= 1 && range_chk(next_p) && map_visit[next_p.first][next_p.second] == 0) {
				map_visit[next_p.first][next_p.second] = 1;
				next_v = map_copied[next_p.first][next_p.second];
				if (next_v > 1) {
					//printf("%d %d\n", next_p.first, next_p.second);
					bfs_q.push({ next_p,next_v });
				}
				map_copied[next_p.first][next_p.second] = 0;
				destroy_block_cnt++;
			}
		}
	}

	//printf("����\n");
	//print_f();

	drop();

	/*printf("�߶�\n");
	print_f();*/

	return;
}

int range_chk(std::pair<int, int> cur_p) {
	if (0 <= cur_p.first && cur_p.first < H) {
		if (0 <= cur_p.second && cur_p.second < W) {
			return 1;
		}
	}
	return 0;
}

void print_f() {
	printf("copied_map\n");
	for (int i = 0; i < H; i++) {
		for (int j = 0; j < W; j++) {
			printf("%d ", map_copied[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

void drop() {
	int temp_i = 0;
	cur_block_cnt = 0;	// ����Ʈ�����ϴµ�
	for (int j = 0; j < W; j++) {
		for (int i = H - 1; i >= 0; i--) {
			if (map_copied[i][j] != 0) {
				cur_block_cnt++;
				if (i < H - 1) {
					temp_i = i;
					while (1) {
						if (map_copied[temp_i + 1][j] != 0)
							break;
						else {
							map_copied[temp_i + 1][j] = map_copied[temp_i][j];
							map_copied[temp_i][j] = 0;
							temp_i++;
							if (temp_i == H - 1)
								break;
						}
					}
				}
			}
		}
	}
	return;
}