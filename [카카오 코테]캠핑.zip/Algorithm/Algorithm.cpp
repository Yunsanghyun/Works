#include <vector>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

// ������ǥ ����
vector<pair<int, int>> compress_arr;
// ���຤�� �迭
int matrix[5001][5001];

// �κ��� �迭 ����
void partial_arr(int line, int row) {
    //vector<int> temp;
    for (int i = 0; i <= line; i++) {
        //matrix.push_back(temp);
        for (int j = 0; j <= row; j++) {
            matrix[i][j] = 0;
        }
    }

    for (int i = 0; i < compress_arr.size(); i++) {
        matrix[compress_arr[i].first][compress_arr[i].second] = 1;
    }

    for (int i = 0; i <= line; i++) {
        for (int j = 0; j <= row; j++) {
            if (i - 1 >= 0 && j - 1 >= 0)
                matrix[i][j] += matrix[i - 1][j] + matrix[i][j - 1] - matrix[i - 1][j - 1];
            else if (i - 1 >= 0 && j - 1 < 0)
                matrix[i][j] += matrix[i - 1][j];
            else if (i - 1 < 0 && j - 1 >= 0)
                matrix[i][j] += matrix[i][j - 1];
        }
    }
}

// ������ǥ ����
pair<int, int> compress() {
    sort(compress_arr.begin(), compress_arr.end());
    int max_line = compress_arr[0].first;
    int compress_line = 0;
    int temp_line = 0;
    for (int i = 0; i < compress_arr.size(); i++) {
        if (compress_arr[i].first == max_line) {
            compress_arr[i].first = compress_line;
        }
        else if (compress_arr[i].first > max_line) {
            max_line = compress_arr[i].first;
            compress_line++;
            compress_arr[i].first = compress_line;
        }

        temp_line = compress_arr[i].first;
        compress_arr[i].first = compress_arr[i].second;
        compress_arr[i].second = temp_line;
    }

    sort(compress_arr.begin(), compress_arr.end());
    int max_row = compress_arr[0].first;
    int compress_row = 0;
    int temp_row = 0;
    for (int i = 0; i < compress_arr.size(); i++) {
        if (compress_arr[i].first == max_row) {
            compress_arr[i].first = compress_row;
        }
        else if (compress_arr[i].first > max_row) {
            max_row = compress_arr[i].first;
            compress_row++;
            compress_arr[i].first = compress_row;
        }

        temp_row = compress_arr[i].first;
        compress_arr[i].first = compress_arr[i].second;
        compress_arr[i].second = temp_row;
    }
    sort(compress_arr.begin(), compress_arr.end());

    return { compress_line,compress_row };
}

int solution(int n, vector<vector<int>> data) {
    int cnt = 0;
    int inner_chk = 0;

    pair<int, int> compress_info;
    pair<int, int> cur_p;

    memset(matrix, 0, sizeof(matrix));

    for (int i = 0; i < data.size(); i++) {
        cur_p = { data[i][0], data[i][1] };
        compress_arr.push_back(cur_p);
    }

    // ����迭�� ��,����
    compress_info = compress();
    partial_arr(compress_info.first, compress_info.second);

    // ��Ⱑ �ִ� ��ǥ �ΰ��� �����ϴµ�, �� ��ǥ ��, �ϳ��� 1 ���̸�ŭ ���� ī��Ʈ 1
    // �ƴϸ�, �κ����� ���ؼ� ī��Ʈ

    pair<int, int> ref_p;
    pair<int, int> select_p;

    pair<int, int> start_p;
    pair<int, int> end_p;

    for (int i = 0; i < compress_arr.size(); i++) {
        ref_p = compress_arr[i];
        for (int j = i + 1; j < compress_arr.size(); j++) {
            select_p = compress_arr[j];

            if (ref_p.first == select_p.first || ref_p.second == select_p.second)
                continue;

            start_p.first = min(ref_p.first, select_p.first);
            start_p.second = min(ref_p.second, select_p.second);
            end_p.first = max(ref_p.first, select_p.first);
            end_p.second = max(ref_p.second, select_p.second);

            if (abs(start_p.first - end_p.first) == 0 || abs(start_p.second - end_p.second) == 0) {
                continue;
            }
            else if (abs(start_p.first - end_p.first) == 1 || abs(start_p.second - end_p.second) == 1) {
                cnt++;
                continue;

            }
            else {
                if (matrix[end_p.first - 1][end_p.second - 1] -
                    matrix[start_p.first][end_p.second - 1] -
                    matrix[end_p.first - 1][start_p.second] +
                    matrix[start_p.first][start_p.second] == 0) {
                    cnt++;
                    continue;
                }
            }
        }
    }

    compress_arr.clear();
    return cnt;
}