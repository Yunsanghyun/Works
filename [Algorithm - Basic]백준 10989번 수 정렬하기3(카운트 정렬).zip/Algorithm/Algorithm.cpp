#include <iostream>
#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>

using namespace std;

int cnt[10001];
vector<pair<int, int>> num;

int main() {
	int n = 0;
	int temp = 0;
	memset(cnt, 0, sizeof(cnt));
	scanf("%d", &n);

	for (int i = 1; i <= n; i++) {
		scanf("%d", &temp);
		cnt[temp] += 1;
	}

	for (int i = 1; i <= 10000; i++) {
		num.push_back({ i,cnt[i] });
	}

	for (int i = 0; i < num.size(); i++) {
		for (int j = 0; j < num[i].second; j++) {
			printf("%d\n", num[i].first);
		}
	}
	return 0;
}
