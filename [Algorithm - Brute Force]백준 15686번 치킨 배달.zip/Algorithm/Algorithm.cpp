#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

std::vector<std::pair<int, int>> chicken_location;
std::vector<std::pair<int, int>> home_location;
std::vector<std::pair<int, int>> select_chicken;
std::vector<int> visit_chicken;

int matrix[51][51];
int cur_home_num = 0;
int cur_market_num = 0;
int target_market_num = 0;
int market_cnt = 0;

int temp_distance = 0;
int min_distance = 1e9;

int distance(std::vector<std::pair<int, int>>& chicken_location);
void cal(int start);
void print_f(std::vector<std::pair<int, int>>& p);

int main() {
    int city_size = 0;

    // �Է��� �ް�, ���� ���� ġŲ�� ��ǥ�� �ľ�
    scanf("%d %d", &city_size, &target_market_num);
    for (int i = 0; i < city_size; i++) {
        for (int j = 0; j < city_size; j++) {
            scanf("%d", &matrix[i][j]);
            if (matrix[i][j] == 2) {
                visit_chicken.push_back(0);
                chicken_location.push_back(std::make_pair(i, j));
            }
            else if (matrix[i][j] == 1) {
                home_location.push_back(std::make_pair(i, j));
            }
        }
    }

    cur_market_num = chicken_location.size();
    cur_home_num = home_location.size();

    //print_f(chicken_location);

    cal(0);

    printf("%d", min_distance);

    return 0;
}

void cal(int start) {
    // ġŲ�� ����� ������, ������ ġŲ�Ÿ��� ����
    if (market_cnt == target_market_num) {
        //print_f(select_chicken);
        temp_distance = distance(select_chicken);
        //printf("�Ÿ��� %d\n", temp_distance);
        //printf("\n");

        if (min_distance > temp_distance)
            min_distance = temp_distance;

        return;
    }
    for (int i = start; i < cur_market_num; i++) {
        if (visit_chicken[i] == 0) {
            visit_chicken[i] = 1;
            select_chicken.push_back(chicken_location[i]);
            market_cnt++;

            cal(start);

            visit_chicken[i] = 0;
            select_chicken.pop_back();
            start++;
            market_cnt--;
        }
    }
}

int distance(std::vector<std::pair<int, int>>& chicken_location) {
    int temp = 0;
    int min = 1e9;
    int chicken_distance = 0;

    // �� �������� ġŲ�������� �ּҰŸ��� ����
    for (int i = 0; i < home_location.size(); i++) {
        min = 1e9;
        for (int j = 0; j < chicken_location.size(); j++) {
            temp = std::abs(home_location[i].first - chicken_location[j].first) +
                std::abs(home_location[i].second - chicken_location[j].second);
            //printf("�� %d %d���� ġŲ�� %d %d���� �Ÿ� = %d \n", home_location[i].first, home_location[i].second, chicken_location[j].first, chicken_location[j].second, temp);
            if (min > temp) {
                min = temp;
            }
        }//printf("�ּҰŸ��� %d\n",min);
        chicken_distance += min;
    }
    return chicken_distance;
}

void print_f(std::vector<std::pair<int, int>>& p) {
    std::vector<std::pair<int, int>>::iterator itr;
    for (itr = p.begin(); itr != p.end(); itr++) {
        printf("%d %d / ", (*itr).first, (*itr).second);
    }
    printf("\n");
}
