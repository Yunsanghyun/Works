#include <stdio.h>
#include "NameCard.h"

void list_init(List* list) {
	for (int i = 0; i < List_len; i++) {
		list->list_arr[i] = 0;
	}
	list->num_of_data = 0;
}

void list_add(List* list, char* name, char* phone) {
	int cnt = list->num_of_data;
	list->list_arr[cnt] = MakeNameCard(name, phone);
	list->num_of_data++;
}
int find_name(List* list, char* name) {
	for (int i = 0; i < List_len; i++) {
		if (NameCompare(list->list_arr[i], name) == 0) {
			return i;
		}
	}
	printf("ã������ ����� �����ϴ�. \n");
	return -1;
}
void print_info(List* list, char* name) {
	int num = find_name(list, name);
	if (num == -1) {
		return;
	}
	ShowNameCardInfo(list->list_arr[num]);
}
void change_phone(List* list, char* name, char* phone) {
	int num = find_name(list, name);
	if (num == -1) {
		return;
	}
	ChangePhoneNum(list->list_arr[num],phone);
}
void delete_info(List* list, char* name) {
	int num = find_name(list, name);
	if (num == -1) {
		return;
	}
	free(list->list_arr[num]);
	for (int i = num; i < List_len; i++) {
		list->list_arr[i] = list->list_arr[i + 1];
	}
	list->num_of_data--;
}

void print_all(List* list) {
	for (int i = 0; i < list->num_of_data; i++) {
		printf("�̸��� :");
		for (int j = 0; j < 30; j++) {
			printf("%c", list->list_arr[i]->name[j]);
			if (list->list_arr[i]->name[j] == '\0')
				break;
		}
		printf("\n��ȭ��ȣ�� :");
		for (int j = 0; j < 30; j++) {
			printf("%c", list->list_arr[i]->phone[j]);
			if (list->list_arr[i]->phone[j] == '\0')
				break;
		}
		printf("\n");
	}
}

NameCard* MakeNameCard(char* name, char* phone) {
	NameCard* temp = (NameCard*)malloc(sizeof(NameCard));
	
	for (int i = 0; i < 30; i++) {
		temp->name[i] = name[i];
		if (name[i] == '\0')
			break;
	}
	for (int i = 0; i < 30; i++) {
		temp->phone[i] = phone[i];
		if (phone[i] == '\0')
			break;
	}
	return temp;
}
void ShowNameCardInfo(NameCard* pcard) {
	printf("�̸��� :");
	for (int i = 0; i < 30; i++) {
		printf("%c", pcard->name[i]);
		if (pcard->name[i] == '\0')
			break;
	}
	printf("\n");
	printf("��ȭ��ȣ�� :");
	for (int i = 0; i < 30; i++) {
		printf("%c", pcard->phone[i]);
		if (pcard->phone[i] == '\0')
			break;
	}
	printf("\n");
}
int NameCompare(NameCard* pcard, char* name) {
	for (int i = 0; i < 30; i++) {
		if (pcard->name[i] != name[i]) {
			return -1;
		}
		if (pcard->name[i] == '\0')
			break;
	}
	return 0;
}
void ChangePhoneNum(NameCard* pcard, char* phone) {
	for (int i = 0; i < 30; i++) {
		pcard->phone[i] = phone[i];
	}
}