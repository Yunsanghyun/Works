#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ListStack.h"

void SInit(List * list){
	list->head = NULL;
	list->index = -1;
}

void SPush(List * list, Data data){
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->data = data;


	newNode->next = list->head;
	list->head = newNode;
	list->index++;
}

// ��������� 1, �Ⱥ�������� 0
int SEmpty(List* list) {
	return list->head == NULL;
}

Data SPop(List * list){
	Node* temp_node;
	Data temp_data;

	temp_node = list->head;
	temp_data = list->head->data;

	list->head = list->head->next;

	free(temp_node);
	list->index--;

	return temp_data;
}

Data SPeek(List* list){
	return list->head->data;
}
