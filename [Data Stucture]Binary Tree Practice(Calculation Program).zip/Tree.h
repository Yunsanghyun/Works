#ifndef __TREE
#define __TREE

#include <stdio.h>
#include <stdlib.h>

typedef int Data;
typedef void (*function)(Data data);

typedef struct TreeNode {
	Data data;
	struct TreeNode* left;
	struct TreeNode* right;
}TNode;

void Treeinit(TNode* nd);
TNode* MakeNode(Data data);
Data GetData(TNode* nd);
void SetData(TNode* nd, Data data);
TNode* GetLeftNode(TNode* nd);
TNode* GetRightNode(TNode* nd);
void ConnectLeftNode(TNode* nd, TNode* left);
void ConnectRightNode(TNode* nd, TNode* right);
void DeleteNode(TNode* nd);

void PreOrder(TNode* nd, function funcptr);
void MiddleOrder(TNode* nd,function funcptr);
void BackOrder(TNode* nd, function funcptr);
int Calculate_Tree(TNode* nd);
#endif 