#include <stdio.h>
#include <stdlib.h>
#include "Tree.h"

void Treeinit(TNode* nd) {
	nd->left = NULL;
	nd->right = NULL;
}
TNode* MakeNode(Data data) {
	TNode* new = (TNode*)malloc(sizeof(TNode));
	Treeinit(new);
	new->data = data;

	return new;
}
Data GetData(TNode* nd) {
	return nd->data;
}
void SetData(TNode* nd, Data data) {
	nd->data = data;
}
TNode* GetLeftNode(TNode* nd) {
	return nd->left;
}
TNode* GetRightNode(TNode* nd) {
	return nd->right;
}
void ConnectLeftNode(TNode* nd, TNode* left) {
	nd->left = left;
}
void ConnectRightNode(TNode* nd, TNode* right) {
	nd->right = right;
}
void PreOrder(TNode* nd, function funcptr) {
	if (nd == NULL) {
		return; 
	}
	funcptr(nd->data);
	PreOrder(nd->left, funcptr);
	PreOrder(nd->right, funcptr);
}
void MiddleOrder(TNode* nd, function funcptr) {
	if (nd == NULL) {
		return;
	}
	if (nd->left != NULL || nd->right != NULL) {
		printf("(");
	}

	MiddleOrder(nd->left, funcptr);
	funcptr(nd->data);
	MiddleOrder(nd->right, funcptr);
	
	if (nd->left != NULL || nd->right != NULL) {
		printf(")");
	}
	
	return;
}
void BackOrder(TNode* nd, function funcptr) {
	if (nd == NULL) {
		return;
	}
	BackOrder(nd->left, funcptr);
	BackOrder(nd->right, funcptr);
	funcptr(nd->data);
}
void DeleteNode(TNode* nd) {
	if (nd == NULL)
		return;

	DeleteNode(nd->left);
	DeleteNode(nd->right);
	free(nd);
}

int Calculate_Tree(TNode* nd) {
	if (nd->left == NULL && nd->right == NULL) {
		return nd->data;
	}

	int op1 = Calculate_Tree(nd->left) - '0';
	int op2 = Calculate_Tree(nd->right) - '0';

	int result = 0;
	
	switch (nd->data) {
	case '+':
		result = op1 + op2;
		break;
	case '-':
		result = op1 - op2;
		break;
	case '*':
		result = op1 * op2;
		break;
	case '/':
		result = op1 / op2;
		break;
	}

	return result + '0';

}