#ifndef __CALCULATION_H__
#define __CALCULATION_H__

int calculation(char* arr);

#endif