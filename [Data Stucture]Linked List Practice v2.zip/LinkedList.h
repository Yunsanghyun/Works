#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stdio.h>

typedef struct Linked_List List;

struct Linked_List {
	int data;
	List* next_list;
};


#endif