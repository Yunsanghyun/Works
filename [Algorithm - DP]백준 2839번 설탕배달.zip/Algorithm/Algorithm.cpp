#include <iostream>
#include <cstring>

int dp[5001];

int main() {
	memset(dp, 0, sizeof(dp));

	int N = 0;
	scanf("%d", &N);
	
	dp[3] = 1;
	dp[5] = 1;

	for (int i = 0; i <= N; i++) {
		if (dp[i] != 0) {
			if(dp[i + 3] == 0)
				dp[i + 3] = dp[i] + 1;
			else {
				if(dp[i + 3] > dp[i] + 1)
					dp[i + 3] = dp[i] + 1;
			}
			
			if (dp[i + 5] == 0)
				dp[i + 5] = dp[i] + 1;
			else {
				if (dp[i + 5] > dp[i] + 1)
					dp[i + 5] = dp[i] + 1;
			}
		}
	}

	/*printf("\n");
	for (int i = 0; i <= N; i++) {
		printf("%d\n",dp[i]);
	}
	printf("\n");*/

	if (dp[N] == 0)
		dp[N] = -1;
	printf("%d", dp[N]);

	return 0;
}