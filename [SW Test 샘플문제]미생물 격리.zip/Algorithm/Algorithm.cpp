#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

int move(int target_time);
int edge_chk(std::pair<int, int> cur_p);
void print_f();

// �̻��� ��
int num_matrix[101][101];
// �ִ밪
int max_matrix[101][101];
// �̵�����
int direct_matrix[101][101];

int N = 0;
int M = 0;
int K = 0;

std::vector<std::pair<std::pair<int,int>, std::pair<int, int>>> group_v;
std::vector<std::pair<int, int>> value{ {0,0},{-1,0},{1,0}, {0,-1}, {0,1} };

int main() {
	int test_case = 0;
	int temp_x, temp_y, temp_num, temp_direct = 0;
	int total_num = 0;
	group_v.clear();

	scanf("%d", &test_case);
	
	for (int i = 1; i <= test_case; i++) {
		memset(num_matrix, 0, sizeof(num_matrix));
		memset(max_matrix, 0, sizeof(max_matrix));
		memset(direct_matrix, 0, sizeof(direct_matrix));
		group_v.clear();

		scanf("%d %d %d", &N, &M, &K);

		for (int j = 0; j < K; j++) {
			scanf("%d %d %d %d", &temp_x, &temp_y, &temp_num, &temp_direct);
			group_v.push_back({{temp_x,temp_y}, { temp_num,temp_direct }});
		}

		total_num = move(M);
		printf("#%d %d\n", i,total_num);
	}
	return 0;
}

int move(int target_time) {
	// ��ǥ
	std::pair<int, int> cur_p;
	int cur_direct = 0;
	int cur_num = 0;
	std::pair<int, int> next_p;
	int next_direct = 0;
	int next_num = 0;

	int temp_x, temp_y, temp_num, temp_direct = 0;
	int total_num = 0;

	for (int i = 1; i <= M; i++) {
		//printf("%d��° �̵�\n", i);
		memset(num_matrix, 0, sizeof(num_matrix));
		memset(direct_matrix, 0, sizeof(direct_matrix));
		memset(max_matrix, 0, sizeof(max_matrix));

		// ���� �׸�
		for (int j = 0; j < group_v.size(); j++) {
			cur_p = { group_v[j].first.first, group_v[j].first.second };
			cur_direct = group_v[j].second.second;
			cur_num = group_v[j].second.first;

			next_p = { cur_p.first + value[cur_direct].first, cur_p.second + value[cur_direct].second };
			next_direct = cur_direct;
			next_num = cur_num;

			//printf("%d %d %d %d / %d %d %d %d\n", cur_p.first, cur_p.second, cur_num, cur_direct, next_p.first, next_p.second, next_num, next_direct);

			// ������ġ�� �����ڸ��� ��,
			if (edge_chk(next_p)) {
				next_num = next_num / 2;
				group_v[j].second.first = next_num;
				if (next_direct == 1)
					next_direct = 2;
				else if (next_direct == 2)
					next_direct = 1;
				else if (next_direct == 3)
					next_direct = 4;
				else
					next_direct = 3;
			}

			// ���ο� ��ġ�� �̻����� ������
			if (num_matrix[next_p.first][next_p.second] == 0) {
				num_matrix[next_p.first][next_p.second] = next_num;
				max_matrix[next_p.first][next_p.second] = next_num;
				direct_matrix[next_p.first][next_p.second] = next_direct;
			}
			// ���ο� ��ġ�� �̻����� ������
			else {
				num_matrix[next_p.first][next_p.second] += next_num;
				// �̻��� ���� ���� ���� �̵������� ����
				if (max_matrix[next_p.first][next_p.second] < next_num) {
					max_matrix[next_p.first][next_p.second] = next_num;
					direct_matrix[next_p.first][next_p.second] = next_direct;
				}
			}			
		}

		// �׷��� ���� ������ ������ ������Ʈ��
		if (i < M) {
			group_v.clear();
			for (int j = 0; j < N; j++) {
				for (int k = 0; k < N; k++) {
					// �̻����� ���� ��,
					if (num_matrix[j][k] != 0) {
						temp_num = num_matrix[j][k];
						temp_direct = direct_matrix[j][k];
						group_v.push_back({ {j,k},{temp_num,temp_direct} });
					}
				}
			}
		}
		//print_f();
	}

	for (int i = 0; i < group_v.size(); i++) {
		total_num += group_v[i].second.first;
	}

	return total_num;
}

int edge_chk(std::pair<int, int> cur_p) {
	if (cur_p.first == 0 || cur_p.first == (N - 1)) {
		return 1;
	}
	if (cur_p.second == 0 || cur_p.second == (N - 1)) {
		return 1;
	}
	return 0;
}

void print_f() {
	printf("\nnum\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d ", num_matrix[i][j]);
		}
		printf("\n");
	}
	printf("\ndirect\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d ", direct_matrix[i][j]);
		}
		printf("\n");
	}
	printf("\nmax\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d ", max_matrix[i][j]);
		}
		printf("\n");
	}
}
