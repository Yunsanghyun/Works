#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>

using namespace std;

int main() {
	int A, B = 0;

	while (scanf("%d %d", &A, &B) != EOF) {
		cout << A + B << endl;
	}
	
	return 0;
}