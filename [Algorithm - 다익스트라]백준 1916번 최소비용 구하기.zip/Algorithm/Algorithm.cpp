#include <iostream>
#include <ctime>
#include <queue>
#include <cstring>
#include <vector>
#include <string>

void dijkstra(int start_city);

int short_cut[1001];
int dist_info[1001][1001];
int N, M = 0;
std::vector<int> connect_city[1001];

int main() {
	int start, end, dist = 0;
	int departure, arrival = 0;
	scanf("%d", &N);
	scanf("%d", &M);

	memset(dist_info, 0, sizeof(dist_info));

	// ���������� ��ġ�� ���� ª�� ������ ���ܵ�
	for (int i = 0; i < M; i++) {
		scanf("%d %d %d", &start, &end, &dist);
		
		if(dist_info[start][end] == 0)
			dist_info[start][end] = dist;
		else {
			dist_info[start][end] = std::min(dist_info[start][end], dist);
		}

		connect_city[start].push_back(end);
	}

	scanf("%d %d", &departure, &arrival);

	dijkstra(departure);

	printf("%d\n", short_cut[arrival]);

	return 0;
}

#define pairs std::pair<int, int>
#define INF 1e9
void dijkstra(int start_city) {
	// ù��° �Ÿ�, �ι�° ��ġ
	std::priority_queue<pairs, std::vector<pairs>, std::greater<pairs>> que;
	int cur_city = 0;
	int cur_dist = 0;

	for (int i = 1; i <= N; i++) {
		if (i != start_city) {
			que.push({ INF,i });
			short_cut[i] = INF;
		}
	}
	que.push({0, start_city});
	short_cut[start_city] = 0;

	//printf("������ġ %d\n", start_city);
	while (que.empty() == 0) {
		cur_city = que.top().second;
		cur_dist = que.top().first;
		que.pop();

		/*printf("%d %d\n", cur_city, cur_dist);
		for (int i = 1; i <= N; i++) {
			printf("%d ", short_cut[i]);
		}
		printf("\n");*/

		for (int i = 0; i < connect_city[cur_city].size(); i++) {
			if (short_cut[connect_city[cur_city][i]] >= short_cut[cur_city] + dist_info[cur_city][connect_city[cur_city][i]]) {
				short_cut[connect_city[cur_city][i]] = short_cut[cur_city] + dist_info[cur_city][connect_city[cur_city][i]];
				que.push({ short_cut[connect_city[cur_city][i]], connect_city[cur_city][i] });
			}
		}
	}
	return;
}