#include <iostream>

using namespace std;

int main() {
	int A, B, V = 0;
	int day = 0;
	int height = 0;
	scanf("%d %d %d", &A, &B, &V);

	if ((V - A) % (A - B) == 0) {
		day = (V - A) / (A - B);
		day++;
	}
	else {
		day = (V - A) / (A - B);
		day += 2;
	}

	printf("%d", day);
	return 0;
}
