#include <iostream>
#include <cmath>
#include <vector>
#include <cstring>

void DFS(int start_num);
void print_f();

std::vector<int> matrix[10001];
int visit[10001];
int cnt[10001];

int N, M = 0;
int max_cnt = 0;

int main() {
	int temp_a, temp_b = 0;

	scanf("%d %d", &N, &M);
	memset(matrix, 0, sizeof(matrix));
	memset(visit, 0, sizeof(visit));
	memset(cnt, 0, sizeof(cnt));

	for (int i = 0; i < M; i++) {
		scanf("%d %d", &temp_a, &temp_b);
		matrix[temp_a].push_back(temp_b);
	}

	for (int i = 1; i <= N; i++) {
		memset(visit, 0, sizeof(visit));
		DFS(i);
		print_f();
	}

	for (int i = 1; i <= N; i++) {
		if (max_cnt == cnt[i])
			printf("%d ", i);
	}

	return 0;
}

void DFS(int start_num) {
	printf("%d�� ��ǻ�� Ž�� �� \n", start_num);
	visit[start_num] = 1;
	cnt[start_num] += 1;
	if (max_cnt < cnt[start_num])
		max_cnt = cnt[start_num];
	
	for (int i = 0; i < matrix[start_num].size(); i++) {
		int new_num = matrix[start_num][i];
		// ����� ��ǻ��
		if (visit[new_num] == 0) {
			DFS(new_num);
		}
	}
	return;
}

void print_f() {
	printf("visit\n");
	for (int i = 1; i <= N; i++) {
		printf("%d ", visit[i]);
	}
	printf("\n");

	printf("cnt\n");
	for (int i = 1; i <= N; i++) {
		printf("%d ", cnt[i]);
	}
	printf("\n");
}