#include <iostream>
#include <string>
#include <stack>

using namespace std;
stack<int> s;

int main() {
	int k = 0;
	int money = 0;
	int sum = 0;
	scanf("%d", &k);

	for (int i = 0; i < k; i++) {
		scanf("%d", &money);
		if (money == 0)
			s.pop();
		else
			s.push(money);
	}

	while (s.empty() == 0) {
		sum += s.top();
		s.pop();
	}

	printf("%d", sum);
	return 0;
}