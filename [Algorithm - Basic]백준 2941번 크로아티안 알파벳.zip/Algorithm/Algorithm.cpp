#include <iostream>
#include <vector>
#include <cstring>
#include <string>
#include <algorithm>

using namespace std;

int chk(string ref_str, int no, string com_str) {
	for (int i = 0; i < com_str.size(); i++) {
		if (no + i >= ref_str.size())
			return 0;

		if (ref_str[no + i] != com_str[i]) {
			return 0;
		}
	}
	return 1;
}

int main() {
	int sum = 0;
	int cnt = 0;
	string str;
	cin >> str;

	string croatia[8] = { "c=","c-","dz=","d-","lj","nj","s=","z="};

	for (int i = 0; i < str.size(); i++) {
		for (int j = 0; j < 8; j++) {
			if (chk(str, i, croatia[j])) {
				cnt++;
				i += croatia[j].size() - 1;
				sum += croatia[j].size();
				break;
			}
		}
	}

	printf("%d\n", str.size() - sum + cnt);

	return 0;
}
