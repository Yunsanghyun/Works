#include <iostream>
#include <vector>
#include <cstring>
#include <string>
#include <algorithm>

using namespace std;
// �빮�� 65 ~ 90 -> 0 ~ 25
// �ҹ��� 97 ~ 122 -> 32 ~ 57

int main() {
	pair<int,int> cnt[30];
	string str;
	cin >> str;

	memset(cnt, 0, sizeof(cnt));

	for (int i = 0; i < str.size(); i++) {
		if (str[i] >= 97)
			str[i] -= 32;

		cnt[str[i] - 65].first += 1;
		cnt[str[i] - 65].second = str[i];
	}

	sort(cnt, cnt + 30);
	if (cnt[28].first == cnt[29].first) {
		printf("?");
	}
	else {
		printf("%c", cnt[29].second);
	}

	return 0;
}