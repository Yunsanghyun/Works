#include <string>
#include <vector>
#include <iostream>

using namespace std;

int str_compress(string str, int part_len) {
    int cnt = 1;
    int comp_str_len = 0;
    int cur_str_len = 0;
    string cur_str;
    string comp_str;
    string::iterator str_itr;

    string temp_cur_str;
    string temp_comp_str;
    string temp_cnt_str;

    printf("�κ� ���ڿ� ���̰� %d�϶�\n", part_len);

    for (int i = 0; i < str.size(); i++)
        cur_str.push_back(str[i]);

    // 1. ���๮�ڿ��� ���̸�ŭ ���� �ְ�, ���� ���ڿ����� ����
    for (int i = 0; i < part_len; i++) {
        str_itr = cur_str.begin();
        comp_str.push_back(cur_str.front());
        cur_str.erase(str_itr);
    }

    while (1) {
        comp_str_len = comp_str.size();
        temp_cur_str.clear();
        temp_comp_str.clear();

        // ���� ���ڿ��� ���� ��,
        if (cur_str.size() >= part_len) {
            // 2. ���� ���ڿ� �չ��ڿ��̶� ���๮�ڿ� �޹��ڿ� ��
            for (int i = 0; i < part_len; i++) {
                temp_cur_str.push_back(cur_str[i]);
                temp_comp_str.push_back(comp_str[comp_str_len - part_len + i]);
            }

            // 3. ������ ���� ���ڿ� ���� ��, ī��Ʈ ��
            if (temp_cur_str.compare(temp_comp_str) == 0) {
                cnt++;
                for (int i = 0; i < part_len; i++) {
                    str_itr = cur_str.begin();
                    cur_str.erase(str_itr);
                }
                if (cnt == 2) {
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, cnt + 48);
                }
                else if( 2 < cnt && cnt < 10) {
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, cnt + 48);
                }
                else if (cnt == 10) {
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, cnt / 10 + 48);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, cnt % 10 + 48);
                }
                else if (10 < cnt && cnt < 99) {
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, cnt / 10 + 48);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, cnt % 10 + 48);
                }
                else if (cnt == 100) {
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, cnt / 100 + 48);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, (cnt & 100) / 10 + 48);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, (cnt & 100) % 10 + 48);

                }
                else if (100 < cnt && cnt < 999) {
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, cnt / 100 + 48);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, (cnt & 100) / 10 + 48);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, (cnt & 100) % 10 + 48);
                }
                else if (cnt == 1000) {
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.erase(str_itr - part_len - 1);
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, '1');
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, '0');
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, '0');
                    str_itr = comp_str.end();
                    comp_str.insert(str_itr - part_len, '0');
                }
            }
            // 4. �ٸ��� ���� ���ڿ� �����ϰ�,
            else {
                cnt = 1;
                for (int i = 0; i < part_len; i++) {
                    str_itr = cur_str.begin();
                    comp_str.push_back(cur_str.front());
                    cur_str.erase(str_itr);
                }
            }
        }
        else {
            cur_str_len = cur_str.size();
            for (int i = 0; i < cur_str_len; i++) {
                str_itr = cur_str.begin();
                comp_str.push_back(cur_str.front());
                cur_str.erase(str_itr);
            }
            break;
        }
    }
    std::cout << "���๮�ڿ� " << comp_str << std::endl;
    return comp_str.size();
}

// �ߺ��Ǵ� ���ڿ��� �����ؼ� �ִܱ��̸� ����
// ������ ���ڿ� ���� 2 ~ ���� ���ڿ� ����
int main(void) {
    int answer = 0;
    int cur_len = 0;
    int min_len = 1e9;

    string s[5] = { "abababababababababababababababab",
        "ababcdcdababcdcd",
        "abcabcdede",
        "abcabcabcabcdededededede",
        "xababcdcdababcdcd" };

    for (int i = 0; i < 5; i++) {
        string cur_str = s[i];
        min_len = 1e9;

        if (cur_str.size() > 1) {
            for (int j = 1; j <= cur_str.size() / 2; j++) {
                cur_len = str_compress(cur_str, j);
                if (min_len > cur_len)
                    min_len = cur_len;
            }
        }
        else
            min_len = 1;
        std::cout << s[i] << "�� ��, �ּұ��� " << min_len << std::endl;
    }
    return 0;
}