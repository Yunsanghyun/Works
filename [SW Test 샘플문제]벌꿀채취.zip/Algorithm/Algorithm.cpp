#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>

void chk_max_honey();
void DFS(std::vector<int>& cur_select, int ele_cnt);
void worker_select();
void second_worker_select();

std::vector<int> first_select;
std::vector<int> second_select;

int visit[11][11];
int map[11][11];

int N, M, C = 0;
int max_total_honey_sum = 0;

int main() {
	int test_case = 0;

	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		memset(map, 0, sizeof(map));
		memset(visit, 0, sizeof(visit));

		max_total_honey_sum = 0;
		
		scanf("%d %d %d", &N, &M, &C);

		for (int j = 0; j < N; j++) {
			for (int k = 0; k < N; k++) {
				scanf("%d", &map[j][k]);
			}
		}

		worker_select();

		printf("#%d %d\n", i, max_total_honey_sum);
	}
	return 0;
}

void worker_select() {
	for (int i = 0; i < N; i++) {
		for (int j = 0; j <= N - M; j++) {
			//memset(visit, 0, sizeof(visit));
			first_select.clear();

			// 1�� �۾����� ����
			for (int k = 0; k < M; k++) {
				first_select.push_back(map[i][j + k]);
				visit[i][j + k] = 1;
				//printf("1�� �۾��� ������ǥ %d %d\n", i, j + k);
			}
			second_worker_select();
		}
	}
}

void second_worker_select() {
	for (int i = 0; i < N; i++) {
		for (int j = 0; j <= N - M; j++) {
			if (visit[i][j] == 0) {
				second_select.clear();

				// 2�� �۾����� ����
				for (int k = 0; k < M; k++) {
					second_select.push_back(map[i][j + k]);
					//printf("2�� �۾��� ������ǥ %d %d\n", i, j + k);
				}
				chk_max_honey();
			}
		}
	}
}

int max_honey_sum = 0;
int visit_m[6];
int cnt = 0;

// 1���� 2�� �۾��� ��� M���� ������
void chk_max_honey() {
	int first_honey_sum = 0;
	int second_honey_sum = 0;
	int total_honey_sum = 0;

	max_honey_sum = 0;
	for (int i = 1; i <= M; i++) {
		memset(visit_m, 0, sizeof(visit_m));
		cnt = 0;
		DFS(first_select, i);
	}
	first_honey_sum = max_honey_sum;

	max_honey_sum = 0;
	for (int i = 1; i <= M; i++) {
		memset(visit_m, 0, sizeof(visit_m));
		cnt = 0;
		DFS(second_select, i);
	}
	second_honey_sum = max_honey_sum;
	
	total_honey_sum = first_honey_sum + second_honey_sum;
	if (max_total_honey_sum < total_honey_sum)
		max_total_honey_sum = total_honey_sum;
}

std::vector<int> dfs_v;
int temp_sum = 0;
int honey_sum = 0;

void DFS(std::vector<int>& cur_select, int ele_cnt) {
	if (cnt == ele_cnt) {
		temp_sum = 0;
		honey_sum = 0;
		for (int i = 0; i < dfs_v.size(); i++) {
			temp_sum += dfs_v[i];
			honey_sum += std::pow(dfs_v[i], 2);
		}

		if (temp_sum > C)
			return;
		else {
			if (max_honey_sum < honey_sum)
				max_honey_sum = honey_sum;
		}
		return;
	}

	for (int i = 0; i < M; i++) {
		if (visit_m[i] == 0) {
			visit_m[i] = 1;
			dfs_v.push_back(cur_select[i]);
			cnt++;

			DFS(cur_select,ele_cnt);

			visit_m[i] = 0;
			dfs_v.pop_back();
			cnt--;
		}
	}
}