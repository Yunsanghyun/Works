#include "Util.h"
#include <iostream>
#include <algorithm>
#include <fstream>

namespace MyExcel {
	Vector::Vector(int _alloc_len) {
		alloc_len = _alloc_len;
		data = new string[alloc_len];
		curr_len = 0;
	}
	Vector::~Vector() {
		if(data)
			delete[] data;
	}
	void Vector::add_data(string _data) {
		if (alloc_len < curr_len) {
			string* temp = new string[alloc_len * 2];
			for (int i = 0; i < curr_len; i++) {
				temp[i] = data[i];
			}
			delete[] data;
			data = temp;
			delete[] temp;
			alloc_len = alloc_len * 2;
		}
		data[curr_len] = _data;
		curr_len++;
	}
	void Vector::delete_data(int index) {
		for (int i = index + 1; i < curr_len; i++) {
			data[i - 1] = data[i];
		}
		curr_len--;
	}
	int Vector::size() {
		return curr_len;
	}
	string Vector::operator[](int i) {
		return data[i];
	}
///////////////////////////////////////////////////
	Stack::Stack() : start(NULL,"") {
		current = &start;
	}
	Stack::~Stack() {
		while (current == &start) {
			Node* prev = current;
			current = current->prev;
			delete prev;
		}
	}
	void Stack::add_data(string s) {
		Node* n = new Node(current, s);
		current = n;
	}
	string Stack::remove_return_data() {
		if (current == &start)
			return "";

		string s = current->s;
		Node* prev = current;
		current = current->prev;
		
		delete prev;
		return s;
	}
	string Stack::return_data() {
		if (current == &start)
			return "";

		return current->s;
	}
	bool Stack::is_empty() {
		if (current == &start)
			return true;
		else
			return false;
	}
//////////////////////////////////////////////////
	NumStack::NumStack() : start(NULL, 0) {
		current = &start;
	}
	NumStack::~NumStack() {
		while (current == &start) {
			Node* prev = current;
			current = current->prev;
			delete prev;
		}
	}
	void NumStack::add_data(double s) {
		Node* n = new Node(current, s);
		current = n;
	}
	double NumStack::remove_return_data() {
		if (current == &start)
			return 0;

		double s = current->s;
		Node* prev = current;
		current = current->prev;

		delete prev;
		return s;
	}
	double NumStack::return_data() {
		if (current == &start)
			return 0;

		return current->s;
	}
	bool NumStack::is_empty() {
		if (current == &start)
			return true;
		else
			return false;
	}

	class Table;

	class Cell {
	protected:
		int x, y;
		Table* table;
		string data;
	public:
		virtual string stringify();
		virtual int to_numeric();
		Cell(string _data, int _x, int _y, Table* _table);
	};

	Cell::Cell(string _data, int _x, int _y, Table* _table) 
		: data(_data), x(_x), y(_y), table(_table){}
	string Cell::stringify() {
		return data;
	}
	int Cell::to_numeric() {
		return 0;
	}

	class Table {
	protected:
		int max_row_size, max_col_size;
		Cell*** data_table;
	public:
		Table(int _max_row_size, int _max_col_size);
		~Table();
		// ���ο� �� ���
		void reg_cell(Cell* c, int row, int col);
		// ���� �������� ��ȯ
		int to_numeric(const string& s);
		// �� �� �� ��ȣ�� ���� ȣ��
		int to_numeric(int row, int col);
		// ���� ���ڿ��� ��ȯ�Ѵ�.
		string stringify(const string& s);
		string stringify(int row, int col);

		virtual string print_table() = 0;
	};

	Table::Table(int _max_row_size, int _max_col_size) {
		max_row_size = _max_row_size;
		max_col_size = _max_col_size;

		data_table = new Cell * *[max_row_size];
		for (int i = 0; i < max_row_size; i++) {
			data_table[i] = new Cell *[max_col_size];
			for (int j = 0; j < max_col_size; j++) {
				data_table[i][j] = NULL;
			}
		}
	}
	Table::~Table() {
		for (int i = 0; i < max_row_size; i++) {
			delete[] data_table[i];
			for (int j = 0; j < max_col_size; j++) {
				if(data_table[i][j])
					delete data_table[i][j];
			}
		}
		delete[] data_table;
	}
	void Table::reg_cell(Cell* c, int row, int col) {
		if (data_table[row][col]) {
			delete data_table[row][col];
		}
		data_table[row][col] = c;
	}
	// ���� �������� ��ȯ
	int Table::to_numeric(const string& s) {
		int row = s[0] - 'A';
		int col = atoi(s.c_str() + 1) - 1;
		
		if (data_table[row][col]) {
			return data_table[row][col]->to_numeric();
		}
		return 0;
	}
	// �� �� �� ��ȣ�� ���� ȣ��
	int Table::to_numeric(int row, int col) {
		if (data_table[row][col]) {
			return data_table[row][col]->to_numeric();
		}
		return 0;
	}
	// ���� ���ڿ��� ��ȯ�Ѵ�.
	string Table::stringify(const string& s) {
		int row = s[0] - 'A';
		int col = atoi(s.c_str() + 1) - 1;

		if (data_table[row][col]) {
			return data_table[row][col]->stringify();
		}
		return "";
	}
	string Table::stringify(int row, int col){
		if (data_table[row][col]) {
			return data_table[row][col]->stringify();
		}
		return "";
	}
	std::ostream& operator<<(std::ostream& o, Table& table) {
		o << table.print_table();
		return o;
	}

	class TxtTable : public Table {
	private:
		string repeat_char(int n, char c);
		string col_num_to_str(int n);
	public:
		TxtTable(int row, int col) : Table(row, col) {}
		string print_table();
	};

	string TxtTable::repeat_char(int n, char c) {
		string s = "";
		for (int i = 0; i < n; i++) {
			s.push_back(c);
		}
		return s;
	}
	string TxtTable::col_num_to_str(int n) {
		string s = "";
		if (n < 26) {
			s.push_back('A' + n);
		}
		else {
			char first = 'A' + n / 26 - 1;
			char second = 'A' + n & 26;

			s.push_back(first);
			s.push_back(second);
		}
		return s;
	}
	string TxtTable::print_table() {
		string total_table;

		// ���ڿ� ��, ���� �� ���ڿ��� ���� Ȯ��
		int* col_max_wide = new int[max_col_size];
		for (int i = 0; i < max_col_size; i++) {
			unsigned int max_wide = 2;
			for (int j = 0; j < max_row_size; j++) {
				if (data_table[j][i] && data_table[j][i]->stringify().length() > max_wide) {
					max_wide = data_table[j][i]->stringify().length();
				}
			}
			col_max_wide[i] = max_wide;
		}
		
		total_table += "    ";
		int total_wide = 4;
		for (int i = 0; i < max_col_size; i++) {
			if (col_max_wide[i]) {
				int max_len = std::max(2, col_max_wide[i]);
				total_table += " I " + col_num_to_str(i);
				total_table += repeat_char(max_len - col_num_to_str(i).length(), ' ');

				total_wide += (max_len + 3);
			}
		}

		total_table += "\n";
		for (int i = 0; i < max_row_size; i++) {
			total_table += repeat_char(total_wide, '-');
			total_table += "\n" + std::to_string(i + 1);
			total_table += repeat_char(4 - std::to_string(i + 1).length(), ' ');

			for (int j = 0; j < max_col_size; j++) {
				if (col_max_wide[j]) {
					int max_len = std::max(2, col_max_wide[j]);

					string s = "";
					if (data_table[i][j]) {
						s = data_table[i][j]->stringify(); 
					}
					total_table += " I " + s;
					total_table += repeat_char(max_len - s.length(), ' ');
				}
			}
			total_table += "\n";
		}
		return total_table;
	}

}

int main() {
	MyExcel::TxtTable table(5, 5);
	std::ofstream out("test.txt");

	table.reg_cell(new MyExcel::Cell("Hello ~", 0, 0, &table), 0, 0);
	table.reg_cell(new MyExcel::Cell("C++", 0, 1, &table), 0, 1);

	table.reg_cell(new MyExcel::Cell("Programming", 1, 1, &table), 1, 1);
	std::cout << std::endl << table;
	out << table;

	return 0;
}

