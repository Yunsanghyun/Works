#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#include <algorithm>

#define TRUE 1
#define FALSE 0

void print_f();
void BFS(int start_x, int start_y, int clust_num);
void draw_down();
void destroy(int height, int direction);

int check_range(std::pair<int, int> cur_p);

// ��ǥ, Ŭ����Ʈ ��ȣ
std::pair<std::pair<int, int>, int> float_element[10001];
std::pair<int, int> clust_element[10001];
int float_element_cnt = 0;

char cave[101][101];
int visit[101][101];
int throw_height[101];

int R, C = 0;

int main() {
    int throw_cnt = 0;
    int temp_height = 0;
    
    memset(cave, 0, sizeof(cave));
    memset(throw_height, 0, sizeof(throw_height));

    scanf("%d %d", &R, &C);
    for (int i = 0; i < R; i++) {
        scanf("%s", &cave[i]);
    }
    
    scanf("%d", &throw_cnt);
    for (int i = 1; i <= throw_cnt; i++) {
        scanf("%d", &temp_height);
        throw_height[i] = R - temp_height;
    }
    
    for (int i = 1; i <= throw_cnt; i++) {
        memset(visit, 0, sizeof(visit));
        float_element_cnt = 0;

        destroy(throw_height[i], i % 2);

        /*printf("%d ���̷� ������, ���� \n", throw_height[i]);
        print_f();*/

        int clust_num = 1;
        for (int j = 0; j < R; j++) {
            for (int k = 0; k < C; k++) {
                if (cave[j][k] == 'x' && visit[j][k] == 0) {
                    BFS(j, k, clust_num);
                    clust_num++;

                    /*printf("BFS ó�� \n");
                    print_f();*/
                }
            }
        }

        if (float_element_cnt != 0) {
            draw_down();

            /*printf("�����\n");
            print_f();*/
            memset(float_element, 0, sizeof(float_element));
        }
    }
    
    for (int x = 0; x < R; x++) {
        for (int y = 0; y < C; y++) {
            printf("%c", cave[x][y]);
        }
        printf("\n");
    }
    return 0;
}

void draw_down() {
	int cur_x = 0;
	int cur_y = 0;
    int is_finished = 0;

    while (is_finished == 0) {
        // �ʱ�ȭ
        for (int i = 0; i < float_element_cnt; i++) {
            cur_x = float_element[i].first.first;
            cur_y = float_element[i].first.second;

            cave[cur_x][cur_y] = '.';
            visit[cur_x][cur_y] = 0;
            float_element[i].first.first += 1;
        }
        // ǥ��
        for (int i = 0; i < float_element_cnt; i++) {
            cur_x = float_element[i].first.first;
            cur_y = float_element[i].first.second;

            cave[cur_x][cur_y] = 'x';
            visit[cur_x][cur_y] = 1;
            // ���� ���� �����ϰų�, ���� ���� �ٸ� Ŭ����Ʈ�� �ִ� �̳׶��� ��,
            if (cur_x == R - 1 || (cave[cur_x + 1][cur_y] == 'x' && visit[cur_x + 1][cur_y] != float_element[i].second)) {
                is_finished = 1;
            }
        }
    }   
    return;
}

void destroy(int height, int direction) {
    if (direction == 1) {
        for (int i = 0; i < C; i++) {
            if (cave[height][i] == 'x') {
                cave[height][i] = '.';
                break;
            }
        }
    }
    else {
        for (int i = C - 1; i >= 0; i--) {
            if (cave[height][i] == 'x') {
                cave[height][i] = '.';
                break;
            }
        }
    }
    return;
}

void BFS(int start_x, int start_y, int clust_num) {
    std::queue<std::pair<int, int>> bfs_q;

    std::vector<std::pair<int, int>> check_value{ {-1,0},{1,0}, {0,-1}, {0,1} };
    std::pair<int, int> cur_p;
    std::pair<int, int> next_p;

    memset(clust_element, 0, sizeof(clust_element));

    int is_float = TRUE;
    int clust_element_cnt = 0;

    bfs_q.push({ start_x,start_y });
    while (bfs_q.empty() == 0) {
        cur_p = bfs_q.front();
        bfs_q.pop();

        visit[cur_p.first][cur_p.second] = clust_num;
        clust_element[clust_element_cnt] = cur_p;
        clust_element_cnt++;
        //printf("Ŭ����Ʈ ������Ʈ %d %d / Ŭ����Ʈ ��ȣ %d\n", cur_p.first, cur_p.second, clust_num);

        // Ŭ����Ʈ�� ���߿� ���ִ��� Ȯ��
        if (cur_p.first == R - 1) {
            is_float = FALSE;
        }

        for (int i = 0; i < 4; i++) {
            next_p = { cur_p.first + check_value[i].first , cur_p.second + check_value[i].second };
            // ���� ��, �湮 ���� �̳׶���
            if (check_range(next_p) && visit[next_p.first][next_p.second] == 0) {
                if (cave[next_p.first][next_p.second] == 'x') {
                    visit[next_p.first][next_p.second] = clust_num;
                    bfs_q.push(next_p);           
                }
            }
        }
    }
    // Ŭ����Ʈ�� ���߿� ��������, ���ҵ��� ���� ����
    if (is_float == TRUE) {
        for (int i = 0; i < clust_element_cnt; i++) {
            float_element[i] = {{ clust_element[i].first, clust_element[i].second },clust_num};
        }
        float_element_cnt = clust_element_cnt;
    }
    return;
}

int check_range(std::pair<int, int> cur_p) {
    if (0 <= cur_p.first && cur_p.first < R) {
        if (0 <= cur_p.second && cur_p.second < C) {
            return 1;
        }
    }
    return 0;
}

void print_f() {
    printf("\ncave\n");
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            printf("%c ", cave[i][j]);
        }
        printf("\n");
    }

    printf("\nvisit\n");
    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            printf("%d ", visit[i][j]);
        }
        printf("\n");
    }
}