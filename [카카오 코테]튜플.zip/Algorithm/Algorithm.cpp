#include <string>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

// �־��� ���ڿ����� ���ҵ��� �̾Ƴ�, ���Ϳ� ����
void vector_set(vector<vector<int>>& ele_v, string s) {
    int v_num = 0;
    int cur_num = 0;
    string num;
    vector<int> temp;
    // {}�� �����ϰ�, ,�� ������ ���� ���ͷ�
    ele_v.push_back(temp);

    int i = 0;
    while(s[i] != '\0') {
        //printf("%c\n", s[i]);

        if (s[i] == '{' || s[i] == '}') {
            i++;
            continue;
        }

        if (s[i] == ',' && s[i + 1] == '{') {
            v_num++;
            i++;
            ele_v.push_back(temp);
            continue;
        }

        // ���Ұ� 1 ~ 100000
        else {
            num.clear();
            while (1) {
                if (s[i] == ',')
                    break;
                if (s[i] == '}')
                    break;

                num.push_back(s[i]);
                i++;
            }

            /*for (int i = 0; i < num.size(); i++) {
                printf("%d", num[i] - 48);
            }
            printf("\n");*/

            cur_num = 0;
            for (int i = 0; i < num.size(); i++) {
                cur_num += (num[i] - 48) * std::pow(10, num.size() - 1 - i);
            }
            ele_v[v_num].push_back(cur_num);
            i++;
        }
    }
    return;
}

int main() {
    vector<vector<int>> ele_v;
    // ù���� ������, �ι��� ���͹�ȣ
    vector<pair<int,int>> size_v;
    vector<int> answer;
    int flag = 0;

    // ���� �ִ� �鸸
    // 1 * 10 + 2 * 90 + 3 * 900 + 4* 9000 + 5 * 90000 + 
    string s = "{{20,111},{111}}";

    // ���Ϳ� ���Ҹ� ���� (���� ����� ����)
    vector_set(ele_v, s);

    for (int i = 0; i < ele_v.size(); i++) {
        size_v.push_back({ ele_v[i].size() ,i });
    }
    std::sort(size_v.begin(), size_v.end());

    for (int i = 0; i < size_v.size(); i++) {
        for (int j = 0; j < size_v[i].first; j++) {
            flag = 0;

            for (int k = 0; k < answer.size(); k++) {
                if (answer[k] == ele_v[size_v[i].second][j]) {
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
                answer.push_back(ele_v[size_v[i].second][j]);
        }
    }

    for (int i = 0; i < answer.size(); i++)
        printf("%d ", answer[i]);

    return 0;
}