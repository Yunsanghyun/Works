#include <iostream>
#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>

using namespace std;

int chk_prime(int num) {
	for (int i = 2; i <= sqrt(num); i++) {
		if (num % i == 0)
			return 0;
	}
	return 1;
}

int prime[250001];
int main() {
	int num = 0;
	int cnt = 0;
	memset(prime, 0, sizeof(prime));

	for (int i = 2; i <= 250000; i++) {
		if (chk_prime(i))
			prime[i] = 1;
	}

	while (1) {
		cnt = 0;
		scanf("%d", &num);
		if (num == 0)
			break;

		for (int i = num + 1; i <= 2 * num; i++) {
			if (prime[i] == 1)
				cnt++;
		}

		printf("%d\n", cnt);
	}
	return 0;
}
