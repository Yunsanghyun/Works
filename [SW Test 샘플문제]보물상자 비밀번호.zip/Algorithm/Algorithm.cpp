#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>

void chk_num(std::vector<char>& target_v, int num);
void rotate(std::vector<char>& target_v);
void print_f();

char matrix[30];
std::vector<long long int> num_v;
std::vector<char> vect;

int main() {
	int test_case = 0;
	int N, K = 0;
	int ele_num = 0;

	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		memset(matrix, 0, sizeof(matrix));
		vect.clear();
		num_v.clear();

		scanf("%d %d", &N, &K);
		scanf("%s", &matrix);
		
		ele_num = N / 4;

		for (int j = 0; j < N; j++) {
			vect.push_back(matrix[j]);
			//printf("%c ", vect[j]);
		}
		
		for (int k = 0; k < ele_num; k++) {
			chk_num(vect, ele_num);
			rotate(vect);
		
			//print_f();
		}

		std::sort(num_v.begin(), num_v.end());

		//print_f();
		
		printf("#%d %lld\n", i, num_v[K - 1] * -1);
	}
	return 0;
}

void print_f() {
	printf("\nvect\n");
	for (int i = 0; i < vect.size(); i++) {
		printf("%c ", vect[i]);
	}
	printf("\n");

	printf("\nnum_v\n");
	for (int i = 0; i < num_v.size(); i++) {
		printf("%lld ", num_v[i]);
	}
	printf("\n");
}

// �ߺ��� ���� ����
// ������ ����
void chk_num(std::vector<char>& target_v, int num) {
	long long int temp = 0;
	int flag = 0;

	for (int i = 0; i < 4; i++) {
		temp = 0;
		for (int j = 0; j < num; j++) {
			if(target_v[j + i * num] == 'A')
				temp += std::pow(16, num - j - 1) * (10);
			else if (target_v[j + i * num] == 'B')
				temp += std::pow(16, num - j - 1) * (11);
			else if (target_v[j + i * num] == 'C')
				temp += std::pow(16, num - j - 1) * (12);
			else if (target_v[j + i * num] == 'D')
				temp += std::pow(16, num - j - 1) * (13);
			else if (target_v[j + i * num] == 'E')
				temp += std::pow(16, num - j - 1) * (14);
			else if (target_v[j + i * num] == 'F')
				temp += std::pow(16, num - j - 1) * (15);
			else
				temp += std::pow(16, num - j - 1) * (target_v[j + i * num] - 48);
		}

		flag = 0;
		for (int k = 0; k < num_v.size(); k++) {
			if (num_v[k] == temp * -1) {
				flag = 1;
				break;
			}
		}
		if(flag == 0)
			num_v.push_back(temp * -1);
	}
}

// �� �ڿ��ִ� ���� �� ������ �M
void rotate(std::vector<char>& target_v) {
	char temp = target_v.back();
	target_v.pop_back();
	target_v.insert(target_v.begin(), temp);
	return;
}
