import requests
import string
import datetime
import Crawling

import openpyxl
from openpyxl import load_workbook
from openpyxl import Workbook

date = datetime.datetime.now()

load_wb = load_workbook("C:/List.xlsx", data_only=True)
load_ws = load_wb['Sheet1']

# 종목 코드
company_codes = []
# 종목 이름
company_names = []

# 5년치 매출액
total_income_array = []
# 5년치 당순
net_income_array = []
# 5년치 자본총계
total_capital_array = []
# 5년치 esp
eps_array = []
# 5년치 roe
roe_array = []
# 5년치 per
per_array = []
# 5년치 pbr
pbr_array = []
# 5년치 주식수
stock_array = []
# 5년치 회계년도
date_array = []

# 5년치 데이터
total_data_array = []

for row in range(1,2212):
    #print(load_ws.cell(row,1).value)
    company_codes.append(load_ws.cell(row,1).value)

for row in range(1,2212):
    #print(load_ws.cell(row,2).value)
    company_names.append(load_ws.cell(row,2).value)


data_table = Crawling.cw(company_codes[0])
#print(data_table)

#엑셀 저장부분
write_wb = Workbook()
write_ws = write_wb.create_sheet('Sheet1')
write_ws = write_wb.active
write_ws['A1'] = '숫자'
write_wb.save('F:/test.xlsx')

