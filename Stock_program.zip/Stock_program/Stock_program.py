'''
1. 5년치 매출액, 당기순이익, 자본총계, EPS
   1. 5년치 매출액 평균 증감율
   2. 평균 증감율을 바탕으로 내년 매출액 계산
   3. 최근 매출액 저장

2. 5년치 주식수
   1. 주식수는 (당기순이익*100000000)xEPS
   2. 5년치 주식수 평균 증감율
   3. 평균 증감율을 바탕으로 내년 매출액 계산
   4. 최근 매출액 저장

3. 현재 주가
4. 추정된 매출액, 당기순이익, 자본총계, 주식수
    - ROE = (당기순이익/지본총계)*100
    - EPS = (당기순이익 * 100000000)/주식수
    - PER = 주가 / EPS
    - PBR = ROE * PER / 100
5. 추정수익률 
    - (1/PER) * 100
6. 사용자로부터 요구수익률을 받아옴
7. 추정수익률이 요구수익률보다 큰 놈만 가져옴 
'''

import requests
import openpyxl
import string
import pandas as pd 
import re
import datetime
#import matplotlib.pyplot as plt
from openpyxl import load_workbook
from openpyxl import Workbook
from bs4 import BeautifulSoup

date = datetime.datetime.now()

load_wb = load_workbook("C:/List.xlsx", data_only=True)
load_ws = load_wb['Sheet1']

re_enc = re.compile("encparam: '(.*)'", re.IGNORECASE) 
re_id = re.compile("id: '([a-zA-Z0-9]*)' ?", re.IGNORECASE)

# 종목 코드
company_codes = []
# 종목 이름
company_names = []

# 5년치 매출액
total_income_array = []
# 5년치 당순
net_income_array = []
# 5년치 자본총계
total_capital_array = []
# 5년치 esp
eps_array = []
# 5년치 roe
roe_array = []
# 5년치 per
per_array = []
# 5년치 pbr
pbr_array = []
# 5년치 주식수
stock_array = []
# 5년치 회계년도
date_array = []

# 5년치 데이터
total_data_array = []

for row in range(1,2212):
    #print(load_ws.cell(row,1).value)
    company_codes.append(load_ws.cell(row,1).value)

for row in range(1,2212):
    #print(load_ws.cell(row,2).value)
    company_names.append(load_ws.cell(row,2).value)

def get_coinfo_link1(company_code):
    url = "https://navercomp.wisereport.co.kr/v2/company/c1010001.aspx?cmp_cd={}".format(company_code) 
    para_result = requests.get(url).text
    encparam = re_enc.search(para_result).group(1) 
    encid = re_id.search(para_result).group(1)

    result = requests.get(url)
    naver_link = BeautifulSoup(result.content, "html.parser")

    table = naver_link.find("table", {"id": "cTB11"})

    now_price = table.select('td')[0].strong.get_text()
    if now_price == "":
        now_price = "0"
    now_price = now_price.replace(",","")
    now_price = float(now_price.replace("\t",""))

    url = "https://navercomp.wisereport.co.kr/v2/company/ajax/cF1001.aspx?cmp_cd={}&fin_typ=0&freq_typ=Y&encparam={}&id={}".format(company_code, encparam, encid) 
    print(url)
    result = requests.get(url)
    coinfo_link = BeautifulSoup(result.content, "html.parser")

    #financial summary
    head = coinfo_link.select('thead')[1]

    #연도
    total_date_mat = head.select('tr')[1]

    fifth_total_date = total_date_mat.select('th')[0].get_text()
    forth_total_date = total_date_mat.select('th')[1].get_text()
    thirth_total_date = total_date_mat.select('th')[2].get_text()
    second_total_date = total_date_mat.select('th')[3].get_text()
    first_total_date = total_date_mat.select('th')[4].get_text()

    fifth_total_date = fifth_total_date.replace("\t","")
    fifth_total_date = fifth_total_date.replace("\r","")
    fifth_total_date = fifth_total_date.replace("\n","")
    forth_total_date = forth_total_date.replace("\t","")
    forth_total_date = forth_total_date.replace("\r","")
    forth_total_date = forth_total_date.replace("\n","")
    thirth_total_date = thirth_total_date.replace("\t","")
    thirth_total_date = thirth_total_date.replace("\r","")
    thirth_total_date = thirth_total_date.replace("\n","")
    second_total_date = second_total_date.replace("\t","")
    second_total_date = second_total_date.replace("\r","")
    second_total_date = second_total_date.replace("\n","")
    first_total_date = first_total_date.replace("\t","")
    first_total_date = first_total_date.replace("\r","")
    first_total_date = first_total_date.replace("\n","")

    date_array = [fifth_total_date,forth_total_date,thirth_total_date,second_total_date,first_total_date]

    #financial summary
    body = coinfo_link.select('tbody')[1]
    
    #매출액 
    total_income_mat = body.select('tr')[0]   
    

    #엑셀 저장부분
    write_wb = Workbook()
    write_ws = write_wb.create_sheet('Sheet1')
    
    write_ws = write_wb.active
    write_ws['A1'] = '숫자'
    write_wb.save('F:/test.xlsx')


get_coinfo_link1(company_codes[0])  

