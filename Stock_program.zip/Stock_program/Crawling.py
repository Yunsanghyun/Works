import requests
import re
import pandas as pd 
from bs4 import BeautifulSoup

def cw(company_code):
    re_enc = re.compile("encparam: '(.*)'", re.IGNORECASE) 
    re_id = re.compile("id: '([a-zA-Z0-9]*)' ?", re.IGNORECASE)

    url = "https://navercomp.wisereport.co.kr/v2/company/c1010001.aspx?cmp_cd={}".format(company_code) 
    para_result = requests.get(url).text
    encparam = re_enc.search(para_result).group(1) 
    encid = re_id.search(para_result).group(1)

    result = requests.get(url)
    naver_link = BeautifulSoup(result.content, "html.parser")

    table = naver_link.find("table", {"id": "cTB11"})

    now_price = table.select('td')[0].strong.get_text()
    if now_price == "":
        now_price = "0"
    now_price = now_price.replace(",","")
    now_price = float(now_price.replace("\t",""))

    url = "https://navercomp.wisereport.co.kr/v2/company/ajax/cF1001.aspx?cmp_cd={}&fin_typ=0&freq_typ=Y&encparam={}&id={}".format(company_code, encparam, encid) 
    print(url)
    result = requests.get(url)
    coinfo_link = BeautifulSoup(result.content, "html.parser")

    #financial summary
    head = coinfo_link.select('thead')[1]

    #financial summary
    body = coinfo_link.select('tbody')[1]

    #회계년도 저장
    total_year_date_mat = head.select('tr')[1]
    year_date = [0,0,0,0,0]
    for i in range(0,5):
        year_date[i] = total_year_date_mat.select('th')[i].get_text()
        year_date[i] = year_date[i].replace("\t","")
        year_date[i] = year_date[i].replace("\r","")
        year_date[i] = year_date[i].replace("\n","")
    #print(year_date)

    year_data = [[0]*5]*33

    for i in range(0,3):
        total_mat = body.select('tr')[i]   
        print(total_mat)
        for j in range(0,5):
            year_data[i][j] = total_mat.select('td')[j].get_text()
            print(i,'행',j,'열 =',year_data[i][j])
    
    for a in range(0,3):
        for b in range(0,5):
            print(a,'행',b,'열 =',year_data[a][b])
    
    return body
    
