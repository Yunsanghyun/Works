#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

void DFS(std::pair<int,int> start_p, int history);
void print_f();
int range_chk(std::pair<int, int> cur_p);
int height_chk(std::pair<int, int> cur_p, std::pair<int, int> next_p, int history);
int end_chk(std::pair<int, int> cur_p, int history);

std::vector<std::pair<int, int>> top;
std::vector<std::pair<int, int>> value{ {-1,0},{1,0}, {0,-1}, {0,1} };

int map[8][8];
int visit[8][8];

int N, K = 0;
int cur_max_distance = 1;
int total_max_distance = 1;
int is_way = 0;
int temp_distance = 1;

int main() {
	int test_case = 0;
	scanf("%d", &test_case);

	int max_height = 1;
	for (int i = 1; i <= test_case; i++) {
		memset(map, 0, sizeof(map));
		max_height = 1;
		total_max_distance = 1;
		
		scanf("%d %d", &N, &K);

		for (int j = 0; j < N; j++) {
			for (int k = 0; k < N; k++) {
				scanf("%d", &map[j][k]);
				if (max_height < map[j][k]) {
					max_height = map[j][k];
					top.clear();
					top.push_back({ j,k });
				}
				else if (max_height == map[j][k])
					top.push_back({ j,k });
			}
		}
		for (int i = 0; i < top.size(); i++) {
			memset(visit, 0, sizeof(visit));
			cur_max_distance = 1;
			temp_distance = 1;

			//printf("%d %d �����\n", top[i].first, top[i].second);
			
			visit[top[i].first][top[i].second] = 2;
			DFS(top[i],0);

			if (total_max_distance < cur_max_distance) {
				total_max_distance = cur_max_distance;
			}
		}
		printf("#%d %d\n", i, total_max_distance);
	}
	return 0;
}

int temp_map = 1;
void DFS(std::pair<int,int> start_p, int history) {
	std::pair<int,int> cur_p = start_p;
	int cur_history = history;
	//visit[cur_p.first][cur_p.second] = 1;

	//printf("���� ���� ��ǥ %d %d / �̵��Ÿ� %d / �̷� %d\n", cur_p.first, cur_p.second, temp_distance, cur_history);
	//print_f();

	// ���̻� �� ���� ���� ���
	if (end_chk(cur_p, cur_history)) {
		//printf("���ٸ���\n");
		if (cur_max_distance < temp_distance)
			cur_max_distance = temp_distance;

		return;
	}

	for (int i = 0; i < 4; i++) {
		std::pair<int,int> next_p = { cur_p.first + value[i].first, cur_p.second + value[i].second };
		int next_history = cur_history;
		
		if (visit[next_p.first][next_p.second] == 0 && range_chk(next_p)) {
			//printf("���� ��ǥ�� %d %d\n", next_p.first, next_p.second);
			is_way = height_chk(cur_p, next_p, cur_history);
			
			// K��ŭ�� �״�� ���� ���ܻ�Ȳ�� �� �� ������ ���� ���̺��� 1 �۰Ը� �����.
			if (is_way == 2) {
				next_history = 1;
				temp_map = map[next_p.first][next_p.second];
				map[next_p.first][next_p.second] = map[cur_p.first][cur_p.second] - 1;
			}

			if (is_way) {
				visit[next_p.first][next_p.second] = 1;
				temp_distance++;

				DFS(next_p, next_history);

				if (cur_history != next_history) {
					next_history = 0;
					map[next_p.first][next_p.second] = temp_map;
				}

				visit[next_p.first][next_p.second] = 0;
				temp_distance--;
			}
		}
	}
	return;
}

// ���̻� �� ���� ������ Ȯ��
// ���⿡ �湮
int end_chk(std::pair<int, int> cur_p, int history) {
	std::pair<int, int> next_p;
	
	for (int i = 0; i < 4; i++) {
		next_p = { cur_p.first + value[i].first, cur_p.second + value[i].second };
		if (visit[next_p.first][next_p.second] == 0 && range_chk(next_p)) {
			// �� ���� ���� ��
			if (height_chk(cur_p, next_p, history)) {
				return 0;
			}
		}
	}
	return 1;
}

int range_chk(std::pair<int, int> cur_p) {
	if (0 <= cur_p.first && cur_p.first < N) {
		if (0 <= cur_p.second && cur_p.second < N) {
			return 1;
		}
	}
	return 0;
}

int height_chk(std::pair<int, int> cur_p, std::pair<int, int> next_p, int history) {
	if (map[cur_p.first][cur_p.second] > map[next_p.first][next_p.second])
		return 1;
	else {
		if ((map[cur_p.first][cur_p.second] > map[next_p.first][next_p.second] - K) && history == 0)
			return 2;
		else
			return 0;
	}
} 

void print_f() {
	printf("\nvisit\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d ", visit[i][j]);
		}
		printf("\n");
	}

	printf("\nmatrix\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d ", map[i][j]);
		}
		printf("\n");
	}
}