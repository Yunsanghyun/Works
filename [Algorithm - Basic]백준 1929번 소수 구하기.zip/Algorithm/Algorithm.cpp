#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

vector<int> prime;
int chk_prime(int num) {
	if (num == 1)
		return 0;
	else {
		for (int i = 2; i < (int)sqrt(num) + 1; i++) {
			if (num % i == 0)
				return 0;
		}
		return 1;
	}
	return 0;
}

int main() {
	int start = 0;
	int end = 0;
	int cnt = 0;
	int sum = 0;

	scanf("%d", &start);
	scanf("%d", &end);

	for (int i = start; i <= end; i++) {
		if (chk_prime(i)) {
			printf("%d\n", i);
		}
	}

	return 0;
}
