#include <iostream>
#include <cmath>
#include <cstring>

using namespace std;

int cal(int gap) {
	int temp = 0;
	int flag1 = 0;
	int flag2 = 0;
	int flag3 = 0;

	if (gap == 1) {
		return 1;
	}
	else {
		temp = (int)sqrt(gap);
		flag1 = temp * temp;
		flag2 = flag1 + temp;
		flag3 = (temp + 1) * (temp + 1);

		if (gap == flag1)
			return (2 * temp) - 1;
		else if(flag1 < gap && gap <= flag2)
			return (2 * temp);
		else if (flag2 < gap && gap <= flag3)
			return (2 * temp) + 1;
	}
}

int main() {
	int test_case = 0;
	int gap = 0;
	int start = 0, end = 0;
	int answer = 0;
	scanf("%d", &test_case);

	// ������ �ٷ� ���� �����ؾ���
	for (int i = 0; i < test_case; i++) {
		scanf("%d %d", &start, &end);
		gap = end - start;
		answer = cal(gap);
		printf("%d\n", answer);
	}
	return 0;
}
