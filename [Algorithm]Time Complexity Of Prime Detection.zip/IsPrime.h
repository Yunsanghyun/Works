#ifndef __IS_PRIME
#define __IS_PRIME

void Search(int target, int* arr);
void Eratosthenes(int target, int* dest, int* temp);

#endif 