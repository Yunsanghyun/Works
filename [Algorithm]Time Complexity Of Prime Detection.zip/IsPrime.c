void Search(int target, int* arr) {
	int flag = 0;
	int cnt = 1;
	arr[0] = 2;
	
	for (int i = 3; i <= target; i++) {
		flag = 0;
		for (int j = 2; j <= i/2; j++) {
			if (i % j == 0) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			arr[cnt] = i;
			cnt++;
		}
	}
}

// arr �迭��ȣ 0 ~ 49�� 1 ~ 50�̶�� �����Ѵ�.
void Eratosthenes(int target, int* dest, int* temp) {
	int cnt = 0;
	for (int i = 2; i <= target; i++) {
		for (int j = i * 2; j <= target; j += i) {
			temp[j - 1] = -1;
		}
	}
	// 1�ϋ� ������
	temp[0] = -1;
	// 2�϶� �Ҽ� ����
	temp[1] = 0;

	for (int i = 0; i < target; i++) {
		if (temp[i] == 0) {
			dest[cnt] = i + 1;
			cnt++;
		}
	}
}
