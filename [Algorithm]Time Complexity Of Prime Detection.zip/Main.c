#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "IsPrime.h"

int main(void)
{
	int len = 0;
	int i = 0;
	int* prime_arr1;
	int* prime_arr2;
	int* prime_arr3;
	clock_t start1,start2,end1,end2;

	while (1) {
		printf("������ �Ҽ��� ���Ұž�? \n");
		scanf("%d", &len);

		prime_arr1 = (int*)malloc(sizeof(int) * (len + 1));
		prime_arr2 = (int*)malloc(sizeof(int) * (len + 1));
		prime_arr3 = (int*)malloc(sizeof(int) * (len + 1));

		for (int i = 0; i < len; i++) {
			prime_arr1[i] = 0;
			prime_arr2[i] = 0;
			prime_arr3[i] = 0;
		}
		/*
		start1 = clock();
		Search(len, prime_arr1);
		end1 = clock();
		printf("����ð��� %.5f\n", (float)(end1 - start1) / CLOCKS_PER_SEC);

		
		while(prime_arr1[i] != 0) {
			printf("%d��° �Ҽ��� %d\n", i + 1, prime_arr1[i]);
			i++;
		}
		*/

		start2 = clock();
		Eratosthenes(len, prime_arr2, prime_arr3);
		end2 = clock();
		printf("����ð��� %.5f\n", (float)(end2 - start2) / CLOCKS_PER_SEC);

		/*
		i = 0;
		while (prime_arr2[i] != 0) {
			printf("%d��° �Ҽ��� %d\n", i + 1, prime_arr2[i]);
			i++;
		}
		*/

		free(prime_arr1);
		free(prime_arr2);
	}
	return 0;
}