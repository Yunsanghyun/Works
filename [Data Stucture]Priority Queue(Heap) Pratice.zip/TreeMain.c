#include <stdio.h>
#include "Tree.h"

void func(Data data);

int main() {
	Node* nd1 = MakeNode(1);
	Node* nd2 = MakeNode(2);
	Node* nd3 = MakeNode(3);
	Node* nd4 = MakeNode(4);

	ConnectLeftNode(nd1, nd2);
	ConnectRightNode(nd1, nd3);
	ConnectLeftNode(nd2, nd4);

	PreOrder(nd1, func);
	printf("\n");
	MiddleOrder(nd1, func);
	printf("\n");
	BackOrder(nd1, func);

	DeleteNode(nd1);

	return 0;
}

void func(Data data) {
	printf("%d \n", data);
}