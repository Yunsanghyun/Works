#include <stdio.h>
#include <string.h>
#include "pqueue.h"

// d1�� d2���� ��� 1�� ����, ���ų� ª���� 0�� ����
int com_char(HData data1, HData data2) {
	int len1 = strlen(data1);
	int len2 = strlen(data2);

	if (len1 > len2)
		return 1;
	else
		return 0;
}

int main() {
	Heap pqueue;
	
	Init_pqueue(&pqueue,com_char);
	Enqueue(&pqueue, "I");
	Enqueue(&pqueue, "hate");
	Enqueue(&pqueue, "fucking");
	Enqueue(&pqueue, "study");
	Enqueue(&pqueue, "shit");

	printf("%s\n", Dequeue(&pqueue));
	printf("%s\n", Dequeue(&pqueue));
	printf("%s\n", Dequeue(&pqueue));
	printf("%s\n", Dequeue(&pqueue));
	printf("%s\n", Dequeue(&pqueue));

	return 0;
}


