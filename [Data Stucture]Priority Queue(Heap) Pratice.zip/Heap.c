#include "Heap.h"

void HeapInit(Heap* ph, PriorityComp pc) {
    ph->numOfData = 0;
    ph->comp = pc;
}
void HInsert(Heap* ph, HData data) {
    int new_idx = ph->numOfData + 1;
    int parent_idx;

    while (new_idx != 1) {
        parent_idx = Cal_Parent_idx(new_idx);
        //�θ��尡 �켱���� ���� ��,
        if (ph->comp(ph->heapArr[parent_idx], data) > 0) {
            break;
        }
        //�θ��尡 �켱������ ���� ��,
        else {
            ph->heapArr[new_idx] = ph->heapArr[parent_idx];
            new_idx = parent_idx;
        }
    }
    ph->heapArr[new_idx] = data;
    ph->numOfData++;
}
HData HDelete(Heap* ph) {
    HData temp = ph->heapArr[1];
    HData last = ph->heapArr[ph->numOfData];
    int parent_idx = 1;
    int child_idx;

    while (child_idx = Comp_child_priority(ph, parent_idx)) {
        if (ph->comp(last, ph->heapArr[child_idx])) {
            break;
        }
        else {
            ph->heapArr[parent_idx] = ph->heapArr[child_idx];
            parent_idx = child_idx;
        }
    }

    ph->heapArr[parent_idx] = last;
    ph->numOfData--;
   
    return temp;
}
int HIsEmpty(Heap* ph) {
    if (ph->numOfData == 0)
        return 1;
    else
        return 0;
}
int Cal_LChild_idx(int parent_idx) {
    return parent_idx * 2;
}
int Cal_RChild_idx(int parent_idx) {
    return parent_idx * 2 + 1;
}
int Cal_Parent_idx(int child_idx) {
    return child_idx / 2;
}
int Comp_child_priority(Heap* ph, int idx){
    if (Cal_LChild_idx(idx) > ph->numOfData)
        return 0;
    else if (Cal_LChild_idx(idx) == ph->numOfData) {
        return Cal_LChild_idx(idx);
    }
    else {
        // ������ �켱���� ����
        if (ph->comp(ph->heapArr[Cal_LChild_idx(idx)], ph->heapArr[Cal_RChild_idx(idx)])) {
            return Cal_LChild_idx(idx);
        }
        else
            return Cal_RChild_idx(idx);
    }

}