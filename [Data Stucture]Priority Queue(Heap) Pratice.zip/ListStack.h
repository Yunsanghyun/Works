#ifndef __LIST_STACK_H__
#define __LIST_STACK_H__

#include "Tree.h"

#define TRUE	1
#define FALSE	0

typedef int Data;

typedef struct _node
{
	Data data;
	struct _node * next;
} Node;

typedef struct StackList
{
	Node * head;
	Data index;
} SList;

typedef SList List;

void SInit(List * list);
void SPush(List * list, Data data);
int SEmpty(List* list);
Data SPop(List * list);
Data SPeek(List* list);

#endif