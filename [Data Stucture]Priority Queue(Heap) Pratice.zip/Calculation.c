#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <malloc.h>
#include "ListStack.h"

int calculation(char* arr) {
	int v1 = 0;
	int v2 = 0;
	int anw = 0;
	List stack;
	SInit(&stack);

	for (int i = 0; i < strlen(arr) + 1; i++) {
		if (arr[i] == '\0') {
			break;
		}
		if (isdigit(arr[i])) {
			SPush(&stack,arr[i]);
		}
		else {
			v1 = SPop(&stack) - '0';
			v2 = SPop(&stack) - '0';

			switch (arr[i]) {
			case '+':
				anw = v2 + v1;
				break;
			case '-':
				anw = v2 - v1;
				break;
			case '*':
				anw = v2 * v1;
				break;
			case '/':
				anw = v2 / v1;
				break;
			}
			SPush(&stack, anw + '0');
		}
	}
	return SPop(&stack) - '0';
}
