#include <iostream>
#include <string>
#include <stack>
#include <vector>

using namespace std;

int chk_string(vector<char> str) {
	stack<char> total;
	int value = 0;

	for (int i = 0; i < str.size(); i++) {
		if (str[i] == '(' || str[i] == '[')
			total.push(str[i]);

		else if (str[i] == ')') {
			if (total.empty())
				return 0;
			else {
				if (total.top() == '(')
					total.pop();
				else if (total.top() == '[')
					return 0;
			}
		}
		else if (str[i] == ']') {
			if (total.empty())
				return 0;
			else {
				if (total.top() == '[')
					total.pop();
				else if (total.top() == '(')
					return 0;
			}
		}
	}
	if (total.empty() == 0)
		return 0;
	else
		return 1;
}

int main() {
	vector<char> str;
	int n = 0;
	string temp;

	while (1) {
		str.clear();
		while (1) {
			getline(cin, temp);
			for (int i = 0; i < temp.size(); i++) {
				str.push_back(temp[i]);
			}
			if (temp.back() == '.')
				break;
		}

		if (str.size() == 1)
			break;

		if (chk_string(str))
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}