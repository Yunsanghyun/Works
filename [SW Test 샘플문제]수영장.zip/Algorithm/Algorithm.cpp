#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

void DP_func();
void init();

int price[5];
int plan[13];
int dp[13];
int min_price = 0;

int main() {
	int test_case = 0;
	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		memset(price, 0, sizeof(price));
		memset(plan, 0, sizeof(plan));
		memset(dp, 0, sizeof(dp));

		for (int j = 1; j < 5; j++) {
			scanf("%d", &price[j]);
		}
		for (int k = 1; k < 13; k++) {
			scanf("%d", &plan[k]);
		}

		DP_func();

		/*for (int k = 1; k < 13; k++) {
			printf("%d ", dp[k]);
		}
		printf("\n");*/
		
		printf("#%d %d\n", i, dp[12]);
	}
	return 0;
}

// �Ŵ� 4���� ����� ��
void DP_func() {
	int temp1, temp2, temp3, temp4 = 0;

	// dp[1],dp[2],dp[3] ����
	init();

	for (int i = 4; i < 13; i++) {
		temp1 = dp[i - 1] + price[1] * plan[i]; // ������ + �̹��� 1ȸ��
		temp2 = dp[i - 1] + price[2]; // ������ + �̹��� 1�ޱ�
		temp3 = dp[i - 3] + price[3]; // 3���� + 3�ޱ�
		temp4 = price[4];

		dp[i] = std::min(std::min(std::min(temp1, temp2), temp3), temp4);
	}
	return;
}

//dp[1],dp[2],dp[3] �ʱ�ȭ
void init() {
	int temp1, temp2, temp3, temp4 = 0;

	temp1 = price[1] * plan[1];
	temp2 = price[2];
	temp3 = price[3];
	temp4 = price[4];

	dp[1] = std::min(std::min(std::min(temp1, temp2), temp3), temp4);

	temp1 = price[1] * plan[2];
	temp2 = price[2];
	temp3 = price[3];
	temp4 = price[4];

	dp[2] = std::min(std::min(std::min(temp1 + dp[1], temp2 + dp[1]), temp3), temp4);

	temp1 = price[1] * plan[3];
	temp2 = price[2];
	temp3 = price[3];
	temp4 = price[4];

	dp[3] = std::min(std::min(std::min(temp1 + dp[2], temp2 + dp[2]), temp3), temp4);
}
	