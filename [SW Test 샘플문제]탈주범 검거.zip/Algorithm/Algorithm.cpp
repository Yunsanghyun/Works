#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

int BFS(std::pair<int, int> start_p, int total_time);
int range_chk(std::pair<int, int> cur_p);
int pipe_chk(std::pair<int, int> cur_p, std::pair<int, int> next_p);
void print_f();

int turnel[51][51];
int visit[51][51];

int N, M = 0;

int main() {
	int test_case = 0;
	scanf("%d", &test_case);
	
	int start_x, start_y = 0;
	int time = 0;
	int place_num = 0;

	for (int i = 1; i <= test_case; i++) {
		memset(turnel, 0, sizeof(turnel));
		memset(visit, 0, sizeof(visit));

		scanf("%d %d", &N, &M);
		scanf("%d %d", &start_x, &start_y);
		scanf("%d", &time);

		for (int j = 0; j < N; j++) {
			for (int k = 0; k < M; k++) {
				scanf("%d", &turnel[j][k]);
			}
		}

		place_num = BFS({ start_x,start_y }, time);

		printf("#%d %d\n", i,place_num);
	}
	return 0;
}

int BFS(std::pair<int, int> start_p, int total_time) {
	int place_num = 0;
	int cur_time = 1;
	int next_time = 1;

	std::pair<int, int> cur_p;
	std::pair<int, int> next_p;
	// ù��° ��ǥ, �ι��� �̵��ð�
	std::queue<std::pair<std::pair<int, int>,int>> bfs_q;
	// �����¿�
	std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };

	cur_p = start_p;
	cur_time = 1;
	
	bfs_q.push({ cur_p, cur_time });
	while (bfs_q.empty() == 0) {
		cur_p = bfs_q.front().first;
		cur_time = bfs_q.front().second;
		bfs_q.pop();

		//printf("���� �����ִ� ��ġ %d %d %d \n", cur_p.first, cur_p.second, turnel[cur_p.first][cur_p.second]);

		visit[cur_p.first][cur_p.second] = 1;

		switch (turnel[cur_p.first][cur_p.second]) {
		case 1:
			for (int i = 0; i < 4; i++) {
				next_p = { cur_p.first + value[i].first,cur_p.second + value[i].second };
				next_time = cur_time + 1;
				// ����üũ, �湮üũ, 
				if (range_chk(next_p) && visit[next_p.first][next_p.second] == 0) {
					// ������ üũ, �̵��Ÿ� üũ
					if (pipe_chk(cur_p, next_p) && next_time <= total_time) {
						bfs_q.push({ next_p, next_time });
					}
				}
			}
			break;

		case 2:
			for (int i = 0; i < 2; i++) {
				next_p = { cur_p.first + value[i].first,cur_p.second + value[i].second };
				next_time = cur_time + 1;
				// ����üũ, �湮üũ, 
				if (range_chk(next_p) && visit[next_p.first][next_p.second] == 0) {
					// ������ üũ, �̵��Ÿ� üũ
					if (pipe_chk(cur_p, next_p) && next_time <= total_time) {
						bfs_q.push({ next_p, next_time });
					}
				}
			}
			break;
		case 3:
			for (int i = 0; i < 2; i++) {
				next_p = { cur_p.first + value[i + 2].first,cur_p.second + value[i + 2].second };
				next_time = cur_time + 1;
				//printf("%d %d\n", next_p.first, next_p.second);
				// ����üũ, �湮üũ, 
				if (range_chk(next_p) && visit[next_p.first][next_p.second] == 0) {
					// ������ üũ, �̵��Ÿ� üũ
					if (pipe_chk(cur_p, next_p) && next_time <= total_time) {
						bfs_q.push({ next_p, next_time });
					}
				}
			}
			break;
		case 4:
			for (int i = 0; i < 2; i++) {
				next_p = { cur_p.first + value[0 + 3 * i].first,cur_p.second + value[0 + 3 * i].second };
				next_time = cur_time + 1;
				// ����üũ, �湮üũ, 
				if (range_chk(next_p) && visit[next_p.first][next_p.second] == 0) {
					// ������ üũ, �̵��Ÿ� üũ
					if (pipe_chk(cur_p, next_p) && next_time <= total_time) {
						bfs_q.push({ next_p, next_time });
					}
				}
			}
			break;
		case 5:
			for (int i = 0; i < 2; i++) {
				next_p = { cur_p.first + value[1 + 2 * i].first,cur_p.second + value[1 + 2 * i].second };
				next_time = cur_time + 1;
				// ����üũ, �湮üũ, 
				if (range_chk(next_p) && visit[next_p.first][next_p.second] == 0) {
					// ������ üũ, �̵��Ÿ� üũ
					if (pipe_chk(cur_p, next_p) && next_time <= total_time) {
						bfs_q.push({ next_p, next_time });
					}
				}
			}
			break;
		case 6:
			for (int i = 0; i < 2; i++) {
				next_p = { cur_p.first + value[1 + i].first,cur_p.second + value[1 + i].second };
				next_time = cur_time + 1;
				// ����üũ, �湮üũ, 
				if (range_chk(next_p) && visit[next_p.first][next_p.second] == 0) {
					// ������ üũ, �̵��Ÿ� üũ
					if (pipe_chk(cur_p, next_p) && next_time <= total_time) {
						bfs_q.push({ next_p, next_time });
					}
				}
			}
			break;
		case 7:
			for (int i = 0; i < 2; i++) {
				next_p = { cur_p.first + value[2 * i].first,cur_p.second + value[2 * i].second };
				next_time = cur_time + 1;
				// ����üũ, �湮üũ, 
				if (range_chk(next_p) && visit[next_p.first][next_p.second] == 0) {
					// ������ üũ, �̵��Ÿ� üũ
					if (pipe_chk(cur_p, next_p) && next_time <= total_time) {
						bfs_q.push({ next_p, next_time });
					}
				}
			}
			break;
		}
	}

	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if(visit[i][j] == 1)
				place_num++;
		}
	}
	//print_f();

	return place_num;
}

// ���� üũ
int range_chk(std::pair<int, int> cur_p) {
	if (0 <= cur_p.first && cur_p.first < N) {
		if (0 <= cur_p.second && cur_p.second < M) {
			return 1;
		}
	}
	return 0;
}

// ������ ���� �� ����Ǿ��ִ��� üũ
// ���� �������� ���� �������� ��ġ�� ��
int pipe_chk(std::pair<int, int> cur_p, std::pair<int,int> next_p) {
	// ���縦 �������� ������ġ�� ��,��,��,�� (0,1,2,3)
	int direction = 0;
	int cur_pipe = turnel[cur_p.first][cur_p.second];
	int next_pipe = turnel[next_p.first][next_p.second];

	// ���� ���� ���
	if (cur_p.first == next_p.first) {
		if (cur_p.second > next_p.second)
			direction = 2;
		else
			direction = 3;
	}
	// ���� ���� ���
	else if(cur_p.second == next_p.second) {
		if (cur_p.first > next_p.first)
			direction = 0;
		else
			direction = 1;
	}
	
	if (next_pipe == 0)
		return 0;
	else {
		switch (cur_pipe) {
		case 1:
			if (direction == 0) {
				if (next_pipe == 1 || next_pipe == 2 || next_pipe == 5 || next_pipe == 6) {
					return 1;
				}
			}
			else if(direction == 1) {
				if (next_pipe == 1 || next_pipe == 2 || next_pipe == 4 || next_pipe == 7) {
					return 1;
				}
			}
			else if (direction == 2) {
				if (next_pipe == 1 || next_pipe == 3 || next_pipe == 4 || next_pipe == 5) {
					return 1;
				}
			}
			else if (direction == 3) {
				if (next_pipe == 1 || next_pipe == 3 || next_pipe == 6 || next_pipe == 7) {
					return 1;
				}
			}
			break;
		case 2:
			if (direction == 0) {
				if (next_pipe == 1 || next_pipe == 2 || next_pipe == 5 || next_pipe == 6) {
					return 1;
				}
			}
			else if (direction == 1) {
				if (next_pipe == 1 || next_pipe == 2 || next_pipe == 4 || next_pipe == 7) {
					return 1;
				}
			}
			break;
		case 3:
			if (direction == 2) {
				if (next_pipe == 1 || next_pipe == 3 || next_pipe == 4 || next_pipe == 5) {
					return 1;
				}
			}
			else if (direction == 3) {
				if (next_pipe == 1 || next_pipe == 3 || next_pipe == 6 || next_pipe == 7) {
					return 1;
				}
			}
			break;
		case 4:
			if (direction == 0) {
				if (next_pipe == 1 || next_pipe == 2 || next_pipe == 5 || next_pipe == 6) {
					return 1;
				}
			}
			else if(direction == 3) {
				if (next_pipe == 1 || next_pipe == 3 || next_pipe == 6 || next_pipe == 7) {
					return 1;
				}
			}
			break;
		case 5:
			if (direction == 1) {
				if (next_pipe == 1 || next_pipe == 2 || next_pipe == 4 || next_pipe == 7) {
					return 1;
				}
			}
			else if(direction == 3) {
				if (next_pipe == 1 || next_pipe == 3 || next_pipe == 6 || next_pipe == 7) {
					return 1;
				}
			}
			break;
		case 6:
			if (direction == 1) {
				if (next_pipe == 1 || next_pipe == 2 || next_pipe == 4 || next_pipe == 7) {
					return 1;
				}
			}
			else if (direction == 2) {
				if (next_pipe == 1 || next_pipe == 3 || next_pipe == 4 || next_pipe == 5) {
					return 1;
				}
			}
			break;
		case 7:
			if (direction == 0) {
				if (next_pipe == 1 || next_pipe == 2 || next_pipe == 5 || next_pipe == 6) {
					return 1;
				}
			}
			else if (direction == 2) {
				if (next_pipe == 1 || next_pipe == 3 || next_pipe == 4 || next_pipe == 5) {
					return 1;
				}
			}
			break;
		}
	}
	return 0;
}

void print_f() {
	printf("\nvisit\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			printf("%d ", visit[i][j]);
		}
		printf("\n");
	}
}