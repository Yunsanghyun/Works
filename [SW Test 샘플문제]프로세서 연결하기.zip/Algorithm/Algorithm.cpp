#include <iostream>
#include <cstring>
#include <vector>

#define TRUE 1
#define FALSE 0

int matrix[13][13];
int visit[13][13];
int line[13][13];

void DFS(std::pair<int,int> cur_p, int direction);
int check_direction(std::pair<int, int> cur_p, int direction);
int fill_line(std::pair<int, int> cur_p, int direction, int line_color);
void delete_line(std::pair<int, int> cur_p, int direction, int line_color);

void print_f();

std::vector < std::pair<int, int>> core_v;
std::vector<int> line_dist;

int N = 0;
int temp_line_dist = 0;
int total_line_dist = 0;
int total_line_cnt = 0;
int min_line_dist = 1e9;
int max_line_cnt = 0;

int main() {
	int test_case = 0;

	scanf("%d", &test_case);
	for (int i = 0; i < test_case; i++) {
		memset(matrix, 0, sizeof(matrix));
		memset(visit, 0, sizeof(visit));
		memset(line, 0, sizeof(line));

		core_v.clear();
		line_dist.clear();

		min_line_dist = 1e9;
		max_line_cnt = 0;

		scanf("%d", &N);
		for (int j = 0; j < N; j++) {
			for (int k = 0; k < N; k++) {
				scanf("%d", &matrix[j][k]);
				if (matrix[j][k] == 1) {
					if ((0 < j && j < N - 1) && (0 < k && k < N - 1)) {
						core_v.push_back({ j,k });
					}
				}
			}
		}
		
		DFS({-1,-1}, 0);
		
		printf("#%d %d\n",i + 1, min_line_dist);
	}
}

void DFS(std::pair<int, int> cur_p, int direction) {
	//printf("%d %d Ž�� ��\n", cur_p.first, cur_p.second);
	//print_f();

	if (cur_p == core_v.back()) {
		total_line_dist = 0;
		total_line_cnt = 0;
		for (int i = 0; i < line_dist.size(); i++) {
			total_line_dist += line_dist[i];
			if (line_dist[i] != 0)
				total_line_cnt++;
		}

		if (max_line_cnt <= total_line_cnt) {
			max_line_cnt = total_line_cnt;
			if (min_line_dist > total_line_dist)
				min_line_dist = total_line_dist;
		}

		//printf("�ϷḮ��, �� ���� ���� %d, �Ÿ��� %d\n", total_line_cnt, total_line_dist);
		return;
	}	

	for (int i = 0; i < core_v.size(); i++) {
		std::pair<int, int> next_p = core_v[i];
		if (visit[next_p.first][next_p.second] == 0) {
			visit[next_p.first][next_p.second] = 1;
			for (int j = 0; j < 4; j++) {
				if (check_direction(next_p, j)) {
					temp_line_dist = fill_line(next_p, j, i + 1);
					line_dist.push_back(temp_line_dist);
					//printf("%d %d DFS ����\n", next_p.first, next_p.second);
				
					DFS(next_p, j);

					//printf("%d %d DFS ����\n", next_p.first, next_p.second);
					delete_line(next_p, j, i + 1);
					line_dist.pop_back();
				}
			}
		}
		visit[next_p.first][next_p.second] = 0;
	}

	total_line_dist = 0;
	total_line_cnt = 0;
	for (int i = 0; i < line_dist.size(); i++) {
		total_line_dist += line_dist[i];
		if (line_dist[i] != 0)
			total_line_cnt++;
	}

	if (max_line_cnt <= total_line_cnt) {
		max_line_cnt = total_line_cnt;
		if (min_line_dist > total_line_dist)
			min_line_dist = total_line_dist;
	}

	//printf("�ϷḮ��, �� ���� ���� %d, �Ÿ��� %d\n", total_line_cnt, total_line_dist);
	
	return;
}

// 0,1,2,3(��,��,��,��)
// ��� �� �ٸ� �ھ ������ ���� 0
int check_direction(std::pair<int, int> cur_p, int direction) {
	std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };
	if (matrix[cur_p.first + value[direction].first][cur_p.second + value[direction].second] == 0) {
		while ((0 <= cur_p.first && cur_p.first < N) && (0 <= cur_p.second && cur_p.second < N)) {

			cur_p.first += value[direction].first;
			cur_p.second += value[direction].second;

			// �ھ, �ٸ� ������ ������ ���
			if (matrix[cur_p.first][cur_p.second] == 1 || line[cur_p.first][cur_p.second] != 0) {
				return 0;
			}
		}
		return 1;
	}
	else
		return 0;
}

// ���� ��ġ�� �������� ������ ����
// �����ϴٰ� �ھ, �ٸ� ������ ������ ���� 0,
// ���ῡ �����ϸ� �������̸� ����
int fill_line(std::pair<int, int> cur_p, int direction, int line_color) {
	int line_dist = -1;
	std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };

	while ((0 <= cur_p.first && cur_p.first < N) && (0 <= cur_p.second && cur_p.second < N)) {
		line[cur_p.first][cur_p.second] = line_color;
		line_dist++;

		cur_p.first += value[direction].first;
		cur_p.second += value[direction].second;

		// �ھ, �ٸ� ������ ������ ���
		if (matrix[cur_p.first][cur_p.second] == 1 || line[cur_p.first][cur_p.second] != 0) {
			return 0;
		}
	}
	return line_dist;
}

void delete_line(std::pair<int, int> cur_p, int direction, int line_color) {
	std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };

	while ((0 <= cur_p.first && cur_p.first < N) && (0 <= cur_p.second && cur_p.second < N)) {
		line[cur_p.first][cur_p.second] = 0;

		cur_p.first += value[direction].first;
		cur_p.second += value[direction].second;

		// �ھ, �ٸ� ������ ������ ���
		if (matrix[cur_p.first][cur_p.second] == 1 || (line[cur_p.first][cur_p.second] != 0 && line[cur_p.first][cur_p.second] != line_color)) {
			return;
		}
	}
	return;
}

void print_f() {
	printf("\nvisit\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d", visit[i][j]);
		}
		printf("\n");
	}

	printf("\nline\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d", line[i][j]);
		}
		printf("\n");
	}
}