#include <iostream>
#include <cmath>
#include <vector>
#include <cstring>

void DFS(int num);
void print_f();

std::vector<int> temp_group;
std::vector<int> max_group;
std::vector<int> same_group;

int matrix[101];
int visit[101];

int N = 0;
int start_num = 1e9;

int same_cnt = 0;
int routine_cnt = 0;
int max_group_cnt = 0;
int group_cnt = 0;

int main() {
    int temp = 0;
    memset(matrix, 0, sizeof(matrix));
    scanf("%d", &N);

    for (int i = 1; i <= N; i++) {
        scanf("%d", &temp);
        matrix[i] = temp;
    }

    for (int i = 1; i <= N; i++) {
        memset(visit, 0, sizeof(visit));
        start_num = i;
        DFS(i);
    }

    printf("%d\n", max_group.size());
    for (int i = 0; i < max_group.size(); i++) {
        printf("%d\n", max_group[i]);
    }

    return 0;
}

// �׳� ���� �ϳ� �־�����, �̰� ���ٰ� �ڱ� �ڽ��̶� ������ Ǫ��
void DFS(int num) {
    visit[num] = 1;

	if (start_num == matrix[num]) {
		max_group.push_back(start_num);
		return;
	}

	// �湮���� ���� ��
    if (visit[matrix[num]] == 0) {
        DFS(matrix[num]);
    }

    return;
}

void print_f() {
    printf("visit\n");
    for (int i = 1; i <= N; i++)
        printf("%d ", visit[i]);
    printf("\n");
}