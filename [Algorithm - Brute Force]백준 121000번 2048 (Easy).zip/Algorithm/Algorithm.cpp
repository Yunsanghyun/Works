#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

void DFS(int depth);
int CMD_seperate(std::vector<int>& cmd);
void CMD_move(int cmd_num);
void start_move(int x, int y, int cmd_num);
int value_check(std::pair<int, int> org_position, std::pair<int, int> new_position);
void value_set(std::pair<int, int> org_position, std::pair<int, int> new_position, int cmd_num, int check_value);

void print_f(std::vector<int>& p);

int matrix[20][20];
// ù��° ������ �̷�, �ι�° ��
std::pair<int,int> temp_matrix[20][20];

std::vector<int> cmd{-1};
// ù��° ��ģ���, �ι��� ��, ������ ��ǥ(X,Y)
std::vector<std::pair<int,std::pair<int, std::pair<int, int>>>> v_data;
// �����¿� �̵��� ��, ��ǥ�� �����Ǵ� ��
std::vector<std::pair<int, int>> move_value{ {-1,0},{1,0},{0,-1},{0,1} };

int max = 0;
int N = 0;

int main() {
    scanf("%d", &N);

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }

    DFS(0);

    printf("%d", max);

    return 0;
}

void DFS(int depth) {
    int temp;

    // 5�� ���ɿ� ���� ����
    if (depth == 5) {
        print_f(cmd);
        temp = CMD_seperate(cmd);
        if (max < temp) {
            max = temp;
            /*
            print_f(cmd);
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    printf("%d ", temp_matrix[i][j].second);
                }
                printf("\n");
            }
            printf("\n");
            */
        }
        return;
    }

    // 4���� ��������
    for (int i = 0; i < 4; i++) {
        // �������ɰ� ��ġ���ʰ�
        //if (cmd.back() != i) {
            cmd.push_back(i);
            DFS(depth + 1);
            cmd.pop_back();
        //}
    }
}

// Ŀ��Ʈ �з�
int CMD_seperate(std::vector<int>& cmd) {
    int max_value = 0;
    int temp_value = 0;
   
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            temp_matrix[i][j] = { 0, matrix[i][j] };
        }
    }

    for (int i = 1; i <= 5; i++) {
        CMD_move(cmd[i]);
    }

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (max_value < temp_matrix[i][j].second)
                max_value = temp_matrix[i][j].second;
        }
    }

    return max_value;
}
// Ŀ�ǵ� ����
void CMD_move(int cmd_num) {
    int max_value = 0;

    switch (cmd_num) {
    case 0:
        for (int x = 1; x < N; x++)
            for (int y = 0; y < N; y++)
                start_move(x, y, cmd_num);
        break;
    case 1:
        for (int x = N - 2; x >= 0; x--)
            for (int y = 0; y < N; y++)
                start_move(x, y, cmd_num);
        break;
    case 2:
        for (int y = 1; y < N; y++)
            for (int x = 0; x < N; x++)
                start_move(x, y, cmd_num);
        break;
    case 3:
        for (int y = N - 2; y >= 0; y--)
            for (int x = 0; x < N; x++)
                start_move(x, y, cmd_num);
        break;
    }
    /*
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%d ", temp_matrix[i][j].second);
        }
        printf("\n");
    }
    printf("\n");
    */
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            temp_matrix[i][j].first = 0;
        }
    }
}

void start_move(int x, int y, int cmd_num) {
    int check_value = 0;
    std::pair<int, int> org_position;
    std::pair<int, int> new_position;

    // ���� �ִ� ���
    if (temp_matrix[x][y].second != 0) {
        // �ʱ� ��ġ
        org_position = { x,y };
        while (1) {
            // ���ο� ��ġ
            new_position.first = org_position.first + move_value[cmd_num].first;
            new_position.second = org_position.second + move_value[cmd_num].second;
            if (new_position.first < 0 || new_position.first >= N) {
                break;
            }
            if (new_position.second < 0 || new_position.second >= N) {
                break;
            }
            // �������� 0�̸� �̵�
            if (temp_matrix[new_position.first][new_position.second].second == 0) {
                value_set(org_position, new_position, cmd_num, 2);
            }
            // �������� 0�� �ƴϸ� �˻�
            else {
                // 1�̸� �̵� �� ��ħ, 0�̸� �ƹ����� ����
                check_value = value_check(org_position, new_position);
                value_set(org_position, new_position, cmd_num, check_value);
                if (check_value == 0)
                    break;
            }
            org_position = new_position;
        }
    }
}

int value_check(std::pair<int,int> org_position, std::pair<int, int> new_position) {
    int next_history = 0;
    int next_value = 0;
    int cur_history = 0;
    int cur_value = 0;
    
    next_history = temp_matrix[new_position.first][new_position.second].first;
    next_value = temp_matrix[new_position.first][new_position.second].second;
    cur_history = temp_matrix[org_position.first][org_position.second].first;
    cur_value = temp_matrix[org_position.first][org_position.second].second;
    
    if (next_value == cur_value && next_history == 0 && cur_history == 0)
        return 1;
    else
        return 0;
}
void value_set(std::pair<int, int> org_position, std::pair<int, int> new_position, int cmd_num, int check_value) {
    // �̵�
    if (check_value == 2) {
        temp_matrix[new_position.first][new_position.second].first
            = temp_matrix[org_position.first][org_position.second].first;
        temp_matrix[new_position.first][new_position.second].second
            = temp_matrix[org_position.first][org_position.second].second;
        temp_matrix[org_position.first][org_position.second].first = 0;
        temp_matrix[org_position.first][org_position.second].second = 0;
    }
    // �̵� �� ����
    else if(check_value == 1) {
        temp_matrix[new_position.first][new_position.second].first
            = 1;
        temp_matrix[new_position.first][new_position.second].second
            = temp_matrix[org_position.first][org_position.second].second * 2;
        temp_matrix[org_position.first][org_position.second].first = 0;
        temp_matrix[org_position.first][org_position.second].second = 0;
    }
}

void print_f(std::vector<int>& p) {
    for (int i = 1; i < p.size() ; i++) {
        printf("%d  ", p[i]);
    }
    printf("\n");
}
