#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <cstring>
#include <ctime>

std::vector<std::string> answer_v;
std::map<std::string, int> mp;

std::string first_arr[3] = { "ohhenrie","charlie","baesangwook" };
std::string second_arr[4] = { "obama","baesangwook","ohhenrie","clinton" };

int main() {
	int N = 0;
	int M = 0;
	char name[21];
	std::string str;

	clock_t begin = clock();
	
	for (int i = 0; i < 3; i++) {
		str = first_arr[i];
		mp.insert({str,i});
	}

	std::map<std::string, int>::iterator itr;
	for (int i = 0; i < 4; i++) {
		str = second_arr[i];
		itr = mp.find(str);
		if (itr != mp.end()) {
			answer_v.push_back(str);
		}
	}

	std::sort(answer_v.begin(), answer_v.end());
	printf("%d\n", answer_v.size());
	for (int i = 0; i < answer_v.size(); i++) {
		std::cout << answer_v[i] << std::endl;
	}

	clock_t end = clock();
	//double elapsed_sec = double(end - begin) / CLOCKS_PER_SEC;
	double elapsed_sec = double(end - begin);
	printf("%lf\n", elapsed_sec);

	return 0;
}