#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#include <ctime>

void DFS(std::pair<int,std::pair<int,int>> start_p);

char matrix[21][21];
int visit[30];
int R, C = 0;
int move_cnt = 1;
int max_cnt = 0;

std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };
std::pair<int, std::pair<int,int>> new_p;

int main() {
	int BFS_cnt = 0;
	int DFS_cnt = 0;
	memset(matrix, 0, sizeof(matrix));
	memset(visit, 0, sizeof(visit));

	scanf("%d %d", &R, &C);
	
	for (int i = 0; i < R; i++) {
		scanf("%s", &matrix[i]);
	}

	DFS({ 1, {0,0} });
	DFS_cnt = max_cnt;

	printf("%d", DFS_cnt);

	return 0;

}

void DFS(std::pair<int,std::pair<int,int>> start_p) {
	visit[matrix[start_p.second.first][start_p.second.second] - 65] = 1;
	
	//printf("�ʱ� %d %d %d %c\n", start_p.first, start_p.second.first,start_p.second.second, matrix[start_p.second.first][start_p.second.second]);

	if (max_cnt < start_p.first)
		max_cnt = start_p.first;

	// 4�������� �̵�
	for (int i = 0; i < 4; i++) {
		new_p = { start_p.first, {start_p.second.first + value[i].first, start_p.second.second + value[i].second} };

		// �迭 ������ �ִ��� Ȯ��
		if (start_p.second.first + value[i].first >= 0 && start_p.second.first + value[i].first < R) {
			if (start_p.second.second + value[i].second >= 0 && start_p.second.second + value[i].second < C) {
				// �Ȱ��� ���ĺ�����
				if (visit[matrix[start_p.second.first + value[i].first][start_p.second.second + value[i].second] - 65] == 0) {
					visit[matrix[start_p.second.first + value[i].first][start_p.second.second + value[i].second] - 65] = 1;
					start_p.first += 1;
					//printf("���� %d %d %d %c\n", start_p.first, start_p.second.first + value[i].first, start_p.second.second + value[i].second, matrix[start_p.second.first + value[i].first][start_p.second.second + value[i].second]);
					DFS({ start_p.first,{start_p.second.first + value[i].first,start_p.second.second + value[i].second} });
					//printf("���� %d %d %d %c\n", start_p.first, start_p.second.first + value[i].first, start_p.second.second + value[i].second, matrix[start_p.second.first + value[i].first][start_p.second.second + value[i].second]);
					start_p.first -= 1;
					visit[matrix[start_p.second.first + value[i].first][start_p.second.second + value[i].second] - 65] = 0;
				}
			}
		}
	}
	//printf("����\n");
	return;
}