#include <iostream>
#include <cstring>
#include <algorithm>

int dp[1001][10];

int main() {
	int N = 0;
	int sum = 0;
	memset(dp, 0, sizeof(dp));
	scanf("%d", &N);

	for (int x = 0; x < 10; x++) {
		dp[1][x] = 1;
	}

	for (int i = 2; i <= N; i++) {
		for (int j = 0; j < 10; j++) {
			for (int k = j; k < 10; k++) {
				dp[i][k] = (dp[i][k] + dp[i - 1][j]) % 10007;
			} 
		}
	}

	for (int i = 0; i < 10; i++) {
		sum = (sum + dp[N][i]) % 10007;
	}
	printf("%d", sum);
}