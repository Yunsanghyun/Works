#include <iostream>
#include <vector>
#include <cstring>
#include <queue>

void BFS(std::pair<int,int> start_p);
void print();

std::queue<std::pair<int,int>> bfs_q;
std::pair<int, int> start_point = { 0,0 };

char temp_matrix[101][101];
int matrix[101][101];
int visit[101][101];
int cnt[101][101];
int N, M;
int move_cnt = 0;

// 0,0���� ���, N-1,M-1�� ����
// ��� ����(�����¿�)�� ���ؼ� �̵� -> BFS�� ���ⱸ��
int main() {
	memset(visit, 0, sizeof(visit));
	memset(cnt, 0, sizeof(cnt));

	scanf("%d %d", &N, &M);
	for (int i = 0; i < N; i++)
		scanf("%s", temp_matrix[i]);

	for (int i = 0; i < N; i++)
		for (int j = 0; j < M; j++)
			matrix[i][j] = temp_matrix[i][j] - 48;

	BFS(start_point);

	printf("%d",move_cnt);
	return 0;
}

void BFS(std::pair<int,int> start_p) {
	std::pair<int, int> end_point = { N - 1, M - 1 };
	// ��,��,��,�쿡 ���� ������
	std::vector<std::pair<int, int>> value{ {-1,0},{1,0}, {0,-1}, {0,1} };

	bfs_q.push(start_p);
	cnt[start_p.first][start_p.second] = 1;

	while (bfs_q.empty() == 0) {
		start_p = bfs_q.front();
		//printf("%d %d \n", start_p.first, start_p.second);
		//print();

		bfs_q.pop();
		
		if (start_p == end_point) {
			move_cnt = cnt[start_p.first][start_p.second];
			break;
		}

		if (visit[start_p.first][start_p.second] == 0
			&& matrix[start_p.first][start_p.second] == 1) {
			visit[start_p.first][start_p.second] = 1;

			// ������ ��ġ�� 4������ ť�� ����
			for (int i = 0; i < 4; i++) {
				// �̵��� ��, �� ���� ���� �ȿ� ���� ��
				if (start_p.first + value[i].first >= 0 &&
					start_p.first + value[i].first < N) {
					if (start_p.second + value[i].second >= 0 &&
						start_p.second + value[i].second < M) {

						bfs_q.push({ start_p.first + value[i].first, start_p.second + value[i].second });
						//printf("ť�� %d %d �̷��� �־��� \n", start_p.first + value[i].first, start_p.second + value[i].second);
						cnt[start_p.first + value[i].first][start_p.second + value[i].second]
							= cnt[start_p.first][start_p.second] + 1;
					}
				}
			}
		}
	}
}

void print() {
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			printf("%d ", cnt[i][j]);
		}
		printf("\n");
	}
	printf("\n");

	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			printf("%d ", visit[i][j]);
		}
		printf("\n");
	}
}
