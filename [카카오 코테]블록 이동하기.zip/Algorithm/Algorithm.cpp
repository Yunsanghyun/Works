#include <string>
#include <vector>
#include <queue>

using namespace std;

int visit[101][101][101][101];

/// �湮üũ
void visit_chk(std::pair<std::pair<int, int>, std::pair<int, int>> cur_p) {
    visit[cur_p.first.first][cur_p.first.second][cur_p.second.first][cur_p.second.second] = 1;
    visit[cur_p.second.first][cur_p.second.second][cur_p.first.first][cur_p.first.second] = 1;
    return;
}

// ���� ���� �ִ��� üũ
int range_chk(std::pair<std::pair<int, int>, std::pair<int, int>>& new_p, int size) {
    // ���� ���� �ִ� ��츸
    if (0 <= new_p.first.first && new_p.first.first < size) {
        if (0 <= new_p.first.second && new_p.first.second < size) {
            if (0 <= new_p.second.first && new_p.second.first < size) {
                if (0 <= new_p.second.second && new_p.second.second < size) {
                    return 1;
                }
            }
        }
    }
    return 0;
}

// ���� ��ġ���� �̵��� �� �ִ� ��� ��ġ�� bfs_q�� ����
// ��, �̹� ���� ���̳�, ȸ���̳� �̵��� ���� ���� ���������� ����
// ������ ����� ����
void queue_add(std::pair<std::pair<int, int>, std::pair<int, int>> cur_p, int cur_cnt, vector<vector<int>> board, std::queue<std::pair<int, std::pair<std::pair<int, int>, std::pair<int, int>>>>& bfs_q) {
    std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };
    std::pair<std::pair<int, int>, std::pair<int, int>> new_p;

    std::pair<std::pair<int, int>, std::pair<int, int>> clock_first_p;
    std::pair<std::pair<int, int>, std::pair<int, int>> unclock_first_p;
    std::pair<std::pair<int, int>, std::pair<int, int>> clock_second_p;
    std::pair<std::pair<int, int>, std::pair<int, int>> unclock_second_p;

    std::pair<int, int> clock_first_route_p;
    std::pair<int, int> unclock_first_route_p;
    std::pair<int, int> clock_second_route_p;
    std::pair<int, int> unclock_second_route_p;

    // ��,��,��,��
    for (int i = 0; i < 4; i++) {
        new_p.first = { cur_p.first.first + value[i].first, cur_p.first.second + value[i].second };
        new_p.second = { cur_p.second.first + value[i].first, cur_p.second.second + value[i].second };

        // ���� ���� �ִ� ��츸
        if (range_chk(new_p, board.size())) {
            // ���� �ƴ� ��
            if (board[new_p.first.first][new_p.first.second] == 0 && board[new_p.second.first][new_p.second.second] == 0) {
                // �湮 ���Ѱ�
                if (visit[new_p.first.first][new_p.first.second][new_p.second.first][new_p.second.second] == 0) {
                    bfs_q.push({ cur_cnt + 1, new_p });
                    visit_chk(new_p);
                }
            }
        }
    }

    // first�� ����
    // �ð����
    // ���θ��
    if (cur_p.first.first == cur_p.second.first) {
        // first�� ������, second�� ����
        if (cur_p.first.second > cur_p.second.second) {
            clock_first_p.first = { cur_p.first.first, cur_p.first.second };
            clock_first_p.second = { cur_p.second.first - 1, cur_p.second.second + 1 };
            
            unclock_first_p.first = { cur_p.first.first, cur_p.first.second };
            unclock_first_p.second = { cur_p.second.first + 1, cur_p.second.second + 1 };
            
            clock_second_p.first = { cur_p.first.first + 1, cur_p.first.second - 1 };
            clock_second_p.second = { cur_p.second.first, cur_p.second.second };
            
            unclock_second_p.first = { cur_p.first.first - 1, cur_p.first.second - 1 };
            unclock_second_p.second = { cur_p.second.first, cur_p.second.second };

            clock_first_route_p = { cur_p.second.first - 1, cur_p.second.second };
            unclock_first_route_p = { cur_p.second.first + 1, cur_p.second.second };
            clock_second_route_p = { cur_p.first.first + 1, cur_p.first.second };
            unclock_second_route_p = { cur_p.first.first - 1, cur_p.first.second };
        }
        // first�� ����, second�� ������
        else {
            clock_first_p.first = { cur_p.first.first, cur_p.first.second };
            clock_first_p.second = { cur_p.second.first + 1 , cur_p.second.second - 1 };

            unclock_first_p.first = { cur_p.first.first, cur_p.first.second };
            unclock_first_p.second = { cur_p.second.first - 1, cur_p.second.second - 1 };

            clock_second_p.first = { cur_p.first.first - 1, cur_p.first.second + 1 };
            clock_second_p.second = { cur_p.second.first, cur_p.second.second };

            unclock_second_p.first = { cur_p.first.first + 1, cur_p.first.second + 1 };
            unclock_second_p.second = { cur_p.second.first, cur_p.second.second };
        
            clock_first_route_p = { cur_p.second.first + 1, cur_p.second.second };
            unclock_first_route_p = { cur_p.second.first - 1, cur_p.second.second };
            clock_second_route_p = { cur_p.first.first - 1, cur_p.first.second };
            unclock_second_route_p = { cur_p.first.first + 1, cur_p.first.second };
        }
    }
    // ���θ��
    else {
        // first�� �Ʒ� 
        if (cur_p.first.first > cur_p.second.first) {
            clock_first_p.first = { cur_p.first.first, cur_p.first.second };
            clock_first_p.second = { cur_p.second.first + 1, cur_p.second.second + 1 };

            unclock_first_p.first = { cur_p.first.first, cur_p.first.second };
            unclock_first_p.second = { cur_p.second.first + 1, cur_p.second.second - 1 };

            clock_second_p.first = { cur_p.first.first - 1, cur_p.first.second - 1 };
            clock_second_p.second = { cur_p.second.first, cur_p.second.second };

            unclock_second_p.first = { cur_p.first.first - 1, cur_p.first.second + 1 };
            unclock_second_p.second = { cur_p.second.first, cur_p.second.second };

            clock_first_route_p = { cur_p.second.first, cur_p.second.second + 1 };
            unclock_first_route_p = { cur_p.second.first, cur_p.second.second - 1 };
            clock_second_route_p = { cur_p.first.first, cur_p.first.second - 1};
            unclock_second_route_p = { cur_p.first.first, cur_p.first.second + 1};
        }
        // first�� ��
        else {
            clock_first_p.first = { cur_p.first.first, cur_p.first.second };
            clock_first_p.second = { cur_p.second.first - 1 , cur_p.second.second - 1 };

            unclock_first_p.first = { cur_p.first.first, cur_p.first.second };
            unclock_first_p.second = { cur_p.second.first - 1, cur_p.second.second + 1 };

            clock_second_p.first = { cur_p.first.first + 1, cur_p.first.second + 1 };
            clock_second_p.second = { cur_p.second.first, cur_p.second.second };

            unclock_second_p.first = { cur_p.first.first + 1, cur_p.first.second - 1 };
            unclock_second_p.second = { cur_p.second.first, cur_p.second.second };

            clock_first_route_p = { cur_p.second.first, cur_p.second.second - 1 };
            unclock_first_route_p = { cur_p.second.first, cur_p.second.second + 1 };
            clock_second_route_p = { cur_p.first.first, cur_p.first.second + 1 };
            unclock_second_route_p = { cur_p.first.first, cur_p.first.second - 1 };
        }
    }

    // ���� ���� �ִ� ��츸
    if (range_chk(clock_first_p, board.size()) && board[clock_first_route_p.first][clock_first_route_p.second] == 0) {
        // ���� �ƴ� ��
        if (board[clock_first_p.first.first][clock_first_p.first.second] == 0 && board[clock_first_p.second.first][clock_first_p.second.second] == 0) {
            // �湮 ���Ѱ�
            if (visit[clock_first_p.first.first][clock_first_p.first.second][clock_first_p.second.first][clock_first_p.second.second] == 0) {
                bfs_q.push({ cur_cnt + 1, clock_first_p });
                visit_chk(clock_first_p);
            }
        }
    }
    // ���� ���� �ִ� ��츸
    if (range_chk(clock_second_p, board.size()) && board[clock_second_route_p.first][clock_second_route_p.second] == 0) {
        // ���� �ƴ� ��
        if (board[clock_second_p.first.first][clock_second_p.first.second] == 0 && board[clock_second_p.second.first][clock_second_p.second.second] == 0) {
            // �湮 ���Ѱ�
            if (visit[clock_second_p.first.first][clock_second_p.first.second][clock_second_p.second.first][clock_second_p.second.second] == 0) {
                bfs_q.push({ cur_cnt + 1, clock_second_p });
                visit_chk(clock_second_p);
            }
        }
    }
    // ���� ���� �ִ� ��츸
    if (range_chk(unclock_first_p, board.size()) && board[unclock_first_route_p.first][unclock_first_route_p.second] == 0) {
        // ���� �ƴ� ��
        if (board[unclock_first_p.first.first][unclock_first_p.first.second] == 0 && board[unclock_first_p.second.first][unclock_first_p.second.second] == 0) {
            // �湮 ���Ѱ�
            if (visit[unclock_first_p.first.first][unclock_first_p.first.second][unclock_first_p.second.first][unclock_first_p.second.second] == 0){
                bfs_q.push({ cur_cnt + 1, unclock_first_p });
                visit_chk(unclock_first_p);
            }
        }
    }
    // ���� ���� �ִ� ��츸
    if (range_chk(unclock_second_p, board.size()) && board[unclock_second_route_p.first][unclock_second_route_p.second] == 0) {
        // ���� �ƴ� ��
        if (board[unclock_second_p.first.first][unclock_second_p.first.second] == 0 && board[unclock_second_p.second.first][unclock_second_p.second.second] == 0) {
            // �湮 ���Ѱ�
            if (visit[unclock_second_p.first.first][unclock_second_p.first.second][unclock_second_p.second.first][unclock_second_p.second.second] == 0) {
                bfs_q.push({ cur_cnt + 1, unclock_second_p });
                visit_chk(unclock_second_p);
            }
        }
    }
    return;
}

// ����Ȯ�� N - 1, N - 1
int arrive_chk(std::pair<std::pair<int, int>, std::pair<int, int>> cur_p, int N) {
    std::pair<int, int> dest_p = { N - 1, N - 1 };

    if (cur_p.first == dest_p || cur_p.second == dest_p)
        return 1;
    else
        return 0;
}

int BFS(vector<vector<int>> board) {
    int min_move_cnt = 0;
    int cur_move_cnt = 0;
    std::pair<std::pair<int, int>, std::pair<int, int>> cur_p;
    // ù��° �̵�Ƚ��, �ι�° ��ǥ
    std::queue<std::pair<int, std::pair<std::pair<int, int>, std::pair<int, int>>>> bfs_q;

    memset(visit, 0, sizeof(visit));

    bfs_q.push({ 0, { {0,0},{0,1} } });
    while (bfs_q.empty() == 0) {
        cur_move_cnt = bfs_q.front().first;
        cur_p = bfs_q.front().second;
        bfs_q.pop();

        printf("�̵��Ÿ� %d\n", cur_move_cnt);
        printf("���� ��ġ %d %d / %d %d\n", cur_p.first.first, cur_p.first.second, cur_p.second.first, cur_p.second.second);

        // ����Ȯ��
        if (arrive_chk(cur_p, board.size())) {
            min_move_cnt = cur_move_cnt;
            break;
        }
        // ���� �̵������� ��ġ�� queue�� Ǫ��
        queue_add(cur_p, cur_move_cnt, board, bfs_q);
    }
    return min_move_cnt;
}

int main() {
    int answer = 0;
    vector<vector<int>> board;
    vector<int> temp1{ 0,0,0,1,1 };
    vector<int> temp2{ 0,0,0,1,0 };
    vector<int> temp3{ 0,1,0,1,1 };
    vector<int> temp4{ 1,1,0,0,1 };
    vector<int> temp5{ 0,0,0,0,0 };

    board.push_back(temp1);
    board.push_back(temp2);
    board.push_back(temp3);
    board.push_back(temp4);
    board.push_back(temp5);

    answer = BFS(board);
    printf("�ּ� �̵�Ƚ���� %d\n", answer);

    return answer;
}