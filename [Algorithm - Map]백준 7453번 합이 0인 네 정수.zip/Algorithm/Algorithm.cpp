#include <iostream>
#include <algorithm>
#include <cstring>
#include <vector>

long long int first_arr[4001];
long long int second_arr[4001];
long long int third_arr[4001];
long long int forth_arr[4001];

int main() {
	int N = 0;
	scanf("%d", &N);

	for (int i = 0; i < N; i++) {
		scanf("%lld %lld %lld %lld", &first_arr[i], &second_arr[i], &third_arr[i], &forth_arr[i]);
	}

	std::vector<long long int> v;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			v.push_back(third_arr[i] + forth_arr[j]);
		}
	}

	std::sort(v.begin(), v.end());
	long long int answer = 0;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			long long int sum = first_arr[i] + second_arr[j];
			// key ���� ���ų� key ���� ū ���� ���� ��
			int low = std::lower_bound(v.begin(), v.end(), -sum) - v.begin();
			// key ���� �ʰ��ϴ� ù���� ����
			int high = std::upper_bound(v.begin(), v.end(), -sum) - v.begin();

			if (v[low] == -sum)
				answer += high - low;
		}
	}
	printf("%lld\n", answer);

	return 0;
}
