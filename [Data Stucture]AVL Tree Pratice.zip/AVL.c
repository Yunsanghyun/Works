#include <stdio.h>
#include "BinaryTree3.h"

int GetTreeHeight(BTreeNode* RootNode) {
	if (RootNode == NULL)
		return 0;

	int left_height = GetTreeHeight(GetLeftSubTree(RootNode));
	int right_height = GetTreeHeight(GetRightSubTree(RootNode));

	if (left_height > right_height)
		return left_height + 1;
	else
		return right_height + 1;

}
int GetChildHeightGap(BTreeNode* RootNode) {
	int left_height = GetTreeHeight(GetLeftSubTree(RootNode));
	int right_height = GetTreeHeight(GetRightSubTree(RootNode));

	return left_height - right_height;
}
BTreeNode* LLRotate(BTreeNode* RootNode) {
	if (RootNode == NULL)
		return NULL;
	
	BTreeNode* p_node = RootNode;
	BTreeNode* c_node = GetLeftSubTree(RootNode);

	ChangeLeftSubTree(p_node, GetRightSubTree(c_node));
	ChangeRightSubTree(c_node, p_node);
	
	return c_node;
}
BTreeNode* RRRotate(BTreeNode* RootNode) {
	if (RootNode == NULL)
		return NULL;

	BTreeNode* p_node = RootNode;
	BTreeNode* c_node = GetRightSubTree(RootNode);

	ChangeRightSubTree(p_node, GetLeftSubTree(c_node));
	ChangeLeftSubTree(c_node, p_node);

	return c_node;
}
BTreeNode* LRRotate(BTreeNode* RootNode) {
	if (RootNode == NULL)
		return NULL;

	BTreeNode* p_node = RootNode;
	BTreeNode* c_node = GetLeftSubTree(RootNode);

	ChangeLeftSubTree(p_node, RRRotate(c_node));
		
	return LLRotate(p_node);
}
BTreeNode* RLRotate(BTreeNode* RootNode) {
	if (RootNode == NULL)
		return NULL;

	BTreeNode* p_node = RootNode;
	BTreeNode* c_node = GetRightSubTree(RootNode);

	ChangeRightSubTree(p_node, LLRotate(c_node));
	
	return RRRotate(p_node);
}
BTreeNode* Rebalance(BTreeNode** RootNode){
	BTreeNode* p_node = *RootNode;
	BTreeNode* c_node;

	int height = GetChildHeightGap(*RootNode);

	// LL Ȥ�� LR
	if (height > 1) {
		c_node = GetLeftSubTree(*RootNode);

		// LL
		if (GetChildHeightGap(c_node) > 0) {
			p_node = LLRotate(p_node);
		}
		// LR
		else {
			p_node = LRRotate(p_node);
		}
	}
	else if (height < -1) {
		c_node = GetRightSubTree(*RootNode);

		// LL
		if (GetChildHeightGap(c_node) < 0) {
			p_node = RRRotate(p_node);
		}
		// LR
		else {
			p_node = RLRotate(p_node);
		}
	}

	return p_node;
}