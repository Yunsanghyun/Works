#include <stdio.h>
#include <stdlib.h>
#include "BinaryTree3.h"
#include "BinarySearchTree2.h"

int main(void)
{
	BTreeNode* AVL_root;
	BTreeNode* sNode;    // search node
	BTreeNode* LNode;
	BTreeNode* RNode;

	BSTMakeAndInit(&AVL_root);

	BSTInsert(&AVL_root, 1);
	BSTInsert(&AVL_root, 2);
	BSTInsert(&AVL_root, 3);
	BSTInsert(&AVL_root, 4);
	BSTInsert(&AVL_root, 5);
	BSTInsert(&AVL_root, 6);
	
	BSTShowAll(AVL_root);

	return 0;
}