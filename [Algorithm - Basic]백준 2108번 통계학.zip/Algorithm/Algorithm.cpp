#include <iostream>
#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>

using namespace std;

int chk(vector<pair<int, int>>& cnt_v, int num) {
	for (int i = 0; i < cnt_v.size(); i++) {
		if (cnt_v[i].second == num) {
			cnt_v[i].first += 1;
			return 1;
		}
	}
	return 0;
}

int main() {
	int num = 0;
	int temp = 0;
	int sum = 0;
	int min, max = 0;

	vector<int> total_v;
	vector<pair<int,int>> cnt_v;
	vector<int> min_cnt_v;

	scanf("%d", &num);
	for (int i = 0; i < num; i++) {
		scanf("%d", &temp);
		sum += temp;
		total_v.push_back(temp);

		if (chk(cnt_v, temp)) {
			;
		}
		else {
			cnt_v.push_back({ 1,temp });
		}
	}
	sort(total_v.begin(), total_v.end());
	sort(cnt_v.begin(), cnt_v.end());

	for (int i = 0; i < cnt_v.size(); i++) {
		if (cnt_v.back().first == cnt_v[i].first) {
			min_cnt_v.push_back(cnt_v[i].second);
		}
	}
	sort(min_cnt_v.begin(), min_cnt_v.end());
	
	printf("%.0lf\n", (double)sum / (double)num);
	printf("%d\n", total_v[num / 2]);

	if (min_cnt_v.size() == 1)
		printf("%d\n", min_cnt_v.front());
	else
		printf("%d\n", min_cnt_v[1]);

	printf("%d\n", total_v.back() - total_v.front());

	return 0;
}
