#define sub_height 1111111111111111
#define HASH_SIZE 100019

typedef long long ll;
typedef struct {
    int max_height;
    int min_height;
    ll block_arr;
}block_info;

// ���� arr���� ����Ǿ� �ִ� �ؽ�
ll hash_table[100019];
// ù���� ���������� ��, �ι�° ���� ����
block_info block_group[30001];
// �ؽ����̺����� ã�� ������ �迭
ll target_block[4] = { 0,0,0,0 };

// ������ �迭���� ������, �ؽ� ���̺��� ����
void hash_insert(ll block_info) {
    ll key = 0;
    key = (block_info * 17 - 7) % HASH_SIZE;

    while (hash_table[key] != -1) {
        key = (key + 1) % HASH_SIZE;
    }
    hash_table[key] = block_info;
    return;
}

// �ʱ�ȭ �� ���� ������ �����ϴ� �Լ�
void init(int num, int matrix[4][4]) {
    int cur_total_sum = 0;
    int cur_max_height = 0;
    int cur_min_height = 1e9;
    ll cur_block_arr = 0;

    for (int j = 0; j < 4; j++) {
        for (int k = 0; k < 4; k++) {
            cur_block_arr = cur_block_arr * 10 + matrix[j][k];
            cur_total_sum += matrix[j][k];
            if (cur_min_height > matrix[j][k])
                cur_min_height = matrix[j][k];
            if (cur_max_height < matrix[j][k])
                cur_max_height = matrix[j][k];
        }
    }
    block_info block;
    block.block_arr = cur_block_arr;
    block.max_height = cur_max_height;
    block.min_height = cur_min_height;
    block_group[num] = block;
    hash_insert(cur_block_arr);
}

void find_fit_block(int target_height, ll target_block_arr) {
    ll ref_block_arr = target_block_arr;
    ll new_block_arr = 0;
    int temp_arr[16];
    int new_arr[4][16];
    int cur_num = 0;

    for (int i = 0; i < 4; i++)
        target_block[i] = 0;


    //printf("���� ���� %lld / ��ǥ ���� %d\n", target_block_arr, target_height);

    for (int i = 0; i < 16; i++) {
        cur_num = target_height - ref_block_arr % 10;
        ref_block_arr /= 10;
        temp_arr[15 - i] = cur_num;
    }

    /*for (int i = 0; i < 16; i++) {
        printf("%d", temp_arr[i]);
    }
    printf("\n");*/

    //0�� 
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            new_arr[0][4 * i + j] = temp_arr[4 * i + 3 - j];
        }
    }
    //90�� 
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            new_arr[1][3 - i + j * 4] = new_arr[0][4 * i + j];
        }
    }
    //180�� 
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            new_arr[2][3 - i + j * 4] = new_arr[1][4 * i + j];
        }
    }
    //270�� 
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            new_arr[3][3 - i + j * 4] = new_arr[2][4 * i + j];
        }
    }

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 16; j++) {
            target_block[i] = target_block[i] * 10 + new_arr[i][j];
        }
        //printf("ã�� ���� %lld\n", target_block[i]);
    }
    return;
}

int search_hash(ll target_block_arr) {
    ll key = 0;
    key = (target_block_arr * 17 - 7) % HASH_SIZE;

    while (hash_table[key] != -1) {
        if (hash_table[key] == target_block_arr) {
            return key;
        }
        else
            key = (key + 1) % HASH_SIZE;
    }
    return -1;
}

int makeBlock(int module[][4][4]) {
    int save_height_sum = 0;

    for (int i = 0; i < HASH_SIZE; i++) {
        hash_table[i] = -1;
    }

    for (int i = 0; i < 30000; i++) {
        init(i, module[i]);
    }

    for (int i = 0; i < 30000; i++) {
        int cur_max_height = block_group[i].max_height;
        int cur_min_height = block_group[i].min_height;
        ll cur_block_arr = block_group[i].block_arr;
        int target_height = cur_min_height + 8;
        int target_min_height = cur_max_height + 1;
        int arr_num = 0;
        int flag = 0;

        find_fit_block(target_height, cur_block_arr);
        while (flag == 0 && target_height >= target_min_height) {

            for (int j = 0; j < 4; j++) {
                arr_num = search_hash(target_block[j]);
                if (arr_num != -1 && target_block[j] != cur_block_arr) {
                    hash_table[arr_num] = -1;
                    arr_num = search_hash(cur_block_arr);
                    hash_table[arr_num] = -1;

                    flag = 1;
                    save_height_sum += target_height;

                    /*printf("����\n");
                    printf("���� %lld\n", cur_block_arr);
                    printf("���� %lld\n", target_block[j]);
                    printf("���� %d / ���� ���� %d\n", target_height, save_height_sum);*/

                    break;
                }
            }

            // ��ġ�ϴ� ������ ���� ��, ���̸� �Ѵܰ� ����
            if (flag == 0) {
                target_height -= 1;
                target_block[0] -= sub_height;
                target_block[1] -= sub_height;
                target_block[2] -= sub_height;
                target_block[3] -= sub_height;
            }
        }
    }
    return save_height_sum;
}