#include <stdio.h>
#include <string.h>
#include "DBLinkedList.h"

int main(void)
{
	List list;
	int data = 0;;

	ListInit(&list);

	LInsert(&list, 1);
	LInsert(&list, 2);
	LInsert(&list, 3);
	LInsert(&list, 4);
	LInsert(&list, 5);

	if (LFirst(&list, &data)) {
		printf("%d", data);

		while (LNext(&list, &data)) {
			printf("%d", data);
		}

		while (LPrev(&list, &data)) {
			printf("%d", data);
		}
	}

	if (LFirst(&list, &data)) {
		while (LNext(&list, &data)) {
			if (data % 2 == 0) {
				printf("\n������ ��, ������ data�� %d\n", LRemove(&list));
			}
		}

		while (LPrev(&list, &data)) {
			if (data % 3 == 0) {
				printf("\n������ ��, ������ data�� %d\n", LRemove(&list));
			}
		}
	}

	if (LFirst(&list, &data)) {
		printf("%d", data);

		while (LNext(&list, &data)) {
			printf("%d", data);
		}

		while (LPrev(&list, &data)) {
			printf("%d", data);
		}
	}

	

	return 0;
}