#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>

void print_f();
int shock_chk();
void test_start();
void select_line_num(int ele_num, int start_num);

int map[14][21];
int line_visit[14];
int line_num_v[14];

int D, W, K = 0;
int min_chemi = 1e9;

int main() {
	int test_case = 0;

	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		memset(map, 0, sizeof(map));
		memset(line_visit, 0, sizeof(line_visit));
		memset(line_num_v, 0, sizeof(line_num_v));

		min_chemi = 1e9;

		scanf("%d %d %d", &D, &W, &K);
		for (int j = 0; j < D; j++) {
			for (int k = 0; k < W; k++) {
				scanf("%d", &map[j][k]);
			}
		}

		test_start();
		if (min_chemi == 1e9)
			min_chemi = 0;

		printf("#%d %d\n", i, min_chemi);
	}
	return 0;
}

int ele_cnt = 0;
int finished = 0;
void test_start() {
	if (shock_chk()) {
		return;
	}
	else {
		for (int i = 1; i <= K - 1; i++) {
			memset(line_visit, 0, sizeof(line_visit));
			memset(line_num_v, 0, sizeof(line_num_v));
			ele_cnt = 0;
			finished = 0;

			//printf("%d���� ������ ������ ���̽�\n",i);
			select_line_num(i, 0);
			if (finished == 1)
				break;
		}
		if (finished == 0)
			min_chemi = K;
	}
}

// ù��° ���ȣ, �ι��� ��ǰ��ȣ
// ���� ��ĥ�� �ʿ䰡 �����ʳ�
//std::vector<std::pair<int, int>> line_num_v;
void select_line_num(int ele_num, int start_num) {
	if (ele_cnt == ele_num) {
		/*printf("\n���õ� ��\n");
		for (int i = 0; i < D; i++)
			printf("%d ", line_num_v[i]);
		printf("\n");*/


		if (shock_chk()) {
			//printf("����\n");
			if (min_chemi > ele_cnt)
				min_chemi = ele_cnt;
			finished = 1;
		}
		return;
	}

	for (int i = start_num; i < D; i++) {
		for (int j = 1; j <= 2; j++) {
			if (line_visit[i] == 0 && finished == 0) {
				line_visit[i] = 1;
				line_num_v[i] = j;
				ele_cnt++;

				//printf("���� %d %d\n", i, j);
				select_line_num(ele_num, i + 1);
				//printf("���� %d %d\n", i, j);

				line_visit[i] = 0;
				line_num_v[i] = 0;
				ele_cnt--;
			}
		}
	}
}

// ��� ���� �˻��ؼ� ���� ���ڰ� �������� K�� �������� Ȯ��
int shock_chk() {
	int target_num = 0;
	int same_cnt = 0;

	for (int i = 0; i < W; i++) {
		// ù��° �࿡ ��ǰ�� ���ԵǾ��� ���
		if (line_visit[0] == 0) {
			target_num = map[0][i];
		}
		else {
			target_num = line_num_v[0] - 1;
		}

		same_cnt = 1;
		for (int j = 1; j < D; j++) {
			if ((line_visit[j] == 0 && map[j][i] == target_num) ||
				(line_visit[j] == 1 && line_num_v[j] - 1 == target_num)) {
				same_cnt++;
				if (same_cnt >= K)
					break;
			}
			else {
				if(line_visit[j] == 0)
					target_num = map[j][i];
				else
					target_num = line_num_v[j] - 1;

				same_cnt = 1;
			}
		}
		if (same_cnt < K)
			return 0;
	}
	return 1;
}