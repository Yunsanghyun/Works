#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

vector<pair<string, int>> v;

int sum = 1;

// ī�װ����� ������ ���� �߰�, ������ 1 ����
void vec_add(string temp_category) {
	int flag = 0;
	for (int i = 0; i < v.size(); i++) {
		if (v[i].first == temp_category) {
			v[i].second += 1;
			return;
		}
	}
	v.push_back({ temp_category,1 });
	return;
}

int main() {
	int test_case = 0;
	int item_num = 0;
	string temp_cloth;
	string temp_category;
	string category;
	scanf("%d", &test_case);

	for (int i = 0; i < test_case; i++) {
		sum = 1;
		v.clear();
		scanf("%d", &item_num);
		for (int j = 0; j < item_num; j++) {
			cin >> temp_cloth >> temp_category;
			vec_add(temp_category);
		}
		for (int j = 0; j < v.size(); j++) {
			sum *= v[j].second + 1;
		}
		printf("%d\n", sum - 1);
	}
	return 0;
}