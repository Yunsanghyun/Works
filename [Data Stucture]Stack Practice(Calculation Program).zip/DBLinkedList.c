#include <stdio.h>
#include <stdlib.h>
#include "DBLinkedList.h"

void ListInit(List * plist)
{
	Node* head_dummy = (Node*)malloc(sizeof(Node));
	Node* tail_dummy = (Node*)malloc(sizeof(Node));
	plist->head = head_dummy;
	plist->tail = tail_dummy;
	plist->head->next = plist->tail;
	plist->tail->prev = plist->head;
	plist->head->prev = NULL;
	plist->tail->next = NULL;

	plist->cur = NULL;
	plist->numOfData = 0;
}

// tail �ʿ� ��� �߰�
void LInsert(List * plist, Data data){
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->data = data;

	newNode->prev = plist->tail->prev;
	plist->tail->prev->next = newNode;

	plist->tail->prev = newNode;
	newNode->next = plist->tail;

	plist->numOfData++;
}

// ���ο� ��尡 ������ �߰��������� Head�� �ִ°� ���� ù���� ���
int LFirst(List * plist, Data* data){
	if (plist->head->next == NULL) {
		return FALSE;
	}

	plist->cur = plist->head->next;
	*data = plist->cur->data;

	return TRUE;
}

int LNext(List * plist, Data* data){
	if (plist->cur->next->next == NULL) {
		return FALSE;
	}
	plist->cur = plist->cur->next;
	*data = plist->cur->data;

	return TRUE;
}

int LPrev(List* plist, Data* data) {
	if (plist->cur->prev->prev == NULL) {
		return FALSE;
	}
	plist->cur = plist->cur->prev;
	*data = plist->cur->data;

	return TRUE;
}

//���� ��带 �����ϰ�, ���� ��ȯ
Data LRemove(List * plist){
	Node* node_temp = (Node*)malloc(sizeof(Node));
	node_temp = plist->cur;
	int data_temp = plist->cur->data;

	plist->cur->prev->next = plist->cur->next;
	plist->cur->next->prev = plist->cur->prev;
	plist->cur = plist->cur->prev;

	free(node_temp);

	plist->numOfData--;

	return data_temp;
}

int LCount(List * plist)
{
	return plist->numOfData;
}
