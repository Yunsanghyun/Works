#include <stdio.h>

static int num1 = 10;

void print() {
	printf("%d\n",num1);
}