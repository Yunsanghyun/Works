#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>

// ������ ���� �з�
void select(int num);
// 0,0 ���������� ������ �Ÿ��� �־��� 4�� ��ǥ�� �־����� ���ƴٴϸ鼭 �ִ밪�� ����
int search(std::pair<int, int> first, std::pair<int, int> second,
	std::pair<int, int> third, std::pair<int, int> forth);

std::vector<int> max_v;

int line, column;
int matrix[500][500];

int main() {
	int temp = 0;
	int max = 0;
	scanf("%d %d", &line, &column);

	for (int i = 0; i < line; i++) {
		for (int j = 0; j < column; j++) {
			scanf("%d", &matrix[i][j]);
		}
	}

	// 1 ~ 5���� ������ ������ ���ϰ�, 
	// �ִ밪�� ���
	for (int k = 1; k <= 5; k++) {
		select(k);
	}
	std::vector<int>::iterator itr;
	for (itr = max_v.begin(); itr != max_v.end(); itr++) {
		//printf("�ִ밪 ���ʹ� %d\n", *itr);
		if (max < *itr)
			max = *itr;
	}

	printf("%d", max);

	return 0;
}

// 1�� �׸�, 2�� ���ڸ���, 3�� ��ť, 4�� Z, 5�� ����
void select(int num) {
	switch (num) {
		// �׸�
	case 1:
		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(0, 1),
			std::make_pair(1, 0), std::make_pair(1, 1)));
		break;
		// ���ڸ���
	case 2:
		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(0, 1),
			std::make_pair(0, 2), std::make_pair(0, 3)));
		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(1, 0),
			std::make_pair(2, 0), std::make_pair(3, 0)));
		break;
		// ��ť
	case 3:
		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(0, 1),
			std::make_pair(0, 2), std::make_pair(1, 1)));

		max_v.push_back(search(std::make_pair(0, 1), std::make_pair(1, 0),
			std::make_pair(1, 1), std::make_pair(2, 1)));

		max_v.push_back(search(std::make_pair(0, 1), std::make_pair(1, 0),
			std::make_pair(1, 1), std::make_pair(1, 2)));

		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(1, 0),
			std::make_pair(1, 1), std::make_pair(2, 0)));
		break;
		// Z
	case 4:
		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(1, 0),
			std::make_pair(1, 1), std::make_pair(2, 1)));

		max_v.push_back(search(std::make_pair(0, 1), std::make_pair(0, 2),
			std::make_pair(1, 0), std::make_pair(1, 1)));

		max_v.push_back(search(std::make_pair(0, 1), std::make_pair(1, 0),
			std::make_pair(1, 1), std::make_pair(2, 0)));

		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(0, 1),
			std::make_pair(1, 1), std::make_pair(1, 2)));
		break;
	case 5:
		// ����
		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(1, 0),
			std::make_pair(2, 0), std::make_pair(2, 1)));

		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(0, 1),
			std::make_pair(0, 2), std::make_pair(1, 0)));

		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(0, 1),
			std::make_pair(1, 1), std::make_pair(2, 1)));

		max_v.push_back(search(std::make_pair(0, 2), std::make_pair(1, 0),
			std::make_pair(1, 1), std::make_pair(1, 2)));


		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(0, 1),
			std::make_pair(1, 0), std::make_pair(2, 0)));

		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(1, 0),
			std::make_pair(1, 1), std::make_pair(1, 2)));

		max_v.push_back(search(std::make_pair(0, 1), std::make_pair(1, 1),
			std::make_pair(2, 0), std::make_pair(2, 1)));

		max_v.push_back(search(std::make_pair(0, 0), std::make_pair(0, 1),
			std::make_pair(0, 2), std::make_pair(1, 2)));

		break;
	}

	return;
}

// 0,0 �������� �󸶳� �������ִ���
int search(std::pair<int, int> first, std::pair<int, int> second,
	std::pair<int, int> third, std::pair<int, int> forth) {
	int max_sum = 0;
	int temp = 0;

	for (int i = 0; i < line; i++) {
		for (int j = 0; j < column; j++) {
			temp = 0;
			if (i + first.first < line && i + second.first < line &&
				i + third.first < line && i + forth.first < line &&

				j + first.second < column && j + second.second < column &&
				j + third.second < column && j + forth.second < column) {

				temp = matrix[i + first.first][j + first.second] +
					matrix[i + second.first][j + second.second] +
					matrix[i + third.first][j + third.second] +
					matrix[i + forth.first][j + forth.second];

				if (max_sum < temp)
					max_sum = temp;
			}
		}
	}

	//printf("max_sum ���� %d \n", max_sum);
	return max_sum;
}
