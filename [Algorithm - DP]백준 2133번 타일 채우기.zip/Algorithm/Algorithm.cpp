#include <iostream>
#include <cstring>
#include <cmath>

int dp[31];

int main() {
    memset(dp, 0, sizeof(dp));
    int case_sum = 0;
	int N = 0;
	scanf("%d", &N);

	// Ȧ���� ��, ����� �� = 0
	if (N % 2 == 1)
		printf("0\n");
	// ¦�� �� ��,
	else {
		// dp[2] = 3 * dp[1] + 2;
		// dp[3] = 3 * dp[2] + 2 * dp[1] + 2;
		// dp[4] = 3 * dp[3] + 2 * dp[2] + 2 * dp[1] + 2;  
		// dp[i] = 3 * dp[i - 1] + 2 (dp[i - 2] + dp[i - 3] + ... + 1) 

		dp[1] = 3;
		// 2,4,6,8 -> 1,2,3,4
		int num = N / 2;
		int sum = 1;
		for (int i = 2; i <= num; i++) {
			dp[i] = 3 * dp[i - 1] + 2 * sum;
			sum += dp[i - 1];
		}

		printf("%d\n", dp[num]);
	}

	return 0;
}