#include <iostream>
#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>

using namespace std;

void find_prime(int num, vector<pair<int,int>>& v) {
	int start = 2;
	while (num != 1) {
		for (int i = start; i <= num; i++) {
			if (num % i == 0) {
				num /= i;
				start = i;
				if (v.size() == 0 || v.back().first != i)
					v.push_back({ i,1 });
				else
					v.back().second += 1;
				break;
			}
		}
	}
}

int main() {
	int first,second = 0;
	int max_num = 1, min_num = 1;
	vector<pair<int,int>> first_v;
	vector<pair<int,int>> second_v;

	scanf("%d %d", &first,&second);

	if (first == 1 || second == 1) {
		printf("%d\n", max(first, second));
		printf("%d\n", max(first, second));
	}

	find_prime(first,first_v);
	find_prime(second, second_v);

	// �ּҺ��� ã��,
	// ���� ���Ѱſ��� �ּҰ������ ������ �ִ� �����
	for (int i = 0; i < first_v.size(); i++) {
		for (int j = 0; j < second_v.size(); j++) {
			if (first_v[i].first == second_v[j].first) {
				min_num *= pow(first_v[i].first, min(first_v[i].second, second_v[j].second));
			}
		}
	}
	max_num = (first * second) / min_num;
	printf("%d\n", min_num);
	printf("%d\n", max_num);
	return 0;
}
