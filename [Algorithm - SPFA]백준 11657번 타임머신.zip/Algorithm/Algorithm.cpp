#include <iostream>
#include <cstring>
#include <vector>
#include <queue>

#define INF 1e9;

using namespace std;

// �ʱⰪ�� ���Ѵ�
long long int map[501];
int visit_cnt[501];
int N = 0;
int M = 0;

// ���� ���� ��ġ, ���尪�� �������� �Ÿ�
vector<pair<int,int>> dist[501];

int SPFA(int start_p) {
	int cur_p = 0;
	int next_p = 0;
	long long int next_cost = 0;

	queue<int> que;
	que.push(start_p);

	while (!que.empty()) {
		cur_p = que.front();
		que.pop();
		visit_cnt[cur_p] += 1;

		if (visit_cnt[cur_p] > N + 1)
			return 0;

		for (int i = 0; i < dist[cur_p].size(); i++) {
			next_p = dist[cur_p][i].first;
			next_cost = dist[cur_p][i].second;

			if (map[cur_p] + next_cost < map[next_p]) {
				map[next_p] = map[cur_p] + next_cost;
				que.push(next_p);
			}
		}
	}
	return 1;
}

int main(void) {
	int temp_start = 0;
	int temp_end = 0;
	int temp_cost = 0;

	scanf("%d %d", &N, &M);
	memset(visit_cnt, 0, sizeof(visit_cnt));

	for (int i = 1; i <= N; i++) {
		map[i] = 1e9;
	}

	for (int i = 0; i < M; i++) {
		scanf("%d %d %d", &temp_start, &temp_end, &temp_cost);
		dist[temp_start].push_back({ temp_end,temp_cost });
	}

	map[1] = 0;

	if (SPFA(1)) {
		for (int i = 2; i <= N; i++) {
			if (map[i] == 1e9) {
				printf("-1\n");
			}
			else
				printf("%d\n", map[i]);
		}
	}
	else {
		printf("-1\n");
	}
	return 0;
}