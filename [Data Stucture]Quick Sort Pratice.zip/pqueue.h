#ifndef __USEFUL_PQUEUE_H__
#define __USEFUL_PQUEUE_H__

#include "Heap.h"

void Init_pqueue(Heap* pq, PriorityComp pc);
void Enqueue(Heap* pq, HData data);
HData Dequeue(Heap* pq);
int QIsEmpty(Heap* pq);

#endif