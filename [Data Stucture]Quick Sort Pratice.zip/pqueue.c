#include "pqueue.h"

void Init_pqueue(Heap* pq, PriorityComp pc) {
	HeapInit(pq, pc);
}
void Enqueue(Heap* pq, HData data) {
	HInsert(pq, data);
}
HData Dequeue(Heap* pq) {
	HDelete(pq);
}
int QIsEmpty(Heap* pq) {
	HIsEmpty(pq);
}