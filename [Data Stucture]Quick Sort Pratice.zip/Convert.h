#ifndef __CONVER_H__
#define __CONVER_H__

#include "ListStack.h"

void convert(char* arr);
int priority(char opr);
int compare(char opr1, char opr2);

#endif