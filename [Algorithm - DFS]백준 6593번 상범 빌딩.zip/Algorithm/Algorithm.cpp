#include <iostream>
#include <cmath>
#include <queue>
#include <vector>
#include <cstring>

void DFS(std::pair<int, std::pair<int, int>> start_p);
void BFS(std::pair<int, std::pair<int, int>> start_p);
int check_range(std::pair<int, std::pair<int, int>> check_p);
void print_f();

char matrix[31][31][31];
int visit[31][31][31];
int cnt[31][31][31];
//std::pair<int, std::pair<int, int>> bfs_q[54001];

int L, R, C = 0;
int spend_time = 0;
int min_time = 1e9;
int wall_cnt = 0;

// ù��° ����, �ι��� ��ǥ
std::pair<int, std::pair<int, int>> start_p;
std::pair<int, std::pair<int, int>> end_p;
//��,��,��,��,��,��
std::vector<std::pair<int, std::pair<int, int>>> value{ {0,{0,1}},{0,{0,-1}},{0,{1,0}},{0,{-1,0}},{-1,{0,0}},{1,{0,0}} };

int main() {
	while (1) {
		memset(matrix, 0, sizeof(matrix));
		memset(visit, 0, sizeof(visit));
		memset(cnt, 0, sizeof(cnt));

		spend_time = 0;
		min_time = 1e9;
		wall_cnt = 0;

		scanf("%d %d %d", &L, &R, &C);

		if (L == 0 && R == 0 && C == 0)
			break;

		// ���� ���� �Է�
		for (int i = 0; i < L; i++) {
			for (int j = 0; j < R; j++) {
				scanf("%s", &matrix[i][j]);
				// �����, ������ ��ġȮ��
				for (int k = 0; k < C; k++) {
					if (matrix[i][j][k] == 'S')
						start_p = { i,{j,k} };
					if (matrix[i][j][k] == 'E')
						end_p = { i,{j,k} };
					if (matrix[i][j][k] == '#')
						wall_cnt++;
				}
			}
		}

		//DFS(start_p);
		BFS(start_p);
		int temp = 0;

		//while (1) {
		//	if (bfs_q[temp].first == -1)
		//		break;

		//	printf("bfs_q[%d] = %d %d %d\n", temp, bfs_q[temp].first, bfs_q[temp].second.first, bfs_q[temp].second.second);
		//	temp++;
		//}

		if (min_time != 1e9)
			printf("Escaped in %d minute(s).\n", min_time);
		else
			printf("Trapped!\n");
	}
	return 0;
}

void DFS(std::pair<int, std::pair<int, int>> start_p) {
	print_f();
	// Ż�ⱸ�� �������� ��,
	if (start_p == end_p) {
		if (min_time > spend_time)
			min_time = spend_time;

		return;
	}

	for (int i = 0; i < 6; i++) {
		std::pair<int, std::pair<int, int>> new_p = { start_p.first + value[i].first, {start_p.second.first + value[i].second.first ,start_p.second.second + value[i].second.second } };
		// ���� �� �ְ�, �湮 X, ��ĭ
		if (check_range(new_p) && visit[new_p.first][new_p.second.first][new_p.second.second] == 0) {
			if (matrix[new_p.first][new_p.second.first][new_p.second.second] != '#') {
				visit[new_p.first][new_p.second.first][new_p.second.second] = 1;
				spend_time += 1;

				DFS(new_p);

				visit[new_p.first][new_p.second.first][new_p.second.second] = 0;
				spend_time -= 1;
			}
		}
	}
	return;
}

void BFS(std::pair<int, std::pair<int, int>> start_p) {
	std::queue< std::pair<int, std::pair<int, int>>> bfs_q;
	std::pair<int, std::pair<int, int>> new_p;
	int arr_cnt = 0;
	int back_arr_cnt = 0;

	visit[start_p.first][start_p.second.first][start_p.second.second] = 1;
	bfs_q.push(start_p);
	//bfs_q[arr_cnt] = start_p;
	//back_arr_cnt++;

	while (bfs_q.empty() == 0) {
		start_p = bfs_q.front();
		bfs_q.pop();

		//visit[start_p.first][start_p.second.first][start_p.second.second] = 1;

		print_f();

		if (start_p == end_p) {
			if (min_time > cnt[start_p.first][start_p.second.first][start_p.second.second])
				min_time = cnt[start_p.first][start_p.second.first][start_p.second.second];
			return;
		}

		for (int i = 0; i < 6; i++) {
			new_p = { start_p.first + value[i].first, {start_p.second.first + value[i].second.first ,start_p.second.second + value[i].second.second } };
			// ���� �� �ְ�, �湮 X, ��ĭ
			if (check_range(new_p) && visit[new_p.first][new_p.second.first][new_p.second.second] == 0) {
				if (matrix[new_p.first][new_p.second.first][new_p.second.second] != '#') {
					cnt[new_p.first][new_p.second.first][new_p.second.second] = cnt[start_p.first][start_p.second.first][start_p.second.second] + 1;
					visit[new_p.first][new_p.second.first][new_p.second.second] = 1;
					bfs_q.push(new_p);
				}
			}
		}
	}
}

int check_range(std::pair<int, std::pair<int, int>> check_p) {
	// �ǹ� ��, �ִ���
	if (check_p.first >= 0 && check_p.first < L) {
		if (check_p.second.first >= 0 && check_p.second.first < R) {
			if (check_p.second.second >= 0 && check_p.second.second < C) {
				return 1;
			}
		}
	}

	return 0;
}

void print_f() {
	printf("visit\n");
	for (int i = 0; i < L; i++) {
		for (int j = 0; j < R; j++) {
			for (int k = 0; k < C; k++) {
				printf("%d ", visit[i][j][k]);
			}
			printf("\n");
		}
		printf("\n");
	}
	printf("\n");

	printf("cnt\n");
	for (int i = 0; i < L; i++) {
		for (int j = 0; j < R; j++) {
			for (int k = 0; k < C; k++) {
				printf("%d ", cnt[i][j][k]);
			}
			printf("\n");
		}
		printf("\n");
	}
	printf("\n");
}