#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>

void print_f();
void chk_rotate(int cur_num);
void cur_rotate(int cur_num, int cur_direction);
void rotate(int start_num, int direction);

int total_info[5][10];
int K_info[21][2];

int K = 0;

int main() {
	int test_case = 0;
	int point_sum = 0;
	
	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		memset(total_info, 0, sizeof(total_info));
		memset(K_info, 0, sizeof(K_info));
		point_sum = 0;

		scanf("%d", &K);

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				scanf("%d ", &total_info[i][j]);
			}
		}
		
		for (int i = 0; i < K; i++) {
			scanf("%d %d", &K_info[i][0], &K_info[i][1]);
		}

		// ��� ��ȣ�� �߽����� ����� ����� ������
		for (int i = 0; i < K; i++) {
			//printf("%d %d ȸ��\n", K_info[i][0], K_info[i][1]);
			rotate(K_info[i][0], K_info[i][1]);
			
		}

		for (int i = 0; i < 4; i++) {
			if (total_info[i][0] == 1) {
				point_sum += std::pow(2, i);
			}
		}

		printf("#%d %d\n", i, point_sum);
	}
	return 0;
}

std::vector<int> next_rotate_v;
int visit[5];
// �Ѿ���� ��Ϲ�ȣ�� 1 ~ 4
void rotate(int start_num, int direction) {
	std::queue < std::pair<int, int>> bfs_q;
	std::pair<int, int> cur_info;
	memset(visit, 0, sizeof(visit));
	int next_rorate_num = 0;

	cur_info = { start_num, direction };
	bfs_q.push(cur_info);
	while (bfs_q.empty() == 0) {
		cur_info = bfs_q.front();
		bfs_q.pop();
		visit[cur_info.first] = 1;

		//printf("���� �����ִ� �� %d / ȸ������ %d\n", cur_info.first,cur_info.second);

		//���� ���ư��� ��ϸ� ã�´�
		chk_rotate(cur_info.first);
		// ���� ��ϸ� ������
		cur_rotate(cur_info.first, cur_info.second);

		//print_f();

		for (int i = 0; i < next_rotate_v.size(); i++) {
			if (visit[next_rotate_v[i]] == 0) {
				//printf("������ ���ư� �� %d\n", next_rotate_v[i]);
				bfs_q.push({ next_rotate_v[i], cur_info.second * -1 });
			}
		}
	}
}

// ���� ��ϸ� ����
void cur_rotate(int cur_num, int cur_direction) {
	int temp = 0;
	// �ð���� ȸ��
	if (cur_direction == 1) {
		temp = total_info[cur_num - 1][7];
		for (int i = 6; i >= 0; i--) {
			total_info[cur_num - 1][i + 1] = total_info[cur_num - 1][i];
		}
		total_info[cur_num - 1][0] = temp;
	}
	// �ݽð���� ȸ��
	else {
		temp = total_info[cur_num - 1][0];
		for (int i = 0; i < 7; i++) {
			total_info[cur_num - 1][i] = total_info[cur_num - 1][i + 1];
		}
		total_info[cur_num - 1][7] = temp;
	}
	return;
}

// �پ��ִ� ��� ��, �ؼ��� �ٸ���
void chk_rotate(int cur_num) {
	next_rotate_v.clear();
	
	if (cur_num == 1) {
		if (total_info[0][2] != total_info[1][6]) {
			next_rotate_v.push_back(2);
		}
	}
	else if (cur_num == 2) {
		if (total_info[1][6] != total_info[0][2]) {
			next_rotate_v.push_back(1);
		}
		if (total_info[1][2] != total_info[2][6]) {
			next_rotate_v.push_back(3);
		}
	}	
	else if (cur_num == 3) {
		if (total_info[2][6] != total_info[1][2]) {
			next_rotate_v.push_back(2);
		}
		if (total_info[2][2] != total_info[3][6]) {
			next_rotate_v.push_back(4);
		}
	}
	else {
		if (total_info[3][6] != total_info[2][2]) {
			next_rotate_v.push_back(3);
		}
	}
	return;
}

void print_f() {
	printf("\n���� ��ϻ�Ȳ\n");
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 8; j++) {
			printf("%d ", total_info[i][j]);
		}
		printf("\n");
	}
}