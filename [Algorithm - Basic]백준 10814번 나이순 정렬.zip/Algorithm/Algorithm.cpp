#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

// ���̼�, ���� ����� ����

char name_arr[10001][101];

int main() {
	int num = 0;
	int age = 0;
	vector<pair<int, int>> v;
	scanf("%d", &num);
	memset(name_arr, 0, sizeof(name_arr));

	for (int i = 0; i < num; i++) {
		scanf("%d", &age);
		scanf("%s", name_arr[i]);
		v.push_back({ age,i });
	}

	sort(v.begin(), v.end());

	for (int i = 0; i < v.size(); i++) {
		printf("%d ", v[i].first);
		printf("%s\n", name_arr[v[i].second]);
	}
	return 0;
}