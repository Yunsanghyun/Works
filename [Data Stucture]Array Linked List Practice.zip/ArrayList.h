#ifndef ARR_LIST_H
#define ARR_LIST_H

#define list_len 100 

typedef int data_def;

typedef struct arr_list_struct {
	data_def arr[list_len];
	int data_num;
	int curPosition;
}arr_list;

typedef arr_list List;

void ListInit(List* list);
void LInsert(List* list, data_def data);
int LFirst(List* list, data_def* data);
int LNext(List* list, data_def* data);
data_def LRemove(List* list);
int LCount(List* list);

#endif
