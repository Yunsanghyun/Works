#include <stdio.h>
#include "ArrayList.h"

void ListInit(List* list) {
	list->data_num = 0;
	list->curPosition = 0;
}
void LInsert(List* list, data_def data) {
	if (list->data_num >= list_len) {
		printf("������ �Ұ����մϴ�.");
		return;
	}
	list->arr[list->data_num] = data;
	list->data_num++;
}
int LFirst(List* list, data_def* data) {
	list->curPosition = 0;
	if (list->arr[list->curPosition]) {
		*data = list->arr[list->curPosition];
		return 1;
	}
	else
		return 0;
}
int LNext(List* list, data_def* data) {
	list->curPosition++;
	if (list->arr[list->curPosition] && list->curPosition < list->data_num) {
		*data = list->arr[list->curPosition];
		return 1;
	}
	else 
		return 0;
	
}
data_def LRemove(List* list) {
	int temp = list->arr[list->curPosition];

	for (int i = list->curPosition; i < list->data_num; i++) {
		list->arr[i] = list->arr[i + 1];
	}
	list->data_num--;
	list->curPosition--;

	return temp;
}

int LCount(List* list) {
	return list->data_num;
}
