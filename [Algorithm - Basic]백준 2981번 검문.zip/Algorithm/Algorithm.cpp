#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<int> v;
vector<int> prime;

int GCD(int a, int b) {
	if (a % b == 0)
		return b;

	return GCD(b, a % b);
}

int main() {
	int num = 0;
	int temp = 0;
	int rest_num = 0;
	int gcd = 0;

	scanf("%d", &num);
	for (int i = 0; i < num; i++) {
		scanf("%d", &temp);
		v.push_back(temp);
	}

	sort(v.begin(), v.end());
	gcd = v[1] - v[0];

	for (int i = 2; i < num; i++)
		gcd = GCD(gcd, v[i] - v[i - 1]);

	for (int i = 2; i * i <= gcd; i++) {
		if (gcd % i == 0) {
			prime.push_back(i);
			prime.push_back(gcd / i);
		}
	}

	prime.push_back(gcd);
	sort(prime.begin(), prime.end());

	prime.erase(unique(prime.begin(), prime.end()), prime.end());
	
	for (int i = 0; i < prime.size(); i++)
		printf("%d ", prime[i]);

	return 0;
}
