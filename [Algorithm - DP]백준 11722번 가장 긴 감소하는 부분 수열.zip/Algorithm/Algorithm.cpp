#include <iostream>
#include <algorithm>
#include <cstring>
#include <vector>

int arr[1001];
int dp[1001];

int main() {
	int arr_size = 0;
	int max_len = 0;
	memset(arr, 0, sizeof(arr));
	scanf("%d", &arr_size);

	for (int i = 0; i < arr_size; i++) {
		scanf("%d", &arr[i]);
	}

	// i�� �迭�� ����, 0 ~ i-1�� �迭�� ���鼭 �ڱ⺸�� ū �迭�� ���� + 1 �� �ƽ�
	for (int i = 0; i < arr_size; i++) {
		dp[i] = 1;
		for (int j = 0; j < i; j++) {
			if (arr[j] > arr[i]) {
				dp[i] = std::max(dp[j] + 1, dp[i]);
			}
		}

		if (max_len < dp[i])
			max_len = dp[i];
	}

	printf("%d\n", max_len);

	return 0;
}