#include <iostream>
#include <queue>
#include <cstring>
#include <vector>
#include <string>

#define INF 1e9
#define pair_s std::pair<int,int>

void find_short_cut(int start_p);

int N, M, X = 0;
int short_cut[1001][1001];
int dist_map[1001][1001];
std::vector<int> dest_v[1001];

int main() {
	int start, end, dist = 0;
	int cur_dist = 0;
	int max_dist = 0;

	scanf("%d %d %d", &N, &M, &X);
	for (int i = 0; i < M; i++) {
		scanf("%d %d %d", &start, &end, &dist);
		dest_v[start].push_back(end);
		dist_map[start][end] = dist;
	}

	for (int i = 1; i <= N; i++) {
		find_short_cut(i);
	}
	
	/*for (int i = 1; i <= N; i++) {
		for (int j = 1; j <= N; j++) {
			printf("%d ", short_cut[i][j]);
		}
		printf("\n");
	}*/

	for (int i = 1; i <= N; i++) {
		cur_dist = short_cut[i][X] + short_cut[X][i];
		if (max_dist < cur_dist)
			max_dist = cur_dist;
	}
	printf("%d\n", max_dist);
	return 0;
}

void find_short_cut(int start_p) {
	// �̵��Ÿ�, ��ġ
	std::priority_queue < pair_s, std::vector<pair_s>, std::greater<pair_s>> bfs_q;
	//std::queue<std::pair<int,int>> bfs_q;
	int visit[1001];
	int cur_p = 0;
	int cur_dist = 0;

	memset(visit, 0, sizeof(visit));

	for (int i = 1; i <= N; i++) {
		if (i != start_p) {
			bfs_q.push({ INF, i });
			short_cut[start_p][i] = INF;
		}
	}

	bfs_q.push({ 0, start_p });
	short_cut[start_p][start_p] = 0;

	//printf("���� %d\n", start_p);

	while (bfs_q.empty() == 0) {
		cur_dist = bfs_q.top().first;
		cur_p = bfs_q.top().second;
		
		bfs_q.pop();
		visit[cur_p] = 1;

		//printf("��ǥ %d �Ÿ� %d\n", cur_p, cur_dist);

		/*for (int i = 1; i <= N; i++) {
			printf("%d ", short_cut[start_p][i]);
		}*/
		//printf("\n");

		if (cur_dist <= short_cut[start_p][cur_p]) {
			for (int i = 0; i < dest_v[cur_p].size(); i++) {
				if (short_cut[start_p][dest_v[cur_p][i]] > short_cut[start_p][cur_p] + dist_map[cur_p][dest_v[cur_p][i]]) {
					short_cut[start_p][dest_v[cur_p][i]] = short_cut[start_p][cur_p] + dist_map[cur_p][dest_v[cur_p][i]];
					bfs_q.push({ short_cut[start_p][dest_v[cur_p][i]], dest_v[cur_p][i] });
				}
			}
		}
	}
	
	return;
}