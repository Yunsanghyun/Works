#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>
#include <cmath>
#include <cstring>

// ��ǥ ä�κ��� �ڸ��� 1�� ����
void DFS(int depth, int depth_set);
int convert(std::vector<int>& v);
void print_f(std::vector<int>& p);
int find_len(int num);

int min_gap = 1e9;
int min_gap1 = 1e9;
int min_gap2 = 1e9;
int min_gap3 = 1e9;

char target_channel[7];
int target_channel_num = 0;
int target_channel_len = 0;
int cur_channel = 100;
int broken_num = 0;
int DFS_flag = 0;

std::vector<int> broken_list{ 0,0,0,0,0,0,0,0,0,0 };
std::vector<int> number;

// �Է��� ���ڸ��� ���
// �Է��� 0�� ���
// Ű�� �� ���峭 ���
int main() {
    int temp = 0;

    scanf("%s", target_channel);
    target_channel_len = strlen(target_channel);
    for (int i = 0; i < target_channel_len; i++) {
        target_channel_num += (target_channel[i] - 48) * pow(10, target_channel_len - 1 - i);
    }

    scanf("%d", &broken_num);
    for (int i = 0; i < broken_num; i++) {
        scanf("%d", &temp);
        broken_list[temp] = 1;
    }

    if (target_channel_len != 1) {
        DFS(0, target_channel_len - 1);
        min_gap1 = min_gap;
        min_gap = 1e9;
    }
    number.clear();
    DFS(0, target_channel_len);
    min_gap2 = min_gap;
    min_gap = 1e9;
    number.clear();
    DFS(0, target_channel_len + 1);
    min_gap3 = min_gap;

    min_gap = std::min(min_gap1, std::min(min_gap2, min_gap3));

    // ��� ��ư�� �������� + -�� �����߸���
    if (broken_num == 10)
        printf("%d", std::abs(target_channel_num - cur_channel));

    else
        printf("%d", std::min(min_gap, std::abs(target_channel_num - cur_channel)));

    return 0;
}

void DFS(int depth, int depth_set) {
    int temp_gap = 0;
    int nchannel = 0;
    int nchannel_len = 0;

    // ä���� �ڸ����� ���� ��������
    if (depth == depth_set) {
		nchannel = convert(number);
        if (nchannel > 1000000) {
            DFS_flag = 1;
        }
		nchannel_len = find_len(nchannel);
		temp_gap = std::abs(target_channel_num - nchannel) + nchannel_len;

//		print_f(number);
	//	printf("%d %d %d %d\n",DFS_flag, nchannel, nchannel_len, temp_gap);
		if (min_gap > temp_gap) {
			min_gap = temp_gap;
		}
        return;
    }

	for (int i = 0; i < 10; i++) {
		// ���峪�� ���� ���ڵ�
		if (broken_list[i] != 1 && DFS_flag == 0) {
			number.push_back(i);
			DFS(depth + 1,depth_set);
			number.pop_back();
		}
	}
}

int convert(std::vector<int>& v) {
    int number = 0;

    for (int i = 0; i < v.size(); i++) {
        number += v[i] * pow(10, v.size() - i - 1);
    }

    return number;
}

int find_len(int num) {
    int len = 0;
    int temp_num = num;
    while (1) {
        temp_num = temp_num / 10;
        len++;
        if (temp_num == 0)
            break;
    }

    return len;
}

void print_f(std::vector<int>& p) {
    for (int i = 0; i < p.size(); i++) {
        printf("%d  ", p[i]);
    }
    printf("\n");
}