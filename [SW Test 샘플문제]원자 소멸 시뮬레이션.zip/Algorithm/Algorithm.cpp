#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>

int find_energy();
int range_chk(std::pair<int, int> cur_p);
int copy_delete();

// ù���� ����, �ι��� ������
int direct_map[2001][2001];
int energy_map[2001][2001];
int time_map[2001][2001];
int delete_map[2001][2001];

int N = 0;
// ��,��,��,��
std::vector<std::pair<int, int>> value{ {-1,0},{1,0}, {0,-1}, {0,1} };
int main() {
	int test_case = 0;
	int max_energy = 0;

	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		//memset(direct_map, 0, sizeof(direct_map));
		memset(energy_map, 0, sizeof(energy_map));
		memset(time_map, 0, sizeof(time_map));
		//memset(delete_map, 0, sizeof(delete_map));
		scanf("%d", &N);

		max_energy = find_energy();

		printf("#%d %d\n", i, max_energy);
	}
	return 0;
}

// {{��ǥ, {�̵�����, ������}}, �̵��ð�}
std::vector<std::pair<std::pair<std::pair<int, int>, std::pair<int, int>>, int>> cur_atom_v;
std::vector<std::pair<std::pair<std::pair<int, int>, std::pair<int, int>>, int>> next_atom_v;
int find_energy() {
	std::pair<int, int> cur_p;
	std::pair<int, int> cur_data;
	std::pair<int, int> next_p;
	std::pair<int, int> next_data;

	int cur_time = 0;
	int next_time = 0;
	int energy_sum = 0;
	int atom_num = 0;
	int temp_x = 0, temp_y = 0, temp_direct = 0, temp_energy = 0;

	cur_atom_v.clear();
	next_atom_v.clear();

	for (int j = 0; j < N; j++) {
		scanf("%d %d %d %d", &temp_x, &temp_y, &temp_direct, &temp_energy);
		cur_atom_v.push_back({ { {1000 - temp_y,temp_x + 1000},{temp_direct,temp_energy} },0 });
		direct_map[1000 - temp_y][temp_x + 1000] = temp_direct;
		energy_map[1000 - temp_y][temp_x + 1000] = temp_energy;
	}

	// ��� �� ������ ����� �ұ�
	while (cur_atom_v.empty() == 0) {
		atom_num = cur_atom_v.size();
		for (int i = 0; i < atom_num; i++) {
			cur_p = cur_atom_v[i].first.first;
			cur_data = cur_atom_v[i].first.second;
			cur_time = cur_atom_v[i].second;

			next_p = { cur_p.first + value[cur_data.first].first , cur_p.second + value[cur_data.first].second };
			next_data = cur_data;
			next_time = cur_time + 1;

			if (delete_map[cur_p.first][cur_p.second] == 1) {
				delete_map[cur_p.first][cur_p.second] = 0;
				continue;
			}

			if (range_chk(next_p) == 0) {
				direct_map[cur_p.first][cur_p.second] = 0;
				energy_map[cur_p.first][cur_p.second] = 0;
				time_map[cur_p.first][cur_p.second] = 0;
				continue;
			}

			if (energy_map[next_p.first][next_p.second] != 0 && time_map[next_p.first][next_p.second] == cur_time) {
				if ((cur_data.first == 0 && direct_map[next_p.first][next_p.second] == 1) ||
					(cur_data.first == 1 && direct_map[next_p.first][next_p.second] == 0) ||
					(cur_data.first == 2 && direct_map[next_p.first][next_p.second] == 3) ||
					(cur_data.first == 3 && direct_map[next_p.first][next_p.second] == 2)) {

					energy_sum += cur_data.second + energy_map[next_p.first][next_p.second];

					direct_map[cur_p.first][cur_p.second] = 0;
					energy_map[cur_p.first][cur_p.second] = 0;
					time_map[cur_p.first][cur_p.second] = 0;

					direct_map[next_p.first][next_p.second] = 0;
					energy_map[next_p.first][next_p.second] = 0;
					time_map[next_p.first][next_p.second] = 0;

					delete_map[next_p.first][next_p.second] = 1;
					continue;
				}
			}

			if (energy_map[next_p.first][next_p.second] != 0 && time_map[next_p.first][next_p.second] == next_time) {
				energy_sum += cur_data.second;
				direct_map[cur_p.first][cur_p.second] = 0;
				energy_map[cur_p.first][cur_p.second] = 0;
				time_map[cur_p.first][cur_p.second] = 0;

				delete_map[next_p.first][next_p.second] = 2;
				continue;
			}

			direct_map[next_p.first][next_p.second] = next_data.first;
			energy_map[next_p.first][next_p.second] = next_data.second;
			time_map[next_p.first][next_p.second] = next_time;

			next_atom_v.push_back({ {next_p,next_data},next_time });
		}
		energy_sum += copy_delete();
	}
	return energy_sum;
}

int range_chk(std::pair<int, int> cur_p) {
	if (0 <= cur_p.first && cur_p.first <= 2000) {
		if (0 <= cur_p.second && cur_p.second <= 2000) {
			return 1;
		}
	}
	return 0;
}

int copy_delete() {
	std::pair<int, int> cur_p;
	int energy_sum = 0;
	cur_atom_v.clear();

	for (int i = 0; i < next_atom_v.size(); i++) {
		cur_p = next_atom_v[i].first.first;

		if (delete_map[cur_p.first][cur_p.second] == 2) {
			energy_sum += energy_map[cur_p.first][cur_p.second];
			direct_map[cur_p.first][cur_p.second] = 0;
			energy_map[cur_p.first][cur_p.second] = 0;
			time_map[cur_p.first][cur_p.second] = 0;
			delete_map[cur_p.first][cur_p.second] = 0;
			continue;
		}

		cur_atom_v.push_back(next_atom_v[i]);
	}
	next_atom_v.clear();
	return energy_sum;
}