#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
	int N = 0;
	long long int answer = 1;
	int cnt = 0;
	scanf("%d", &N);

	for (int i = N; i >= 1; i--) {
		answer *= i;
		while(answer % 10 == 0) {
			cnt++;
			answer /= 10;
		}
		answer = answer % 1000;
	}
	printf("%d", cnt);
	return 0;
}