#include <string>
#include <utility>
#include <cstring>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

#define abs(x) x<0 ? -x : x

using namespace std;

// ���۽ð��� ����ð��� ms�� ����ؼ� ����
void time_extract(std::vector<int>& time_v, std::string time_str) {
    std::pair<int, int> time_p;
    int plus = 0;
    int start_time = 0, end_time = 0;
    int hour, min, sec, msec, time = 0;

    hour = (time_str[11] - 48) * 10 + time_str[12] - 48;
    min = (time_str[14] - 48) * 10 + time_str[15] - 48;
    sec = (time_str[17] - 48) * 10 + time_str[18] - 48;
    msec = (time_str[20] - 48) * 100 + (time_str[21] - 48) * 10 + (time_str[22] - 48);

    for (int i = 24; i < time_str.size(); i++) {
        if (time_str[i] == '.') {
            plus = 1;
            continue;
        }
        else if (time_str[i] == 's')
            break;
        else
            time += (time_str[i] - 48) * std::pow(10, 27 - i + plus);
    }

    printf("%d %d %d %d %d\n", hour, min, sec, msec, time);

    end_time = (hour * 3600 + min * 60 + sec) * 1000 + msec;
    if (end_time >= 86400000)
        end_time = 86399999;

    start_time = end_time - time + 1;
    if (start_time < 0)
        start_time = 0;

    time_v.push_back(start_time);
    time_v.push_back(end_time);

    //printf("%d %d\n", start_time, end_time);
    return;
}

int main() {
    int max_cnt = 0;
    int end_time = 0;
    int start_time = 0;
    int start_arr_num = 0;
    int end_arr_num = 0;
    int cur_cnt = 0;

    // ���������� �������� 3�������� 1�� �ı����� �ð������� ���ϴ� ��
    int srch_start_time = 0;
    int srch_end_time = 0;

    // ó��Ƚ���� �� 1�� ���ݱ���
    int guide_start_time = 0;
    int guide_end_time = 0;

    std::vector<string> lines;
    std::vector<int> cur_time_v;
    std::vector<std::vector<int>> total_time_v;
    std::vector<int> start_time_v;
    std::vector<int> end_time_v;
    std::string cur_str;

    /*lines.push_back("2016-09-15 00:00:00.000 0.001s");
    lines.push_back("2016-09-15 00:00:00.000 0.001s");
    lines.push_back("2016-09-15 23:59:59.999 0.001s");
    lines.push_back("2016-09-15 23:59:59.999 0.001s");

    lines.push_back("2016-09-15 20:59:58.233 1.181s");
    lines.push_back("2016-09-15 20:59:58.299 0.8s");
    lines.push_back("2016-09-15 20:59:58.688 1.041s");
    lines.push_back("2016-09-15 20:59:59.591 1.412s");
    lines.push_back("2016-09-15 21:00:00.464 1.466s");
    lines.push_back("2016-09-15 21:00:00.741 1.581s");
    lines.push_back("2016-09-15 21:00:00.748 2.31s");
    */

    lines.push_back("2016-09-15 01:00:04.001 2.0s");
    lines.push_back("2016-09-15 01:00:07.000 2s");

    // �α׿��� ���� �� ����ð��� �����ؼ� ���Ϳ� ����
    for (int i = 0; i < lines.size(); i++) {
        cur_time_v.clear();
        time_extract(cur_time_v, lines[i]);
        total_time_v.push_back(cur_time_v);

        printf("%d��° ���� %d ~ %d\n", i + 1, cur_time_v[0], cur_time_v[1]);
    }

    // �ش� �������� total_time_v�� ���۽ð��̳� ���ð��� ���������� ���ִ� ���
    for (int i = 0; i < total_time_v.size(); i++) {
        int begin = total_time_v[i][1];
        int end = begin + 999;

        printf("�˻����� %d ~ %d\n", begin, end);

        cur_cnt = 0;
        for (int j = i; j < total_time_v.size(); j++) {

            printf("�񱳱��� %d ~ %d\n", total_time_v[j][0], total_time_v[j][1]);
            printf("���� %d / %d\n", abs(total_time_v[j][0] - end), abs(total_time_v[j][1] - begin));

            if (abs(total_time_v[j][1] - begin) >= 1 && abs(total_time_v[j][0] - end) < 1) {
                cur_cnt++;
                printf("cur_cnt = %d\n", cur_cnt);
            }
        }
        if (max_cnt < cur_cnt) {
            max_cnt = cur_cnt;
        }
    }

    printf("Max cnt = %d\n", max_cnt);
    return 0;
}