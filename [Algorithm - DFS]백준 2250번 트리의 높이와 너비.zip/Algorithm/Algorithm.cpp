#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#include <algorithm>

void DFS(int level, int start_p);
std::vector<int> position[10001];

// 0 �ڽĳ��, 1 �ڽĳ��
int tree_set[10001][2];
int visit[10001];
int chk[10001];

int row_num = 0;
int temp_width = 0;
int max_width = 0;
int cnt_level = 1;
int max_level = 1;

int main() {
    int N = 0;
    int root_node = 0;
    memset(tree_set, 0, sizeof(tree_set));
    memset(visit, 0, sizeof(visit));
    memset(chk, 0, sizeof(chk));
    scanf("%d", &N);
    int start_p, left_p, right_p = 0;

    for (int i = 1; i <= N; i++) {
        scanf("%d %d %d", &start_p, &left_p, &right_p);
        tree_set[start_p][0] = left_p;
        tree_set[start_p][1] = right_p;
        chk[left_p] = 1;
        chk[right_p] = 1;
    }

    for (int i = 1; i <= N; i++) {
        if (chk[i] == 0)
            root_node = i;
    }
    // ��Ʈ��尡 �� 1�� �ƴ� �� ����
    // �Էµ� �͵� �߿� �ѹ��� �����ϴ� ���� ��Ʈ����̴�.
    DFS(1,root_node);

    for (int i = 1; i <= cnt_level; i++) {
        // ���� ��ȣ�� ������������ ����
        sort(position[i].begin(), position[i].end());
        temp_width = position[i].back() - position[i].front();
        //printf("���� %d ���� %d\n", i, temp_width + 1);
        if (max_width < temp_width) {
            max_level = i;
            max_width = temp_width;
        }
    }
    printf("%d %d\n", max_level, max_width + 1);
    
    return 0;
}

void DFS(int level, int start_p) {
    if (start_p == -1) {
        return;
    }

    for (int i = 0; i < 2; i++) {
        int next_level = level + 1;
        int next_p = tree_set[start_p][i];

        DFS(next_level, next_p);

        if (visit[start_p] == 0) {
            visit[start_p] = 1;
            row_num++;
            position[level].push_back(row_num);
            if (cnt_level < level)
                cnt_level = level;
            //printf("��%d�� ���� %d ����ȣ %d\n", start_p, level, row_num);
        }
    }
    return;
}