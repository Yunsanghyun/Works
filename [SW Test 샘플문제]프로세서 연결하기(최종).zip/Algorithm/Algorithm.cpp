#include <iostream>
#include <cstring>
#include <vector>

#define TRUE 1
#define FALSE 0

int matrix[13][13];
int core_line[13][13];
int core_visit[13];
int core_direction[13];

void DFS(std::pair<int,int> cur_p, int direction);
int fill_line(std::pair<int, int> cur_p, int direction);
int check_direction(std::pair<int, int> cur_p, int direction);
int no_direction(std::pair<int, int> cur_p);

void print_f();

std::vector < std::pair<int, int>> core_v;

int N = 0;
int core_num = 0;

int cnt = 0;
int line_dist = 0;
int total_line_dist = 0;
int total_line_cnt = 0;
int max_line_cnt = 0;
int min_line_dist = 1e9;

int main() {
	int test_case = 0;

	scanf("%d", &test_case);
	for (int i = 0; i < test_case; i++) {
		memset(matrix, 0, sizeof(matrix));
		memset(core_visit, 0, sizeof(core_visit));
		memset(core_direction, 0, sizeof(core_direction));
		
		core_v.clear();
		max_line_cnt = 0;
		min_line_dist = 1e9;
		cnt = 0;
		core_num = 0;

		scanf("%d", &N);
		for (int j = 0; j < N; j++) {
			for (int k = 0; k < N; k++) {
				scanf("%d", &matrix[j][k]);
				if (matrix[j][k] == 1) {
					if ((0 < j && j < N - 1) && (0 < k && k < N - 1)) {
						core_v.push_back({ j,k });
						core_num++;
					}
				}
			}
		}
		DFS({-1,-1}, 0);
		printf("#%d %d\n",i + 1, min_line_dist);
	}
}

void DFS(std::pair<int, int> cur_p, int direction) {
	if (core_num == cnt) {
		memset(core_line, 0, sizeof(core_line));
		total_line_dist = 0;
		total_line_cnt = 0;

		for (int i = 0; i < cnt; i++) {
			line_dist = fill_line(core_v[i], core_direction[i]);
			if (line_dist == 0) {
				;
			}
			else {
				total_line_dist += line_dist;
				total_line_cnt++;
			}
		}
		
		if (max_line_cnt < total_line_cnt) {
			max_line_cnt = total_line_cnt;
			min_line_dist = total_line_dist;
		}
		else if (max_line_cnt == total_line_cnt)
			if (min_line_dist > total_line_dist)
				min_line_dist = total_line_dist;

		return;
	}

	for (int i = 0; i < core_v.size(); i++) {
		if (core_visit[i] == 0) {
			for (int j = 0; j < 4; j++){
				// ��ΰ� �ϳ��� �ְų�, ��ΰ� �ϳ��� ���� ��,
				if (check_direction(core_v[i], j) || no_direction(core_v[i])) {
					core_visit[i] = 1;
					core_direction[i] = j;
					cnt++;

					DFS(core_v[i], j);

					core_visit[i] = 0;
					core_direction[i] = 0;
					cnt--;
				}
			}
			return;
		}
	}
	return;
}

int distance = 0;
int fill_line(std::pair<int, int> cur_p, int direction) {
	distance = 0;
	std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };
	core_line[cur_p.first][cur_p.second] = 2;

	while (1) {
		cur_p.first += value[direction].first;
		cur_p.second += value[direction].second;
		
		if ((0 > cur_p.first || cur_p.first >= N || 0 > cur_p.second || cur_p.second >= N))
			break;

		if (matrix[cur_p.first][cur_p.second] == 1 || core_line[cur_p.first][cur_p.second] == 1) {
			return 0;
		}
		else {
			core_line[cur_p.first][cur_p.second] = 1;
			distance++;
		}
	}
	return distance;
}

void print_f() {
	printf("\ncore_line\n");
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			printf("%d ", core_line[i][j]);
		}
		printf("\n");
	}
}

int check_direction(std::pair<int, int> cur_p, int direction) {
	std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };

	cur_p.first += value[direction].first;
	cur_p.second += value[direction].second;
	while ((0 <= cur_p.first && cur_p.first < N) && (0 <= cur_p.second && cur_p.second < N)) {
		if (matrix[cur_p.first][cur_p.second] == 1) {
			return 0;
		}
		cur_p.first += value[direction].first;
		cur_p.second += value[direction].second;
	}
	return 1;
}

int no_direction(std::pair<int, int> cur_p) {
	int no_way_cnt = 0;
	std::vector<std::pair<int, int>> value{ {-1,0},{1,0},{0,-1},{0,1} };
	for (int direction = 0; direction < 4; direction++) {
		cur_p.first += value[direction].first;
		cur_p.second += value[direction].second;
		while ((0 <= cur_p.first && cur_p.first < N) && (0 <= cur_p.second && cur_p.second < N)) {
			if (matrix[cur_p.first][cur_p.second] == 1) {
				no_way_cnt++;
			}
			cur_p.first += value[direction].first;
			cur_p.second += value[direction].second;
		}
	}
	if (no_way_cnt == 4)
		return 1;
	else
		return 0;
}