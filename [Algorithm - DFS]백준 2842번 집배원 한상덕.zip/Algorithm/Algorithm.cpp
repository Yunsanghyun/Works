#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

int DFS(std::pair<int, int> cur_p, int left, int right);
int check_range(std::pair<int, int> cur_p);

std::pair<int, int> start_p;
std::pair<int, int> next_p;
std::vector<int> range;
std::vector<std::pair<int, int>> move_v{ {-1,0},{-1,1}, {0,1}, {1,1}, {1,0}, {1,-1}, {0,-1}, {-1,-1} };

char town[51][51];
int visit[51][51];
int height[51][51];

int N = 0;
int house_cnt = 0;

int DFS(std::pair<int, int> cur_p, int left, int right) {
    if (range[left] > height[cur_p.first][cur_p.second] || height[cur_p.first][cur_p.second] > range[right])
        return 0;

    int temp_house_cnt = 0;
    if (town[cur_p.first][cur_p.second] == 'K') {
        temp_house_cnt++;
    }

    for (int i = 0; i < 8; i++) {
        next_p = { cur_p.first + move_v[i].first, cur_p.second + move_v[i].second };
        if (check_range(next_p) && visit[next_p.first][next_p.second] == 0) {
                visit[next_p.first][next_p.second] = 1;
                temp_house_cnt += DFS(next_p, left, right);
        }
    }
    return temp_house_cnt;
}

int main() {
    int tiredness = 1e9;

    scanf("%d", &N);
    for (int i = 0; i < N; i++) {
        scanf("%s", &town[i]);
        for (int j = 0; j < N; j++) {
            if (town[i][j] == 'P')
                start_p = { i,j };
            else if (town[i][j] == 'K') {
                house_cnt++;
            }
        }
    }

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            scanf("%d", &height[i][j]);
            range.push_back(height[i][j]);
        }
    }

    // �ߺ��Ǵ� ������ ��������
    sort(range.begin(), range.end());
    range.erase(std::unique(range.begin(), range.end()), range.end());

    int left = 0;
    int right = 0;
    
    while (left <= right) {
        memset(visit, 0, sizeof(visit));
        
        int get = DFS(start_p, left, right);

        //printf("���� %d ~ %d, �� �� %d \n", range[left], range[right],get);

        if (house_cnt == get) {
            tiredness = std::min(tiredness, range[right] - range[left]);
            left += 1;
        }
        else if (house_cnt > get && right + 1 < range.size())
            right += 1;
        else
            break;
    }
    printf("%d", tiredness);
    return 0;
}


int check_range(std::pair<int, int> cur_p) {
    if (0 <= cur_p.first && cur_p.first < N) {
        if (0 <= cur_p.second && cur_p.second < N) {
            return 1;
        }
    }
    return 0;
}
