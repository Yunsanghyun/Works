#include "Util.h"
#include <iostream>
#include <algorithm>
#include <fstream>
#include <time.h>

namespace MyExcel {
	class Table;

	class Cell {
	protected:
		int x, y;
		Table* table;
	public:
		virtual std::string stringify() = 0;
		virtual int to_numeric() = 0;
		Cell(int _x, int _y, Table* _table);
	};
	
	Cell::Cell(int _x, int _y, Table* _table) 
		: x(_x), y(_y), table(_table){}


	class StringCell : public Cell {
	private:
		std::string data;
	public:
		std::string stringify();
		int to_numeric();

		StringCell(std::string _data, int _x, int _y, Table* _table);
	};

	StringCell::StringCell(std::string _data, int _x, int _y, Table* _table)
		: data(_data), Cell(_x, _y, _table) {}
	std::string StringCell::stringify() {
		return data;
	}
	int StringCell::to_numeric() {
		return 0;
	}

	class NumberCell : public Cell {
	private:
		int data;
	public:
		std::string stringify();
		int to_numeric();

		NumberCell(int _data, int _x, int _y, Table* _table);
	};

	NumberCell::NumberCell(int _data, int _x, int _y, Table* _table)
		: data(_data), Cell(_x, _y, _table) {}
	std::string NumberCell::stringify() {
		return std::to_string(data);
	}
	int NumberCell::to_numeric() {
		return data;
	}

	class DateCell : public Cell {
	private:
		time_t data;
	public:
		std::string stringify();
		int to_numeric();

		DateCell(std::string _data, int _x, int _y, Table* _table);
	};

	DateCell::DateCell(std::string _data, int _x, int _y, Table* _table) 
		: Cell(_x, _y, _table) {
		int year = atoi(_data.c_str());
		int month = atoi((_data.c_str()) + 5);
		int day = atoi(_data.c_str() + 8);

		tm timeinfo;

		timeinfo.tm_year = year - 1900;
		timeinfo.tm_mon = month - 1;
		timeinfo.tm_mday = day;
		timeinfo.tm_hour = 0;
		timeinfo.tm_min = 0;
		timeinfo.tm_sec = 0;

		data = mktime(&timeinfo);
	}

	std::string DateCell::stringify() {
		char buf[50];	
		tm temp;
		localtime_s(&temp, &data);

		strftime(buf, 50, "%F", &temp);
		return std::string(buf);
	}
	int DateCell::to_numeric() {
		return static_cast<int>(data);
	}

	class Table {
	protected:
		int max_row_size, max_col_size;
		Cell*** data_table;
	public:
		Table(int _max_row_size, int _max_col_size);
		~Table();
		// ���ο� �� ���
		void reg_cell(Cell* c, int row, int col);
		// ���� �������� ��ȯ
		int to_numeric(const std::string& s);
		// �� �� �� ��ȣ�� ���� ȣ��
		int to_numeric(int row, int col);
		// ���� ���ڿ��� ��ȯ�Ѵ�.
		std::string stringify(const std::string& s);
		std::string stringify(int row, int col);

		virtual std::string print_table() = 0;
	};

	Table::Table(int _max_row_size, int _max_col_size) {
		max_row_size = _max_row_size;
		max_col_size = _max_col_size;

		data_table = new Cell * *[max_row_size];
		for (int i = 0; i < max_row_size; i++) {
			data_table[i] = new Cell *[max_col_size];
			for (int j = 0; j < max_col_size; j++) {
				data_table[i][j] = NULL;
			}
		}
	}
	Table::~Table() {
		for (int i = 0; i < max_row_size; i++) {
			for (int j = 0; j < max_col_size; j++) {
				if(data_table[i][j])
					delete data_table[i][j];
			}
		}
		for (int i = 0; i < max_row_size; i++) {
			delete[] data_table[i];
		}
		delete[] data_table;
	}
	void Table::reg_cell(Cell* c, int row, int col) {
		if (data_table[row][col]) {
			delete data_table[row][col];
		}
		data_table[row][col] = c;
	}
	// ���� �������� ��ȯ
	int Table::to_numeric(const std::string& s) {
		int col = s[0] - 'A';
		int row = atoi(s.c_str() + 1) - 1;
		
		if (data_table[row][col]) {
			return data_table[row][col]->to_numeric();
		}
		return 0;
	}
	// �� �� �� ��ȣ�� ���� ȣ��
	int Table::to_numeric(int row, int col) {
		if (data_table[row][col]) {
			return data_table[row][col]->to_numeric();
		}
		return 0;
	}
	// ���� ���ڿ��� ��ȯ�Ѵ�.
	std::string Table::stringify(const std::string& s) {
		int row = s[0] - 'A';
		int col = atoi(s.c_str() + 1) - 1;

		if (data_table[row][col]) {
			return data_table[row][col]->stringify();
		}
		return "";
	}
	std::string Table::stringify(int row, int col){
		if (data_table[row][col]) {
			return data_table[row][col]->stringify();
		}
		return "";
	}
	std::ostream& operator<<(std::ostream& o, Table& table) {
		o << table.print_table();
		return o;
	}

	class TxtTable : public Table {
	private:
		std::string repeat_char(int n, char c);
		std::string col_num_to_str(int n);
	public:
		TxtTable(int row, int col) : Table(row, col) {}
		std::string print_table();
	};

	std::string TxtTable::repeat_char(int n, char c) {
		std::string s = "";
		for (int i = 0; i < n; i++) {
			s.push_back(c);
		}
		return s;
	}
	std::string TxtTable::col_num_to_str(int n) {
		std::string s = "";
		if (n < 26) {
			s.push_back('A' + n);
		}
		else {
			char first = 'A' + n / 26 - 1;
			char second = 'A' + n & 26;

			s.push_back(first);
			s.push_back(second);
		}
		return s;
	}
	std::string TxtTable::print_table() {
		std::string total_table;

		// ���ڿ� ��, ���� �� ���ڿ��� ���� Ȯ��
		int* col_max_wide = new int[max_col_size];
		for (int i = 0; i < max_col_size; i++) {
			unsigned int max_wide = 2;
			for (int j = 0; j < max_row_size; j++) {
				if (data_table[j][i] && data_table[j][i]->stringify().length() > max_wide) {
					max_wide = data_table[j][i]->stringify().length();
				}
			}
			col_max_wide[i] = max_wide;
		}
		
		total_table += "    ";
		int total_wide = 4;
		for (int i = 0; i < max_col_size; i++) {
			if (col_max_wide[i]) {
				int max_len = std::max(2, col_max_wide[i]);
				total_table += " I " + col_num_to_str(i);
				total_table += repeat_char(max_len - col_num_to_str(i).length(), ' ');

				total_wide += (max_len + 3);
			}
		}

		total_table += "\n";
		for (int i = 0; i < max_row_size; i++) {
			total_table += repeat_char(total_wide, '-');
			total_table += "\n" + std::to_string(i + 1);
			total_table += repeat_char(4 - std::to_string(i + 1).length(), ' ');

			for (int j = 0; j < max_col_size; j++) {
				if (col_max_wide[j]) {
					int max_len = std::max(2, col_max_wide[j]);

					std::string s = "";
					if (data_table[i][j]) {
						s = data_table[i][j]->stringify(); 
					}
					total_table += " I " + s;
					total_table += repeat_char(max_len - s.length(), ' ');
				}
			}
			total_table += "\n";
		}
		return total_table;
	}
	class ExprCell : public Cell {
	private:
		//�ʱ� ���޵� ����
		std::string data;
		//std::string* parsed_expr;

		//���� ǥ������� ��ȯ�Ǿ��ִ� ����
		Vector exp_vec;

		// ������ �켱 ������ ��ȯ
		int precedence(char c);
		// ������ �м�
		void parse_expression();

	public:
		ExprCell(std::string _data, int _x, int _y, Table* _table);
		std::string stringify();
		int to_numeric();
	};

	ExprCell::ExprCell(std::string _data, int _x, int _y, Table* _table)
		: data(_data), Cell(_x,_y,_table), exp_vec(_data.length() + 2) {
		// data�� �ִ� ������ ���� ǥ������� ��ȯ�Ͽ� exp_vec�� ����
		parse_expression();
	}

	//�����ڿ� �켱���� �ο�
	int ExprCell::precedence(char c) {
		switch (c) {
		case '(':
		case '[':
		case '{':
			return 0;
		case '+':
		case '-':
			return 1;
		case '*':
		case '/':
			return 2;
		}
		return 0;
	}

	// ���������ڷ� ��ȯ
	//�ǿ�����(�� �̸��̳� ����) �� ��� �׳� exp_vec �� �ֽ��ϴ�.
	void ExprCell::parse_expression() {
		Stack stack;

		// ���� ��ü�� () �� �ѷ� �缭 exp_vec �� �����ִ� �����ڵ��� push �ǰ�
		// ���ݴϴ�.
		data.insert(0, "(");
		data.push_back(')');

		for (int i = 0; i < data.length(); i++) {

			if (isalpha(data[i])) {
				exp_vec.add_data(data.substr(i, 2));
				i++;
			}
			else if (isdigit(data[i])) {
				exp_vec.add_data(data.substr(i, 1));
			}
			else if (data[i] == '(' || data[i] == '[' ||
				data[i] == '{') {  // Parenthesis
				stack.add_data(data.substr(i, 1));
			}
			else if (data[i] == ')' || data[i] == ']' || data[i] == '}') {
				std::string t = stack.remove_return_data();
				while (t != "(" && t != "[" && t != "{") {
					exp_vec.add_data(t);
					t = stack.remove_return_data();
				}
			}
			else if (data[i] == '+' || data[i] == '-' || data[i] == '*' ||
				data[i] == '/') {
				while (!stack.is_empty() &&
					precedence(stack.return_data()[0]) >= precedence(data[i])) {
					exp_vec.add_data(stack.remove_return_data());
				}
				stack.add_data(data.substr(i, 1));
			}
		}
	}

	std::string ExprCell::stringify() {
		return std::to_string(to_numeric());
	}
	// ������ȯ���� exp_vec�� ����Ͽ� ���ÿ��� ����
	// ���ϰ��� ���� ��� ������
	int ExprCell::to_numeric() {
		double result = 0;
		NumStack stack;

		for (int i = 0; i < exp_vec.size(); i++) {
			std::string s = exp_vec[i];
			// ����ȣ �̸�
			if (isalpha(s[0])) {
				stack.add_data(table->to_numeric(s));
			}
			// �������� üũ
			else if (isdigit(s[0])) {
				stack.add_data(atoi(s.c_str()));
			}
			// ��ȣ
			else {
				double y = stack.remove_return_data();
				double x = stack.remove_return_data();
				switch (s[0]) {
				case '+':
					stack.add_data(x + y);
					break;
				case '-':
					stack.add_data(x - y);
					break;
				case '*':
					stack.add_data(x * y);
					break;
				case '/':
					stack.add_data(x / y);
					break;
				}
			}
		}
		return stack.remove_return_data();
	}

}

int main() {
	MyExcel::TxtTable table(5, 5);
	table.reg_cell(new MyExcel::NumberCell(2, 1, 1, &table), 1, 1);
	table.reg_cell(new MyExcel::NumberCell(3, 1, 2, &table), 1, 2);

	table.reg_cell(new MyExcel::NumberCell(4, 2, 1, &table), 2, 1);
	table.reg_cell(new MyExcel::NumberCell(5, 2, 2, &table), 2, 2);
	table.reg_cell(new MyExcel::ExprCell("B2+B3*(C2+C3-2)", 3, 3, &table), 3, 2);
	table.reg_cell(new MyExcel::StringCell("B2 + B3 * ( C2 + C3 - 2 ) = ", 3, 2, &table),3,1);

	std::cout << table;
	
	return 0;
}

