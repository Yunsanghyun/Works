#include "Util.h"

namespace MyExcel {
	Vector::Vector(int _alloc_len) {
		alloc_len = _alloc_len;
		data = new std::string[alloc_len];
		curr_len = 0;
	}
	Vector::~Vector() {
		if (data)
			delete[] data;
	}
	void Vector::add_data(std::string _data) {
		if (alloc_len <= curr_len) {
			std::string* temp = new std::string[alloc_len * 2];
			for (int i = 0; i < curr_len; i++) {
				temp[i] = data[i];
			}
			delete[] data;
			data = temp;
			delete[] temp;
			alloc_len = alloc_len * 2;
		}
		data[curr_len] = _data;
		curr_len++;
	}
	void Vector::delete_data(int index) {
		for (int i = index + 1; i < curr_len; i++) {
			data[i - 1] = data[i];
		}
		curr_len--;
	}
	int Vector::size() {
		return curr_len;
	}
	std::string Vector::operator[](int i) {
		return data[i];
	}
	///////////////////////////////////////////////////
	Stack::Stack() : start(NULL, "") {
		current = &start;
	}
	Stack::~Stack() {
		while (current != &start) {
			Node* prev = current;
			current = current->prev;
			delete prev;
		}
	}
	void Stack::add_data(std::string s) {
		Node* n = new Node(current, s);
		current = n;
	}
	std::string Stack::remove_return_data() {
		if (current == &start)
			return "";

		std::string s = current->s;
		Node* prev = current;
		current = current->prev;

		delete prev;
		return s;
	}
	std::string Stack::return_data() {
		if (current == &start)
			return "";

		return current->s;
	}
	bool Stack::is_empty() {
		if (current == &start)
			return true;
		else
			return false;
	}
	//////////////////////////////////////////////////
	NumStack::NumStack() : start(NULL, 0) {
		current = &start;
	}
	NumStack::~NumStack() {
		while (current != &start) {
			Node* prev = current;
			current = current->prev;
			delete prev;
		}
	}
	void NumStack::add_data(double s) {
		Node* n = new Node(current, s);
		current = n;
	}
	double NumStack::remove_return_data() {
		if (current == &start)
			return 0;

		double s = current->s;
		Node* prev = current;
		current = current->prev;

		delete prev;
		return s;
	}
	double NumStack::return_data() {
		if (current == &start)
			return 0;

		return current->s;
	}
	bool NumStack::is_empty() {
		if (current == &start)
			return true;
		else
			return false;
	}
}
