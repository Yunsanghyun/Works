#include <stdio.h>
#include <malloc.h>

#include "LinkedList.h"

int main(void) {	
	List* head_list = NULL;
	List* tail_list = NULL;
	List* cur_list = NULL;

	int data;

	while (1) {
		printf("���ڸ� �Է��Ͻÿ�");
		scanf("%d", &data);
		if (data == 0) {
			break;
		}
		
		List* list = (List*)malloc(sizeof(List));
		list->data = data;
		list->next_list = NULL;

		if (head_list == NULL) {
			head_list = list;
		}
		
		else{
			list->next_list = tail_list;
		} 
		tail_list = list;	
	}

	if (tail_list->next_list != NULL) {
		cur_list = tail_list;
		printf("%d ", cur_list->data);
	}
	while (cur_list->next_list != NULL) {
		cur_list = cur_list->next_list;
		printf("%d ", cur_list->data);
	}

	return 0;
} 