#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stdio.h>

typedef struct Linked_List {
	int data;
	struct Linked_list* next_list;
}List;

#endif	