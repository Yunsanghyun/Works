#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int chk_str(string ref_str, string str) {
    for (int i = 0; i < ref_str.size(); i++) {
        if (ref_str[i] == '*')
            continue;
        else {
            if (ref_str[i] != str[i])
                return 0;
        }
    }
    return 1;
}

// �־��� ���� id ��, ���밡���� id ����Ʈ�� ����
void find_id(vector<string> banned_id, vector<string> user_id, vector<vector<std::pair<string, int>>>& avail_banned) {
    vector<std::pair<string,int>> temp;
    string ref_str;

    for (int i = 0; i < banned_id.size(); i++) {
        ref_str = banned_id[i];
        avail_banned.push_back(temp);
        
        for (int j = 0; j < user_id.size(); j++) {
            if (ref_str.size() != user_id[j].size())
                continue;

            if (chk_str(ref_str, user_id[j])) {
                avail_banned[i].push_back({ user_id[j], j + 1 });
            }

        }
    }
    return;
}

int chk_same(vector<int> cur_banned, vector<vector<int>> final_banned) {
    int flag = 0;

    if (final_banned.size() == 0)
        return 0;
    
    // ������ �ϳ��� ������ �ȵǴ°���
    for (int i = 0; i < final_banned.size(); i++) {
        flag = 0;
        if (final_banned[i] == cur_banned) {
            return 1;
        }

    }
    return 0;
}

int visit[9] = { 0,0,0,0,0,0,0,0,0 };
vector<vector<int>> final_banned;
vector<int> cur_banned;
vector<int> cp_banned;
void DFS(vector<vector<std::pair<string, int>>> avail_banned, int num, int target_id_cnt) {
    if (cur_banned.size() == target_id_cnt) {
        // �������� ����
        cp_banned = cur_banned;
        std::sort(cp_banned.begin(), cp_banned.end());
        // ���� ������ �ִ��� üũ
        if (!chk_same(cp_banned, final_banned)) {
            final_banned.push_back(cp_banned);
        }
        return;
    }

    for (int i = 0; i < avail_banned[num].size(); i++) {
        if (visit[avail_banned[num][i].second] == 0) {
            visit[avail_banned[num][i].second] = 1;
            cur_banned.push_back(avail_banned[num][i].second);

            DFS(avail_banned, num + 1,target_id_cnt);

            visit[avail_banned[num][i].second] = 0;
            cur_banned.pop_back();
        }
    }
    return;
}

int solution(vector<string> user_id, vector<string> banned_id) {
    int answer = 0;
    // ù��° ���ڿ�, �ι�° user_id���� ��ȣ
    vector<vector<std::pair<string,int>>> avail_banned;
    
    find_id(banned_id, user_id, avail_banned);

    DFS(avail_banned, 0, banned_id.size());
    answer = final_banned.size();

    printf("%d\n", answer);

    return answer;
}