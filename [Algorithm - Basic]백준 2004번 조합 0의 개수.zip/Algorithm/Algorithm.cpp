#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int N, M = 0;

int find_num(int num, int value) {
	long long int cnt = 0;

	for (long long i = value; i <= num; i *= value)
		cnt += num / i;

	return cnt;
}

int main() {
	int temp1, temp2 = 0;
	int N_num_cnt = 0;
	int M_num_cnt = 0;
	int N_M_num_cnt = 0;

	scanf("%d %d", &N, &M);

	N_num_cnt = find_num(N,2);
	M_num_cnt = find_num(M,2);
	N_M_num_cnt = find_num(N - M, 2);
	temp1 = N_num_cnt - M_num_cnt - N_M_num_cnt;
	//printf("%d %d %d\n", N_num_cnt, M_num_cnt, N_M_num_cnt);

	N_num_cnt = find_num(N, 5);
	M_num_cnt = find_num(M, 5);
	N_M_num_cnt = find_num(N - M, 5);
	temp2 = N_num_cnt - M_num_cnt - N_M_num_cnt;
	//printf("%d %d %d\n", N_num_cnt, M_num_cnt, N_M_num_cnt);

	printf("%d",min(temp1,temp2) );
	return 0;
}