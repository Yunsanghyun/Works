#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>

void chk_process(std::pair<int, int> a_start, std::pair<int, int> b_start);
void chk_range(std::pair<int, int> cur_p, std::vector<std::pair<int, int>>& cur_bc);

//��,��,��,��
std::vector<std::pair<int, int>> value{ {0,0}, {-1,0},{0,1}, {1,0}, {0,-1} };
// ù��° ��ǥ, �ι�° ��������, ó����
std::vector<std::pair<std::pair<int, int>, std::pair<int, int>>> bc_data;

int a_route[101];
int b_route[101];
int total_process[101];
int M, A = 0;

int main() {
	int test_case = 0;
	int total_sum = 0;
	int temp_x = 0, temp_y = 0, temp_range = 0, temp_process = 0;

	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		memset(a_route, 0, sizeof(a_route));
		memset(b_route, 0, sizeof(b_route));
		memset(total_process, 0, sizeof(total_process));
		bc_data.clear();
		total_sum = 0;
		
		scanf("%d %d", &M, &A);

		for (int j = 1; j <= M; j++) {
			scanf("%d", &a_route[j]);
		}
		for (int j = 1; j <= M; j++) {
			scanf("%d", &b_route[j]);
		}

		for (int k = 0; k < A; k++) {
			scanf("%d %d %d %d", &temp_y, &temp_x, &temp_range, &temp_process);
			bc_data.push_back({ { temp_x - 1,temp_y - 1 }, { temp_range,temp_process } });
		}
		chk_process({ 0,0 }, {9,9});

		for (int i = 0; i <= M; i++) {
			total_sum += total_process[i];
		}
		printf("#%d %d\n", i, total_sum);
	}
	return 0;
}

// ù��°�� BC ��ȣ, �ι����� ó����
std::vector<std::pair<int,int>> bc_A;
std::vector<std::pair<int,int>> bc_B;
void chk_process(std::pair<int, int> a_start, std::pair<int, int> b_start) {
	int max_process = 0;
	int cur_process = 0;
	std::pair<int, int> next_a;
	std::pair<int, int> next_b;
	bc_A.clear();
	bc_B.clear();
	chk_range(a_start, bc_A);
	chk_range(b_start, bc_B);

	for (int i = 0; i < bc_A.size(); i++) {
		for (int j = 0; j < bc_B.size(); j++) {
			if (bc_A[i].first == bc_B[j].first)
				cur_process = (bc_A[i].second + bc_B[j].second)/2;
			else
				cur_process = bc_A[i].second + bc_B[j].second;

			if (max_process < cur_process)
				max_process = cur_process;
		}
	}
	total_process[0] = max_process;
	next_a = a_start;
	next_b = b_start;

	for (int i = 1; i <= M; i++) {
		max_process = 0;
		bc_A.clear();
		bc_B.clear();
		next_a = { next_a.first + value[a_route[i]].first, next_a.second + value[a_route[i]].second };
		next_b = { next_b.first + value[b_route[i]].first, next_b.second + value[b_route[i]].second };
		chk_range(next_a, bc_A);		
		chk_range(next_b, bc_B);
		
		for (int j = 0; j < bc_A.size(); j++) {
			for (int k = 0; k < bc_B.size(); k++) {
				if (bc_A[j].first == bc_B[k].first)
					cur_process = (bc_A[j].second + bc_B[k].second) / 2;
				else
					cur_process = bc_A[j].second + bc_B[k].second;

				if (max_process < cur_process)
					max_process = cur_process;
			}
		}
		total_process[i] = max_process;
	}
	return;
}

// ������ġ���� �ش�Ǵ� BC�� ���Ϳ� ����
void chk_range(std::pair<int,int> cur_p, std::vector<std::pair<int, int>>& cur_bc) {
	int dist = 0;
	for (int i = 0; i < bc_data.size(); i++) {
		dist = std::abs(cur_p.first - bc_data[i].first.first) + std::abs(cur_p.second - bc_data[i].first.second);
		// �������� �ȿ� ���� ��
		if (dist <= bc_data[i].second.first) {
			cur_bc.push_back({ i + 1, bc_data[i].second.second });
		}
		else {
			cur_bc.push_back({ 0,0 });
		}
	}
	return;
}