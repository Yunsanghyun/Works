#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

void DFS(std::pair<int,int> origin_p, int w, int h);
void make_rec(std::pair<int, int> ref_p, int width, int height);
int range_chk(std::pair<int, int> ref_p, int width, int height);

int map[21][21];
int visit[21][21];
int ate_desert[101];

int cur_desert_cnt = 0;
int max_desert_cnt = 0;
int N = 0;

int main() {
	int test_case = 0;	
	
	scanf("%d", &test_case);
	for (int i = 1; i <= test_case; i++) {
		memset(map, 0, sizeof(map));
		max_desert_cnt = 0;

		scanf("%d", &N);
		for (int j = 0; j < N; j++) {
			for (int k = 0; k < N; k++) {
				scanf("%d", &map[j][k]);
			}
		}
		for (int j = 0; j < N; j++) {
			for (int k = 0; k < N; k++) {
				//printf("%d %d ���� ��\n", j, k);
				DFS({j,k}, 0, 0);
			}
		}
		if (max_desert_cnt == 0)
			max_desert_cnt = -1;
		printf("#%d %d\n", i, max_desert_cnt);
	}
	return 0;
}

void DFS(std::pair<int,int> origin_p, int w, int h) {
	//printf("%d %d���� ����%d ����%d\n", origin_p.first, origin_p.second, w, h);

	if (w * h != 0) {
		memset(ate_desert, 0, sizeof(ate_desert));
		memset(visit, 0, sizeof(visit));
		cur_desert_cnt = 0;

		make_rec(origin_p, w, h);

		/*for (int i = 0; i < N; i++) {1
			for (int j = 0; j < N; j++) {
				printf("%d ", visit[i][j]);
			}
			printf("\n");
		}

		for (int i = 1; i < 101; i++)
			printf("%d ", ate_desert[i]);
		printf("\n");*/

		for (int i = 1; i < 101; i++) {
			if (ate_desert[i] >= 2)
				return;
			else if(ate_desert[i] == 1)
				cur_desert_cnt++;
		}

		//printf("�簢�� ����� ���� / ���� ����Ʈ ������ %d\n", cur_desert_cnt);
		if (max_desert_cnt < cur_desert_cnt)
			max_desert_cnt = cur_desert_cnt;

		return;
	}

	// �簢���� �� ���� ���� �̷�� ��������
	for (int i = 1; i < N - 1; i++) {
		for (int j = 1; j < N - 1; j++) {
			if(range_chk(origin_p,i,j))
				DFS(origin_p,i,j);
		}
	}
}

std::vector<std::pair<int, int>> value{ {1,1},{1,-1}, {-1,-1}, {-1,1} };
// ������ǥ�� �������� ���� ���̸� ������ ��, 3�� �������� ���� ���� �ִ��� Ȯ��
int range_chk(std::pair<int, int> ref_p, int width, int height) {
	std::pair<int, int> point_1;
	std::pair<int, int> point_2;
	std::pair<int, int> point_3;
	
	point_1 = { ref_p.first + width * value[0].first, ref_p.second + width * value[0].second };
	point_2 = { point_1.first + height * value[1].first, point_1.second + height * value[1].second };
	point_3 = { point_2.first + width * value[2].first, point_2.second + width * value[2].second };

	if (0 <= point_1.first && point_1.first < N && 0 <= point_1.second && point_1.second < N) {
		if (0 <= point_2.first && point_2.first < N && 0 <= point_2.second && point_2.second < N) {
			if (0 <= point_3.first && point_3.first < N && 0 <= point_3.second && point_3.second < N) {
				return 1;
			}
		}
	}
	return 0;
}

// �ʱ� ��ġ�� �������� ��, ���̸� �̿��� �簢���� �׸���
// �׸��鼭 ����ġ�� ����Ʈ�� �����Ѵ�.
void make_rec(std::pair<int, int> ref_p, int width, int height) {
	std::pair<int, int> cur_p = ref_p;
	std::pair<int, int> next_p = cur_p;

	// ����
	for (int i = 1; i <= width; i++) {
		next_p = { next_p.first + value[0].first, next_p.second + value[0].second };
		ate_desert[map[next_p.first][next_p.second]] += 1;
		visit[next_p.first][next_p.second] = 1;
	}
	// ����
	for (int i = 1; i <= height; i++) {
		next_p = { next_p.first + value[1].first, next_p.second + value[1].second };
		ate_desert[map[next_p.first][next_p.second]] += 1;
		visit[next_p.first][next_p.second] = 1;
	}
	// �ϼ�
	for (int i = 1; i <= width; i++) {
		next_p = { next_p.first + value[2].first, next_p.second + value[2].second };
		ate_desert[map[next_p.first][next_p.second]] += 1;
		visit[next_p.first][next_p.second] = 1;
	}
	// �ϵ�
	for (int i = 1; i <= height; i++) {
		next_p = { next_p.first + value[3].first, next_p.second + value[3].second };
		ate_desert[map[next_p.first][next_p.second]] += 1;
		visit[next_p.first][next_p.second] = 1;
	}
}
