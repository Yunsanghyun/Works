#include <vector>
#include <iostream>
#include <queue>
#include <cstring>

using namespace std;

// �� ��ġ���� ��ź��� ����
// ù����� ������ �³�, �ι�°�� ���ʿ��� �³�
pair<int, int> status[501][501];
int visit[501][501];

int range_chk(pair<int, int> cur_p, int line_size, int row_size) {
    if (0 <= cur_p.first && cur_p.first < line_size) {
        if (0 <= cur_p.second && cur_p.second < row_size) {
            return 1;
        }
    }
    return 0;
}

int BFS(pair<int, int> start_p, vector<vector<int>>& map) {
    int route_case = 0;

    int line_size = map.size();
    int row_size = map[0].size();

    int MOD = 20170805;
    int cur_direct = 0;
    int start = 0;
    int end = 0;
    int flag = 0;

    vector<pair<int, int>> move{ {1,0},{0,1} };
    pair<int, int> cur_p;
    pair<int, int> next_p;
    // ������ġ�κ����� ���Թ��� , ������ġ
    queue<pair<int, pair<int, int>>> bfs_q;

    bfs_q.push({ 0,start_p });
    status[0][0] = { 0,0 };
    while (!bfs_q.empty()) {
        cur_direct = bfs_q.front().first;
        cur_p = bfs_q.front().second;
        bfs_q.pop();

        //printf("�̵� %d %d / ���� %d \n", cur_p.first, cur_p.second, cur_direct);

        for (int i = 0; i < 2; i++) {
            next_p = { cur_p.first + move[i].first, cur_p.second + move[i].second };
            //printf("���� %d %d\n", next_p.first, next_p.second);
            if (range_chk(next_p, line_size, row_size)) {
                // ���� ��ġ�� �̵������� ��ġ�� ��,
                if (map[next_p.first][next_p.second] != 1) {

                    // �湮�� ���� ����
                    if (visit[next_p.first][next_p.second] == 0) {
                        visit[next_p.first][next_p.second] = 1;
                        // 1�̸� �Ʒ�����, 2�̸� �����ʹ���
                        bfs_q.push({ i + 1, next_p });
                    }

                    // ù ����� ��,
                    if (cur_p.first == 0 && cur_p.second == 0) {
                        if (i == 0) {
                            status[next_p.first][next_p.second].first = 1;
                            status[next_p.first][next_p.second].second = 0;
                        }
                        else if (i == 1) {
                            status[next_p.first][next_p.second].first = 0;
                            status[next_p.first][next_p.second].second = 1;
                        }
                        continue;
                    }

                    // ���� ��ġ���� 0���̸� ���� ��ġ�� ��� ������
                    if (map[cur_p.first][cur_p.second] == 0) {
                        // �Ʒ��̵�
                        if (i == 0) {
                            status[next_p.first][next_p.second].first = (status[next_p.first][next_p.second].first + status[cur_p.first][cur_p.second].first + status[cur_p.first][cur_p.second].second) % MOD;
                        }
                        // ���������� �̵�
                        else if (i == 1) {
                            status[next_p.first][next_p.second].second = (status[next_p.first][next_p.second].second + status[cur_p.first][cur_p.second].first + status[cur_p.first][cur_p.second].second) % MOD;
                        }
                    }
                    // ���� ��ġ���� 2���̸�
                    // ���� ���������� ����, �Ѱ��ָ� ����
                    else if (map[cur_p.first][cur_p.second] == 2) {
                        //�Ʒ��� �̵���
                        if (i == 0) {
                            status[next_p.first][next_p.second].first = (status[next_p.first][next_p.second].first + status[cur_p.first][cur_p.second].first) % MOD;
                        }
                        // ���������� �̵� ��,
                        else if (i == 1) {
                            status[next_p.first][next_p.second].second = (status[next_p.first][next_p.second].second + status[cur_p.first][cur_p.second].second) % MOD;
                        }
                    }
                }
            }
        }
    }
    return (status[line_size - 1][row_size - 1].first + status[line_size - 1][row_size - 1].second) % MOD;
}

int main(void) {
    int answer = 0;
    int m = 3;
    int n = 3;
    //vector<vector<int>> city_map{ {0, 0, 0},{0, 0, 0},{0, 0, 0} };
    vector<vector<int>> city_map{ {0, 2, 0, 0, 0, 2},{0, 0, 2, 0, 1, 0},{1, 0, 0, 2, 2, 0} };
    memset(status, 0, sizeof(status));
    memset(visit, 0, sizeof(visit));
    pair<int, int> start_p{ 0,0 };

    answer = BFS(start_p, city_map);

    /*printf("\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", city_map[i][j]);
        }
        printf("\n");
    }

    printf("\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", visit[i][j]);
        }
        printf("\n");
    }

    printf("\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d/%d ", status[i][j].first, status[i][j].second);
        }
        printf("\n");
    }*/

    printf("%d\n", answer);
    return 0;
}